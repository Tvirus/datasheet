/**
  ******************************************************************************
  * @file    board.h
  * @author  weifan
  * @version V1.0.0
  * @date    2020-09-01
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */

#ifndef __BOARD_H_
#define __BOARD_H_


#ifdef __cplusplus
extern "C" {
#endif

#include "fm15f3xx.h"
#include "fm15f3xx_hal.h"

#ifdef __cplusplus
}
#endif
#endif
