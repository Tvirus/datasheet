/**
  ******************************************************************************
  * @file    uart.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-04-30
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "uart.h"

//支持printf函数
#if 1
#pragma import(__use_no_semihosting)
//标准库需要支持的函数
struct __FILE
{
    int handle;
};

FILE __stdout;
//定义_sys_exit()以避免使用半主机模式
void _sys_exit(int x)
{
    x = x;
}
//重定义fputc函数
int fputc(int ch, FILE *f)
{
    while((UARTx->STATUS&0X70)==0x40); //TXFIFO若满，则等待
    UARTx->TXFIFO=(uint8_t)ch;
    return ch;
}
#endif


#if EN_UARTx_RX
uint8_t UART_RX_BUF[UART_REC_LEN]; //用户接收缓存
//bit15：接收到0XD
//bit14~0：接收到的有效字节
__IO uint16_t UART_RX_STA = 0;       //接收状态
//bit15：可发送标志
//bit14~0：可发送的有效字节
__IO uint16_t UART_TX_STA = 0;  //发送状态
uint8_t RxBuffer[RXBUFFERSIZE]; //HAL库使用串口接收缓存
#endif

UART_HandleTypeDef UARTx_Handler;//UART1句柄
/**
  * @brief  Uart Inti
  * @param  UART_TypeDef *UARTx
  * @retval none
  */
void UART_Init(uint32_t bound)
{
    UARTx_Handler.Instance = UARTx;
    UARTx_Handler.Init.BaudRate = bound;
    UARTx_Handler.Init.StopBits = UART_STOPBITS_1;
    UARTx_Handler.Init.WordLength = UART_WORDLENGTH_8B_NONE;
    UARTx_Handler.Init.TransferMode = UART_TRANSFER_TX_RX;
    HAL_UART_Init(&UARTx_Handler);

#if EN_UARTx_RX
    HAL_UART_Receive_IT(&UARTx_Handler, (uint8_t *)RxBuffer, RXBUFFERSIZE);
#endif
}

//UART底层初始化，时钟、引脚、中断
//此函数会被HAL_UART_Init()调用
void HAL_UART_MspInit(UART_HandleTypeDef *huart)
{
    GPIO_InitTypeDef GPIO_InitStruct;
    HAL_CMU_ModuleClockConfig(CMU_MODULE_UART, CMU_UARTCLKSRC_IRC16M, CMU_CLKDIVGP1_1);

    if(huart->Instance==UART0)//UART0
    {
        GPIO_InitStruct.Pin = UART0_TX | UART0_RX;
        GPIO_InitStruct.Alt = GPIO_AF3_UART0;
        GPIO_InitStruct.PuPd = GPIO_NOPULL;
        HAL_GPIO_Init(GPIOF,&GPIO_InitStruct);

#if EN_UARTx_RX
        HAL_NVIC_SetPriority(UART0_IRQn,3,0U);
        HAL_NVIC_EnableIRQ(UART0_IRQn);
#endif
    }

    if(huart->Instance==UART1)//UART1
    {
        GPIO_InitStruct.Pin = UART1_TX | UART1_RX;
        GPIO_InitStruct.Alt = GPIO_AF3_UART1;
        GPIO_InitStruct.PuPd = GPIO_NOPULL;
        HAL_GPIO_Init(GPIOF,&GPIO_InitStruct);

#if EN_UARTx_RX
        HAL_NVIC_SetPriority(UART1_IRQn,3,0U);
        HAL_NVIC_EnableIRQ(UART1_IRQn);
#endif
    }

}

#if EN_UARTx_RX
//中断服务函数
void UART1_Handler(void)
{
    HAL_UART_IRQHandler(&UARTx_Handler);//调用HAL库中断处理函数
}

//中断服务函数
void UART0_Handler(void)
{
    HAL_UART_IRQHandler(&UARTx_Handler);//调用HAL库中断处理函数
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    HAL_UART_Receive_IT(&UARTx_Handler,(uint8_t *)RxBuffer, RXBUFFERSIZE); //接收完成后,重新开启中断并设置RxXferCount为1

    if(huart->Instance==UARTx)
    {
        //接收的数据必须已0x0D,0x0A结尾
        if(UART_RX_STA&0x8000)//接收到0x0D
        {
            if(RxBuffer[0]!=0x0A)UART_RX_STA=0;//接收错误，重新开始
            else
            {
                UART_TX_STA = UART_RX_STA; //接收完成
                UART_RX_STA =0; //状态复位
            }
        }
        else//还没有接收到0x0D
        {
            if(RxBuffer[0]==0x0D)UART_RX_STA|=0x8000;
            else
            {
                UART_RX_BUF[UART_RX_STA&0x3FFF]=RxBuffer[0];//将接收到的字节放入UART_RX_BUF内
                UART_RX_STA++;
                if(UART_RX_STA>(UART_REC_LEN-1))UART_RX_STA=0;//接收错误，重新开始
            }
        }
    }
}
#endif
