Release files for TSL2540/1 (version 2.0) device driver support to the linux kernel.
The driver was developed using on a Raspberry Pi 3B platform, running with 
the Linux Kernel version 4.9 (tag=raspberrypi-kernel_1.20171029-1).

1. Description

  arch/arm/boot/dts/
    - tsl2540-overlay.dts
      This contains the device tree overlay file that is an example of how the
      sensor was added to a Raspberry Pi BSP for development/testing.

  driver/
    This directory contains the source and includes for the driver and
    was built as a module and tested on a Raspberry Pi 3B with kernel version 4.9.

  include/
    This directory contains the device specific include files that are needed
    by both the board config source and the driver source.



The following documentation assumes 'cross-compiling' the driver and copying the resulting '.ko'
to the Raspberry Pi platform. 

A convenience script ./rpi.env is included to setup Cross Compilation environment variables prior to
compiling (Modify this file as outlined below)

Build
     1. Create a build directory to download the necessary files into.
         (Example:        mkdir MyBuildDirectory)
         
     2.    cd MyBuildDirectory
         
     3. Create a another directory and copy the "aos_tsl2540_linux_driver" into it.
         mddir tsl2540
     
     4. Download Raspberry Pi Cross Compile Toolchain:
        - git clone git://github.com/raspberrypi/tools.git --depth=1
     5. Set 'RPI_TOOLCHAIN' environment in the acompanying "rpi.env" file to the applicable 
     directory after git has completed the download.
     For example:
         change:        "${RPI_TOOLCHAIN:?Need to set RPI_TOOLCHAIN to toolchain path}"
         to:            "${RPI_TOOLCHAIN:?./tools/}"
     
     6. Download Raspberry Pi Linux Kernel source:
          - git clone https://github.com/raspberrypi/linux
          - git checkout raspberrypi-kernel_1.20171029-1
     7. Set 'LINUX_SRC' environment variable in "rpi.env" as in step 5 above.

     8. Creat a directory called "ams" under the newly install kerel source;
     "linux/include/linux/i2c" and copy the "ams_tsl2540.h" file into it.
      
     9. Compile Raspberry Pi Linux Kernel*
           - cd linux
          - make bcm2709_defconfig
          - make modules_prepare
          - make -j 4 zImage modules dtbs

     10. Compile Device Driver:
          - 'source ./rpi.env' to setup for cross compiling
          - cd ./driver
          - make clean
          - make CONFIG_SENSORS_TSL2540/1=m
          - copy 'tsl2540.ko' to Raspberry Pi

     11. Compile Device Tree overlay
          - cd ./arch/arm/boot/dts
          - dtc -@ -I dts -O dtb -o tsl2540-overlay.dtbo tsl2540-overlay.dts
          
      (RASPBERRY PI)
          - copy tsl2540-overlay.dtbo to the raspberry Pi direcetory: /boot/overlays/  
          - add 'dtoverlay=tsl2540-overlay' to end of text file /boot/config.txt
          - Raspberry Pi must be rebooted to take effect

Operation

  1. In the Raspberry Pi shell, become root with:
      sudo su -

  2. Transfer the driver module to the raspberry pi (if it is not already in the image).

  3. Insert the driver module
      -insmod /home/pi/tsl2540.ko
      -rmmod tsl2540    // remove the module

  4. Check the input device names in sysfs to find to find the features supported
     with this sensor.
       root@raspberrypi:~# ls /sys/class/input/input(x)

  5. Read from the input device files to get als attributes (device settings) and data
       root@raspberrypi:~# cat /sys/class/input/input(x)/als_gain
       or
       root@raspberrypi:~# echo 1 > /sys/class/input/input(x)/als_enable

ABI descriptions

    ALS sysfs entries
      ./als_enable - read/write device enable.
      ./als_itime - read/write the ALS integration time
      ./als_auto_gain - reads 'auto' or 'manual'. 
              (Set to 0 = manual, 1 = auto) 
      ./als_ch0 - read the raw channel 0 count
      ./als_ch1 - read the raw channel 1 count
      ./als_cpl - read the current CPL value
      ./als_gain - read/write the gain setting
          Setting gain manually, will place auto_gain control into
          'manual' mode, until auto_gain_gain is set to 1.
      ./als_lux - read the calculated lux value
      ./als_persist - read/write the ALS persistance settings
      ./als_thresh_deltaP - read/write ALS deltaP setting (default 10%)
      ./als_wtime - read/write the wait time before ALS readings


Hardware Wiring to Raspberry Pi 3b

This diagram is for wiring an Official AMS 7-pin evaluation Daughter card to the
Raspberry Pi 3b 40-pin connector. (see https://pinout.xyz/)


        Raspberry Pi 3b:                            AMS 7-pin Daughter card:

                    -----                                              --
    Pin_1    3.3V - |* *|                                         X --| Pin_1
          I2C_SDA - |* *|                                       VDD --|
          I2C_SCL - |* *| - GND                                 GND --|
                    |* *|                                   I2C_SDA --|
                    |* *|                                   I2C_SCL --|
                    |* *|                                       INT --|
                    |* *|                                         X --|
                    |* *|                                              --
                    |* *|
                    |* *|
                    |* *|
                    |* *|
                    |* *|
                    |* *|
                    |* *|
                    |* *|
                    |* *|
                    |* *|
                    |* *| - GPIO20 (INT)
                    |* *|
                    -----


*Reference Material for Raspberry Pi Cross compiling:
    http://elinux.org/Raspberry_Pi_Kernel_Compilation
    https://www.raspberrypi.org/documentation/linux/kernel/building.md
                    