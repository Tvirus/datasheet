/**
  ******************************************************************************
  * @file    board.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-03-17
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"
#include "uart.h"

#define TIMx  ST0
#define TIMx_IRQ   STIMER0_IRQn

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{
    while (1)
    {
    }
}
#endif


ADC_HandleTypeDef ADC_Handler={0};//ADC���
void ADC_Init(void)
{
    ADC_ChannelConfigTypeDef ADC_ChannelConf={0};
    ADC_DataProcessConfigTypeDef ADC_DataProcessConf={0};
    GPIO_InitTypeDef GPIO_InitStruct={0};

    ADC_Handler.Instance         = ADC0;
    //ADC����ʱ��

    LL_CMU_ConfigADCClk(LL_CMU_ADCCLK_IRC16M,LL_CMU_REUSEDIV1_DIV1);
    LL_CMU_IDLE_OpenModuleClk(LL_CMU_MDCLK_ADC);

    ADC_Handler.Init.ClkSel        = ADC_CLKSEL_WORKCLKDIV1;
    ADC_Handler.Init.WorkMode      = ADC_WORKMODE_FREETRIG;
    ADC_Handler.Init.ConvertMode   = ADC_CONVMODE_ONESHOT;
    ADC_Handler.Init.ReadyTime     = 0;
    ADC_Handler.Init.SampleTime    = 96;
    ADC_Handler.Init.AutoSleepEn   = ADC_AUTOSLEEP_DISABLE;
    ADC_Handler.Init.VcomEn        = ADC_VCOM_DISABLE;

    HAL_ADC_Init(&ADC_Handler);

    ADC_ChannelConf.Channel      = ADC_CHANNEL_0;
    ADC_ChannelConf.Input        = ADC_INSRC_VDDBKP;    //
    ADC_ChannelConf.TrigSrc      = ADC_TRIGSRC_SOFTWARE;
    ADC_ChannelConf.TrigDelay    = 0;
    ADC_ChannelConf.DiffEn       = ADC_CHxDIFF_DISABLE;
    ADC_ChannelConf.TrigInvEn    = ADC_CHxTRIGINV_DISABLE;

    HAL_ADC_ChannelConfig(&ADC_Handler,&ADC_ChannelConf);        //ͨ������

    ADC_DataProcessConf.Channel       = ADC_CHANNEL_0;
    ADC_DataProcessConf.AverageEn     = ADC_CHxAVERAGE_ENABLE;

    ADC_DataProcessConf.AverageNum    = ADC_AVGNUM_4;
    ADC_DataProcessConf.CompareEn     = ADC_CHxCOMPARE_ENABLE;
    ADC_DataProcessConf.CompareMode   = ADC_CMP_LESS_CV1;
    ADC_DataProcessConf.CompareValue1 = 0xFFF;
    ADC_DataProcessConf.CompareValue2 = 0x0;
    HAL_ADC_DataProcrssConfig(&ADC_Handler,&ADC_DataProcessConf);

    GPIO_InitStruct.Pin   = GPIO_PIN_3;
    GPIO_InitStruct.Alt   = GPIO_AF0_ADC;
    GPIO_InitStruct.PuPd  = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOF,&GPIO_InitStruct);

    //ʹ���ж�ADC0
    HAL_NVIC_SetPriority(ADC0_IRQn, 10, 0U);
    HAL_NVIC_EnableIRQ(ADC0_IRQn);
}


void LED_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct={0};

    GPIO_InitStruct.Pin           = GPIO_PIN_6;
    GPIO_InitStruct.Alt           = LL_GPIO_ALT_GPIO;
    GPIO_InitStruct.Dir           = LL_GPIO_DIRECTION_OUT;
    GPIO_InitStruct.DriveStrength = LL_GPIO_DRIVES_STRONG;
    GPIO_InitStruct.Irq           = LL_GPIO_INTorDMA_DISABLE;
    GPIO_InitStruct.Lock          = LL_GPIO_LK_UNLOCK;
    GPIO_InitStruct.OType         = LL_GPIO_OUTPUT_NOOPENDRAIN;
    GPIO_InitStruct.PuPd          = LL_GPIO_PULL_UP;
    GPIO_InitStruct.Speed         = LL_GPIO_SLEWRATE_HIGH;
    GPIO_InitStruct.WECconfig     = LL_GPIO_WKUP_CLOSED;
    LL_GPIO_Init(GPIOA,&GPIO_InitStruct);
}

void HAL_MspInit(void)
{
    SystemClock_Config();
    UART_Init(115200);
    LED_Init();
    ADC_Init();
    STIMER0_Init();
}


void LED_Toggle(void)
{
    LL_GPIO_TogglePin(GPIOA,GPIO_PIN_6);
}

void STIMER0_Init(void)
{
    LL_CMU_SetStimerClkSrc(TIMx,LL_CMU_STCLK_IRC16M);//16MHz

    LL_STIM_Disable(TIMx);
    LL_STIM_Reset(TIMx);
    LL_STIM_SetPrescaler(TIMx,LL_TIM_PSC_DIV16);//16MHZ/16=1MHz=1us
    LL_STIM_SetRunMode(TIMx,LL_TIM_MODE_MODCNT);
    LL_STIM_DisableOneshot(TIMx);
    LL_STIM_SetMod0Value(TIMx,500000);//200000*1us=0.2s
    LL_STIM_SetTrigOutMode(TIMx,LL_TIM_TR_OUT_HOLD);//LL_TIM_TR_OUT_PULSE;LL_TIM_TR_OUT_HOLD
    LL_STIM_SetTrigInv(TIMx,LL_TIM_TR_OUT_INVERT);//LL_TIM_TR_OUT_NONINVERTED;LL_TIM_TR_OUT_INVERTED

    LL_STIM_EnableINT(TIMx);
    NVIC_SetPriority(TIMx_IRQ, 1);
    NVIC_EnableIRQ(TIMx_IRQ);

    LL_STIM_Enable(TIMx);
}


//����ADC IT
void Get_StartADC_IT(uint32_t ch)
{
    HAL_ADC_Start_IT(&ADC_Handler, ch); //����ADC
}


void STIMER0_Handler(void)
{
    if(LL_STIM_IsActiveFlag(TIMx))
    {
        LL_STIM_ClearFlag(TIMx);
        Get_StartADC_IT(0);
    }
}
/************************************************************************/
/*������:ADC0_Handler                                                   */
/*����˵��:ADC0_Handler                                                 */
/************************************************************************/
void ADC0_Handler(void)
{
    HAL_ADC_IRQHandler(&ADC_Handler, ADC_CHANNEL_0);
}

uint32_t adcvalue=0;
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc,uint32_t channel)
{
    adcvalue = HAL_ADC_GetValue(hadc, channel);
    adcvalue = 3300*adcvalue/4096*4;
    printf("VDDBKP_VALUE (mV)-> %d \n",adcvalue);
    HAL_ADC_Stop_IT(hadc, channel);
}


