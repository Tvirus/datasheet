/*
 ******************************************************************************
 * @file    command.c
 * @author  weifan
 * @version V1.0.0
 * @date    2020-09-03
 * @brief
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
 * All rights reserved.</center></h2>
 *
 ******************************************************************************
 */
#include <stdio.h>
#include <stdlib.h>
#include "flash.h"
#include "uart.h"


#ifndef min
#define min(a,b) ((a)<(b)?(a):(b))
#define max(a,b) ((a)>(b)?(a):(b))
#endif

#define FLASH_PAGE_SIZE 2048

int WriteFlash32(uint32_t addr, uint32_t* wbuf, int wlen)
{	
	int rv;
	
	while(wlen-- > 0){		
		rv = LL_FLASH_Prog1Word(addr, *wbuf, 1);
		if(rv != FLASH_COMPLETE)
			return -1;
		wbuf ++;
		addr += 4;
	}
		
	return 0;
}

void ReadFlash(uint32_t addr, uint8_t* data, uint32_t len)
{
	memcpy(data, (void*)addr, len);
}

int WriteDataFlash(uint32_t addr, uint8_t* data, uint32_t len)
{
	uint8_t  _buf[FLASH_PAGE_SIZE];
	uint32_t pos, clen;
	
	// start page
	pos  = addr&(FLASH_PAGE_SIZE-1);  // offset within page
	addr = addr&~(FLASH_PAGE_SIZE-1); // page base_addr
	
	while(len > 0){
		clen = min(FLASH_PAGE_SIZE-pos, len);
		if(clen  < FLASH_PAGE_SIZE) {
			ReadFlash(addr, _buf, FLASH_PAGE_SIZE);
		}
		
		memcpy(_buf+pos, data, clen);	

		if(LL_FLASH_Erase1Sector_Single(addr) != FLASH_COMPLETE){
			return 2;
		}

		if( WriteFlash32(addr, (uint32_t*)_buf, FLASH_PAGE_SIZE/4) != 0) {
			return 3;	
		}
		addr += FLASH_PAGE_SIZE;
		data += clen;
		len -= clen; pos = 0; 
	}
	
	return 0;
}
