/**
  ******************************************************************************
  * @file    main.c
  * @author  SRG
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"
#include "bsp_fsmc_sram.h"

void delay_ms(uint32_t ms)
{
	int i,j;
	for(i=0;i<ms;i++)
		for(j=0;j<4000;j++);
}

#define BUFFER_SIZE        0x400      /* 1024���ֽ� */
//#define BUFFER_SIZE      0x40      /* 1024���ֽ� */
#define WRITE_READ_ADDR    0x8000


uint16_t TxBuffer[BUFFER_SIZE];
uint16_t RxBuffer[BUFFER_SIZE];
uint32_t WriteReadStatus = 0, Index = 0;

int main(void)
{
	 
  LED_Init();
	POWER_Init();
	/* ���� FSMC Bank1 NOR/SRAM3 */
  FSMC_SRAM_Init();
  //LED1(ON);
  
  /* ���Ҫ���͵Ļ����� */
  Fill_Buffer(TxBuffer, BUFFER_SIZE, 0x3212);
  
  /* ��������������д��SRAM���� */
  FSMC_SRAM_WriteBuffer(TxBuffer, WRITE_READ_ADDR, BUFFER_SIZE);
  
  delay_ms(500);
  
  /* ���ո�д��SRAM��������ݶ����� */
  FSMC_SRAM_ReadBuffer(RxBuffer, WRITE_READ_ADDR, BUFFER_SIZE);  

  /* ��д��SRM��������ݺʹ�SRAM��������ݶ������ȶ� */   
  for (Index = 0x00; (Index < BUFFER_SIZE) && (WriteReadStatus == 0); Index++)
  {
    if (RxBuffer[Index] != TxBuffer[Index])
    {
      WriteReadStatus = Index + 1;
    }
  }	

  if (WriteReadStatus == 0)
  {	/* OK */
    /* Turn on LD2 */
    while(1)
    {
     LED2_Toggle();
     delay_ms(500);
    }    
  }                               
  else  
  { 	
    while(1)
    {
      LED3_Toggle();
      delay_ms(500);
    }
  }
	
}
/* ------------------------------------------------end of file-------------------------------------------- */


