/**
  ******************************************************************************
  * @file FSMC/SRAM/fsmc_sram.c 
  * @author  MCD Application Team
  * @version  V3.0.0
  * @date  04/06/2009
  * @brief  This file provides a set of functions needed to drive the 
  *         IS61WV51216BLL SRAM memory mounted on STM3210E-EVAL board.
  ******************************************************************************
  * @copy
  */ 

/* Includes ------------------------------------------------------------------*/
#include "bsp_fsmc_sram.h"
#include "board.h"

/** @addtogroup StdPeriph_Examples
  * @{
  */

/** @addtogroup FSMC_SRAM
  * @{
  */ 

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/

#define Bank_SRAM_ADDR        ((uint32_t)0x18000000)


/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Configures the FSMC and GPIOs to interface with the SRAM memory.
  *         This function must be called before any write/read operation
  *         on the SRAM.
  * @param  None 
  * @retval : None
  */
	#define SRAM_FSMC_NE         GPIO_PIN_6      
	#define SRAM_FSMC_NADV       GPIO_PIN_5  
	#define SRAM_FSMC_NWE        GPIO_PIN_1  
	#define SRAM_FSMC_NOE        GPIO_PIN_0  
	#define SRAM_FSMC_NLB        GPIO_PIN_2  
	#define SRAM_FSMC_NUB        GPIO_PIN_3  
	#define SRAM_FSMC_CTR_PORT   GPIOD
	
void FSMC_SRAM_Init(void)
{
  LL_GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.Alt=LL_GPIO_ALT_7;
	GPIO_InitStruct.Dir=LL_GPIO_DIRECTION_OUT;
	GPIO_InitStruct.DriveStrength=LL_GPIO_DRIVES_STRONG;
	GPIO_InitStruct.Irq=LL_GPIO_INTorDMA_DISABLE;
	GPIO_InitStruct.Lock=LL_GPIO_LK_UNLOCK;
	GPIO_InitStruct.OType=LL_GPIO_OUTPUT_NOOPENDRAIN;
	GPIO_InitStruct.PuPd=LL_GPIO_PULL_UP;
	GPIO_InitStruct.Speed=LL_GPIO_SLEWRATE_HIGH;
	GPIO_InitStruct.WECconfig=LL_GPIO_WKUP_CLOSED;

/*-- GPIO Configuration ------------------------------------------------------*/
  /* SRAM Data lines configuration */
	GPIO_InitStruct.Pin=GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7;
	LL_GPIO_Init(GPIOA,&GPIO_InitStruct);
	
	GPIO_InitStruct.Pin=GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6
	|GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11;
	LL_GPIO_Init(GPIOB,&GPIO_InitStruct);
	 
  /* SRAM Address lines configuration */
	GPIO_InitStruct.Pin=GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14;
	LL_GPIO_Init(GPIOB,&GPIO_InitStruct);
	
	/* NE configuration */
		GPIO_InitStruct.Pin=SRAM_FSMC_NE;
 	LL_GPIO_Init(GPIOD,&GPIO_InitStruct);
	
  /* NOE and NWE configuration */  
	GPIO_InitStruct.Pin=SRAM_FSMC_NWE|SRAM_FSMC_NOE;
 	LL_GPIO_Init(GPIOD,&GPIO_InitStruct);
  
  /* NLB, NUB configuration */
	GPIO_InitStruct.Pin=SRAM_FSMC_NLB|SRAM_FSMC_NUB;
 	LL_GPIO_Init(GPIOD,&GPIO_InitStruct);
	
	 /* NADV configuration */
	GPIO_InitStruct.Pin=SRAM_FSMC_NADV;
 	LL_GPIO_Init(GPIOD,&GPIO_InitStruct);
	  
/*-- FSMC Configuration ------------------------------------------------------*/
	LL_FSMC_NORSRAMInitTypeDef  FSMC_NORSRAMInitStructure;
	LL_FSMC_TimingConfigTypeDef  p;
	FSMC_TypeDef FMSC;
  FSMC_NORSRAMInitStructure.WorkMode = LL_FSMC_NORSRAM_MODE;
  FSMC_NORSRAMInitStructure.AccessMode = LL_FSMC_ACCESS_MMAP;
  FSMC_NORSRAMInitStructure.MemoryDataWidth = LL_FSMC_WIDTH_16;
  FSMC_NORSRAMInitStructure.NWaitEn = LL_FSMC_NWAIT_DISABLE;
  FSMC_NORSRAMInitStructure.NWaitPolarity = LL_FSMC_NWAITPOL_LOW;
  FSMC_NORSRAMInitStructure.ClkEn = LL_FSMC_CLK_DISABLE;
  FSMC_NORSRAMInitStructure.ClkDiv = 0;
	
	p.AddressSetupTime = 0x03;
  p.AddressHoldTime = 0x03;
  p.DataSetupTime = 0x03; 
  p.DataHoldTime = 0x03;
  p.BusReadyTime =0x03; 
	
	LL_FSMC_NORSRAMInit(&FMSC,&FSMC_NORSRAMInitStructure); 
	LL_FSMC_TimingInit(&FMSC,&p);
	LL_FSMC_Enable(&FMSC);
}

/*
 * ��仺����
 */
void Fill_Buffer(uint16_t *pBuffer, uint16_t BufferLenght, uint32_t Offset)
{
  uint16_t IndexTmp = 0;

  /* Put in global buffer same values */
  for (IndexTmp = 0; IndexTmp < BufferLenght; IndexTmp++ )
  {
    pBuffer[IndexTmp] = IndexTmp + Offset;
  }
}

/**
  * @brief  Writes a Half-word buffer to the FSMC SRAM memory. 
  * @param pBuffer : pointer to buffer. 
  * @param WriteAddr : SRAM memory internal address from which the data 
  *        will be written.
  * @param NumHalfwordToWrite : number of half-words to write. 
  * @retval : None
  */
void FSMC_SRAM_WriteBuffer(uint16_t* pBuffer, uint32_t WriteAddr, uint32_t NumHalfwordToWrite)
{
  for(; NumHalfwordToWrite != 0; NumHalfwordToWrite--) /* while there is data to write */
  {
    /* Transfer data to the memory */
    *(uint16_t *) (Bank_SRAM_ADDR + WriteAddr) = *pBuffer++;
    
    /* Increment the address*/  
    WriteAddr += 2;
  }   
}

/**
  * @brief  Reads a block of data from the FSMC SRAM memory.
  * @param pBuffer : pointer to the buffer that receives the data read 
  *        from the SRAM memory.
  * @param ReadAddr : SRAM memory internal address to read from.
  * @param NumHalfwordToRead : number of half-words to read.
  * @retval : None
  */
void FSMC_SRAM_ReadBuffer(uint16_t* pBuffer, uint32_t ReadAddr, uint32_t NumHalfwordToRead)
{
  for(; NumHalfwordToRead != 0; NumHalfwordToRead--) /* while there is data to read */
  {
    /* Read a half-word from the memory */
    *pBuffer++ = *(__IO uint16_t*) (Bank_SRAM_ADDR + ReadAddr);

    /* Increment the address*/  
    ReadAddr += 2;
  }  
}

/*-----------------------------------------------------------------------------*/
void SRAM_Test(void)
{
  
}

/**
  * @}
  */ 

/**
  * @}
  */ 

/******************* (C) COPYRIGHT 2009 STMicroelectronics *****END OF FILE****/
