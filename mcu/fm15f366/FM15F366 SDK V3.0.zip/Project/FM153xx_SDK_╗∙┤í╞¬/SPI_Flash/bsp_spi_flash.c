 /**
  ******************************************************************************
  * @file    bsp_xxx.c
  * @author  
  * @version V1.0
  * @date    
  * @brief   spi flash �ײ�Ӧ�ú���bsp 
  ******************************************************************************
  * @attention
  ******************************************************************************
  */
  
#include "bsp_spi_flash.h"
#include "board.h"
#define SPI_MOSI_PIN	GPIO_PIN_2
#define SPI_MISO_PIN	GPIO_PIN_1
#define SPI_SCK_PIN		GPIO_PIN_0
#define SPI_NSS_PIN   LL_BKP_PIN1
#define SPI_PORT		  GPIOE
#define SPIx			    SPI3

//#define SPI_FLASH_PageSize            4096
#define SPI_FLASH_PageSize              256
#define SPI_FLASH_PerWritePageSize      256
/* Private typedef -----------------------------------------------------------*/
#define FM25Q32     
//#define FM25Q32 
/* W25Q32 Private define ------------------------------------------------------------*/
#ifdef W25Q32
#define W25X_WriteEnable		      0x06 
#define W25X_WriteDisable		      0x04 
#define W25X_ReadStatusReg		    0x05 
#define W25X_WriteStatusReg		    0x01 
#define W25X_ReadData			        0x03 
#define W25X_FastReadData		      0x0B 
#define W25X_FastReadDual		      0x3B 
#define W25X_PageProgram		      0x02 
#define W25X_BlockErase			      0xD8 
#define W25X_SectorErase		      0x20 
#define W25X_ChipErase			      0xC7 
#define W25X_PowerDown			      0xB9 
#define W25X_ReleasePowerDown	    0xAB 
#define W25X_DeviceID			        0x9F 
#define W25X_ManufactDeviceID   	0x90 
#define W25X_JedecDeviceID		    0x9F 
#define WIP_Flag                  0x01  /* Write In Progress (WIP) flag */
#define Dummy_Byte                0xFF
#endif

/*FM25Q32 Standard SPI Private define------------------------------------------------------------*/
#ifdef FM25Q32
#define FM25X_WriteEnable		        0x06
#define FM25X_WriteDisable		      0x04 
#define FM25X_ReadStatusReg1		    0x05
#define FM25X_ReadStatusReg2		    0x35
#define FM25X_WriteStatusReg		    0x01 
#define FM25X_ReadData			        0x03 
#define FM25X_FastReadData		      0x0B 
#define FM25X_SectorErase_4k		    0x20 
#define FM25X_BlockErase_32k		    0x52
#define FM25X_BlockErase_64k		    0xD8 
#define FM25X_ChipErase			        0xC7 
#define FM25X_FastReadDual		      0x3B 
#define FM25X_PageProgram		        0x02 
#define FM25X_ChipErase			        0xC7 
#define FM25X_PowerDown			        0xB9 
#define FM25X_ReleasePowerDown	    0xAB 
#define FM25X_DeviceID			        0x92 
#define FM25X_ManufactDeviceID     	0x90 
#define FM25X_JedecDeviceID		      0x9F
#define FM25X_QPIEnable		          0x38 
#define WIP_Flag                    0x01  /* Write In Progress (WIP) flag */
#define FM25X_ResetEnable		        0x66
#define FM25X_Reset	                0x99
#define FM25X_SecuritySectorErase       0x44
#define FM25X_SecuritySectorProgram     0x42
#define FM25X_SecuritySectorRead        0x48
#define Dummy_Byte                      0xFF
#endif
/*******************************************************************************
* Function Name  : SPI_FLASH_Init
* Description    : Initializes the peripherals used by the SPI FLASH driver.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SPI_Init(void)
{
	LL_SPI_InitParamTypeDef SPI_InitStruct;
	
	LL_GPIO_SetPinMux(SPI_PORT,SPI_MOSI_PIN,GPIO_AF_SPI3);
	LL_GPIO_SetPinMux(SPI_PORT,SPI_MISO_PIN,GPIO_AF_SPI3);
	LL_GPIO_SetPinMux(SPI_PORT,SPI_SCK_PIN,GPIO_AF_SPI3);
	SPI_InitStruct.BaudRate=LL_SPI_BaudRatePrescaler_DIV2;//fPCLK/2=16MHz/2=8MHz
	SPI_InitStruct.BitOrder=LL_SPI_MSB_FIRST;
	SPI_InitStruct.ClockPhase=LL_SPI_CPHA_1EDGE;
	SPI_InitStruct.ClockPolarity=LL_SPI_CPOL_LOW;
	SPI_InitStruct.ErrorIE=LL_SPI_ERRORIE_DISABLE;
	SPI_InitStruct.Mode=LL_SPI_MODE_MASTER;
	SPI_InitStruct.RXFHALFIE=LL_SPI_RXFHALFIE_DISABLE;
	SPI_InitStruct.RXNEIE=LL_SPI_RXNEIE_DISABLE;
	SPI_InitStruct.SamplePosition=LL_SPI_SamplePosition_Normal;
	SPI_InitStruct.SignalFilterMOSI=LL_SPI_SignalFilterMOSI_DISABLE;
	SPI_InitStruct.SignalFilterSCK=LL_SPI_SignalFilterSCK_DISABLE;
	SPI_InitStruct.SignalFilterSSN=LL_SPI_SignalFilterSSN_DISABLE;
	SPI_InitStruct.SlaveDataSendMode=LL_SPI_SlaveDataSendMode_Normal;
	SPI_InitStruct.SPI_EN=LL_SPI_SPIEN_DISABLE;
	SPI_InitStruct.SSNMCU=LL_SPI_SSNMCU_HIGH;
	SPI_InitStruct.SSNMode=LL_SPI_SSNMODE_HIGH;
	SPI_InitStruct.SSNODEN=LL_SPI_SSNODEN_DISABLE;
	SPI_InitStruct.SSN_MCU_EN=LL_SPI_SSNMCUEN_HARDWARE;
	SPI_InitStruct.TXEHalfIE=LL_SPI_TXEHALFIE_DISABLE;
	SPI_InitStruct.TXEIE=LL_SPI_TXEIE_DISABLE;
	SPI_InitStruct.TXONLY=LL_SPI_TXONLY_DISABLE;
	SPI_InitStruct.TXONLY_EN=LL_SPI_TXONLYEN_DISABLE;
	SPI_InitStruct.T_BYTE=LL_SPI_TBYTE_1BYTE;
	SPI_InitStruct.WAIT_CNT=LL_SPI_WAITCNT_0CYCLE;
	LL_SPIx_Init(SPIx,&SPI_InitStruct);
	LL_SPI_Enable(SPIx);
}

void Flash_NSS_LOW(void)  
{
	LL_BKP_EnableVmain2Vbat(BKP_VMAIN);
	LL_BKP_GPIO_Enable();
	LL_BKP_GPIO_SetPinOutputDir(SPI_FLASH_NSS_PIN);
	LL_BKP_GPIO_ResetOutputPin(SPI_FLASH_NSS_PIN);
}

void Flash_NSS_HIGH(void)  
{
	LL_BKP_EnableVmain2Vbat(BKP_VMAIN);
	LL_BKP_GPIO_Enable();
	LL_BKP_GPIO_SetPinOutputDir(SPI_FLASH_NSS_PIN);
	LL_BKP_GPIO_SetOutputPin(SPI_FLASH_NSS_PIN);
}
/*******************************************************************************
* Function Name  : SPI_FLASH_SectorErase
* Description    : Erases the specified FLASH sector.
* Input          : SectorAddr: address of the sector to erase.
* Output         : None
* Return         : None
*******************************************************************************/

uint32_t SPI_FLASH_ReadDeviceID(void)
{
 uint32_t Temp=0,Temp0=0,Temp1=0, Temp2=0; 
 
  /* Select the FLASH: Chip Select low */
  Flash_NSS_LOW();

  /* Send "RDID " instruction */
  Temp =SPI_RW_Byte(FM25X_JedecDeviceID);
  /* Read a byte from the FLASH */
  Temp0 = SPI_RW_Byte(Dummy_Byte);
  /* Read a byte from the FLASH */
  Temp1 = SPI_RW_Byte(Dummy_Byte);
  /* Read a byte from the FLASH */
	 Temp2 = SPI_RW_Byte(Dummy_Byte);
	
   Temp = Temp0<<16|Temp1<<8|Temp2;
  /* Deselect the FLASH: Chip Select high */
  Flash_NSS_HIGH();
  return Temp;
}
/*******************************************************************************
* Function Name  : SPI_FLASH_WaitForWriteEnd
* Description    : Polls the status of the Write In Progress (WIP) flag in the
*                  FLASH's status  register  and  loop  until write  opertaion
*                  has completed.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SPI_FLASH_WaitForWriteEnd(void)
{
  uint32_t FLASH_Status = 0;

  /* Select the FLASH: Chip Select low */
  Flash_NSS_LOW();

  /* Send "Read Status Register" instruction */
  SPI_RW_Byte(FM25X_ReadStatusReg1);

  /* Loop as long as the memory is busy with a write cycle */
  do
  {
    /* Send a dummy byte to generate the clock needed by the FLASH
    and put the value of the status register in FLASH_Status variable */
    FLASH_Status = SPI_RW_Byte(Dummy_Byte);	 
  }
  while ((FLASH_Status & WIP_Flag) == SET); /* Write in progress */

  /* Deselect the FLASH: Chip Select high */
  Flash_NSS_HIGH();
}
/*******************************************************************************
* Function Name  : SPI_FLASH_WriteEnable
* Description    : Enables the write access to the FLASH.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SPI_FLASH_WriteEnable(void)
{
  /* Select the FLASH: Chip Select low */
  Flash_NSS_LOW();

  /* Send "Write Enable" instruction */
  SPI_RW_Byte(FM25X_WriteEnable);

  /* Deselect the FLASH: Chip Select high */
  Flash_NSS_HIGH();
}

/*******************************************************************************
* Function Name  : SPI_FLASH_PageWrite
* Description    : Writes more than one byte to the FLASH with a single WRITE
*                  cycle(Page WRITE sequence). The number of byte can't exceed
*                  the FLASH page size.
* Input          : - pBuffer : pointer to the buffer  containing the data to be
*                    written to the FLASH.
*                  - WriteAddr : FLASH's internal address to write to.
*                  - NumByteToWrite : number of bytes to write to the FLASH,
*                    must be equal or less than "SPI_FLASH_PageSize" value.
* Output         : None
* Return         : None
*******************************************************************************/
void SPI_FLASH_PageWrite(uint8_t* pBuffer, uint32_t WriteAddr, uint16_t NumByteToWrite)
{
  /* Enable the write access to the FLASH */
  SPI_FLASH_WriteEnable();

  /* Select the FLASH: Chip Select low */
  Flash_NSS_LOW();
  /* Send "Write to Memory " instruction */
  SPI_RW_Byte(FM25X_PageProgram);
  /* Send WriteAddr high nibble address byte to write to */
  SPI_RW_Byte((WriteAddr & 0xFF0000) >> 16);
  /* Send WriteAddr medium nibble address byte to write to */
  SPI_RW_Byte((WriteAddr & 0xFF00) >> 8);
  /* Send WriteAddr low nibble address byte to write to */
  SPI_RW_Byte(WriteAddr & 0xFF);

  if(NumByteToWrite > SPI_FLASH_PerWritePageSize)
  {
     NumByteToWrite = SPI_FLASH_PerWritePageSize;
     //printf("\n\r Err: SPI_FLASH_PageWrite too large!");
  }

  /* while there is data to be written on the FLASH */
  while (NumByteToWrite--)
  {
    /* Send the current byte */
    SPI_RW_Byte(*pBuffer);
    /* Point on the next byte to be written */
    pBuffer++;
  }

  /* Deselect the FLASH: Chip Select high */
  Flash_NSS_LOW();

  /* Wait the end of Flash writing */
  SPI_FLASH_WaitForWriteEnd();
}

/*******************************************************************************
* Function Name  : SPI_FLASH_BufferWrite
* Description    : Writes block of data to the FLASH. In this function, the
*                  number of WRITE cycles are reduced, using Page WRITE sequence.
* Input          : - pBuffer : pointer to the buffer  containing the data to be
*                    written to the FLASH.
*                  - WriteAddr : FLASH's internal address to write to.
*                  - NumByteToWrite : number of bytes to write to the FLASH.
* Output         : None
* Return         : None
*******************************************************************************/
void SPI_FLASH_BufferWrite(uint8_t* pBuffer, uint32_t WriteAddr, uint16_t NumByteToWrite)
{
  uint8_t NumOfPage = 0, NumOfSingle = 0, Addr = 0, count = 0, temp = 0;

  Addr = WriteAddr % SPI_FLASH_PageSize;
  count = SPI_FLASH_PageSize - Addr;
  NumOfPage =  NumByteToWrite / SPI_FLASH_PageSize;
  NumOfSingle = NumByteToWrite % SPI_FLASH_PageSize;

  if (Addr == 0) /* WriteAddr is SPI_FLASH_PageSize aligned  */
  {
    if (NumOfPage == 0) /* NumByteToWrite < SPI_FLASH_PageSize */
    {
      SPI_FLASH_PageWrite(pBuffer, WriteAddr, NumByteToWrite);
    }
    else /* NumByteToWrite > SPI_FLASH_PageSize */
    {
      while (NumOfPage--)
      {
        SPI_FLASH_PageWrite(pBuffer, WriteAddr, SPI_FLASH_PageSize);
        WriteAddr +=  SPI_FLASH_PageSize;
        pBuffer += SPI_FLASH_PageSize;
      }

      SPI_FLASH_PageWrite(pBuffer, WriteAddr, NumOfSingle);
    }
  }
  else /* WriteAddr is not SPI_FLASH_PageSize aligned  */
  {
    if (NumOfPage == 0) /* NumByteToWrite < SPI_FLASH_PageSize */
    {
      if (NumOfSingle > count) /* (NumByteToWrite + WriteAddr) > SPI_FLASH_PageSize */
      {
        temp = NumOfSingle - count;

        SPI_FLASH_PageWrite(pBuffer, WriteAddr, count);
        WriteAddr +=  count;
        pBuffer += count;

        SPI_FLASH_PageWrite(pBuffer, WriteAddr, temp);
      }
      else
      {
        SPI_FLASH_PageWrite(pBuffer, WriteAddr, NumByteToWrite);
      }
    }
    else /* NumByteToWrite > SPI_FLASH_PageSize */
    {
      NumByteToWrite -= count;
      NumOfPage =  NumByteToWrite / SPI_FLASH_PageSize;
      NumOfSingle = NumByteToWrite % SPI_FLASH_PageSize;

      SPI_FLASH_PageWrite(pBuffer, WriteAddr, count);
      WriteAddr +=  count;
      pBuffer += count;

      while (NumOfPage--)
      {
        SPI_FLASH_PageWrite(pBuffer, WriteAddr, SPI_FLASH_PageSize);
        WriteAddr +=  SPI_FLASH_PageSize;
        pBuffer += SPI_FLASH_PageSize;
      }

      if (NumOfSingle != 0)
      {
        SPI_FLASH_PageWrite(pBuffer, WriteAddr, NumOfSingle);
      }
    }
  }
}

/*******************************************************************************
* Function Name  : SPI_FLASH_BufferRead
* Description    : Reads a block of data from the FLASH.
* Input          : - pBuffer : pointer to the buffer that receives the data read
*                    from the FLASH.
*                  - ReadAddr : FLASH's internal address to read from.
*                  - NumByteToRead : number of bytes to read from the FLASH.
* Output         : None
* Return         : None
*******************************************************************************/
void SPI_FLASH_BufferRead(uint8_t* pBuffer, uint32_t ReadAddr, uint16_t NumByteToRead)
{
  /* Select the FLASH: Chip Select low */
  Flash_NSS_LOW();

  /* Send "Read from Memory " instruction */
  SPI_RW_Byte(FM25X_ReadData);

  /* Send ReadAddr high nibble address byte to read from */
  SPI_RW_Byte((ReadAddr & 0xFF0000) >> 16);
  /* Send ReadAddr medium nibble address byte to read from */
  SPI_RW_Byte((ReadAddr& 0xFF00) >> 8);
  /* Send ReadAddr low nibble address byte to read from */
  SPI_RW_Byte(ReadAddr & 0xFF);

  while (NumByteToRead--) /* while there is data to be read */
  {
    /* Read a byte from the FLASH */
    *pBuffer = SPI_RW_Byte(Dummy_Byte);
    /* Point to the next location where the byte read will be saved */
    pBuffer++;
  }

  /* Deselect the FLASH: Chip Select high */
  Flash_NSS_HIGH();
}

/*******************************************************************************
* Function Name  : SPI_FLASH_SectorErase
* Description    : Erases the specified FLASH sector.
* Input          : SectorAddr: address of the sector to erase.
* Output         : None
* Return         : None
*******************************************************************************/
void SPI_FLASH_SectorErase(uint32_t SectorAddr)
{
  /* Send write enable instruction */
  SPI_FLASH_WriteEnable();
  SPI_FLASH_WaitForWriteEnd();
  /* Sector Erase */
  /* Select the FLASH: Chip Select low */
  Flash_NSS_LOW();
  /* Send Sector Erase instruction */
  SPI_RW_Byte(FM25X_SectorErase_4k);
  /* Send SectorAddr high nibble address byte */
  SPI_RW_Byte((SectorAddr & 0xFF0000) >> 16);
  /* Send SectorAddr medium nibble address byte */
  SPI_RW_Byte((SectorAddr & 0xFF00) >> 8);
  /* Send SectorAddr low nibble address byte */
  SPI_RW_Byte(SectorAddr & 0xFF);
  /* Deselect the FLASH: Chip Select high */
  Flash_NSS_HIGH();
  /* Wait the end of Flash writing */
  SPI_FLASH_WaitForWriteEnd();
}
//�������ģʽ
void SPI_Flash_PowerDown(void)   
{ 
  /* Select the FLASH: Chip Select low */
  Flash_NSS_LOW();

  /* Send "Power Down" instruction */
  SPI_RW_Byte(FM25X_PowerDown);

  /* Deselect the FLASH: Chip Select high */
  Flash_NSS_HIGH();
}
//����
void SPI_Flash_WAKEUP(void)   
{
  /* Select the FLASH: Chip Select low */
  Flash_NSS_LOW();

  /* Send "Power Down" instruction */
  SPI_RW_Byte(FM25X_ReleasePowerDown);

  /* Deselect the FLASH: Chip Select high */
  Flash_NSS_HIGH();                   //�ȴ�TRES1
}   
 
/*******************************************************************************
* Function Name  : SPI_FLASH_BulkErase
* Description    : Erases the entire FLASH.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SPI_FLASH_BulkErase(void)
{
  /* Send write enable instruction */
  SPI_FLASH_WriteEnable();

  /* Bulk Erase */
  /* Select the FLASH: Chip Select low */
  Flash_NSS_LOW();
  /* Send Bulk Erase instruction  */
  SPI_RW_Byte(FM25X_ChipErase);
  /* Deselect the FLASH: Chip Select high */
  Flash_NSS_HIGH();

  /* Wait the end of Flash writing */
  SPI_FLASH_WaitForWriteEnd();
}
/*******************************************************************************
* Function Name  : SPI_FLASH_ReadByte
* Description    : Reads a byte from the SPI Flash.
*                  This function must be used only if the Start_Read_Sequence
*                  function has been previously called.
* Input          : None
* Output         : None
* Return         : Byte Read from the SPI Flash.
*******************************************************************************/
uint8_t SPI_FLASH_ReadByte(void)
{
  return (SPI_RW_Byte(Dummy_Byte));
}

/*******************************************************************************
* Function Name  : SPI_FLASH_SendByte
* Description    : Sends a byte through the SPI interface and return the byte
*                  received from the SPI bus.
* Input          : byte : byte to send.
* Output         : None
* Return         : The value of the received byte.
*******************************************************************************/
uint8_t SPI_RW_Byte(uint8_t cmd_addr)
{
	uint8_t rev_data;
	LL_SPI_TransmitData(SPIx,cmd_addr);
	while(LL_SPI_IsEmpty_RxFifo(SPIx));
	rev_data=LL_SPI_ReceiveData(SPIx);
	return rev_data;
}
/*******************************************************************************
* Function Name  : SPI_FLASH_SendHalfWord
* Description    : Sends a Half Word through the SPI interface and return the
*                  Half Word received from the SPI bus.
* Input          : Half Word : Half Word to send.
* Output         : None
* Return         : The value of the received Half Word.
*******************************************************************************/
uint16_t SPI_FLASH_SendHalfWord(uint16_t HalfWord)
{
	uint8_t rev_data;
	LL_SPI_TransmitData(SPIx,HalfWord);
	while(LL_SPI_IsEmpty_RxFifo(SPIx));
	rev_data = LL_SPI_ReceiveData(SPIx);
	return rev_data;
}
/*********************************************END OF FILE**********************/
