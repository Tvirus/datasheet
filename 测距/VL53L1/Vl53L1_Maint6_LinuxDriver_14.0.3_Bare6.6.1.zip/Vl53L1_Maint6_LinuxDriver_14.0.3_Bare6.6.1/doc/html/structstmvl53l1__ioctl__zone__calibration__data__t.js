var structstmvl53l1__ioctl__zone__calibration__data__t =
[
    [ "data", "structstmvl53l1__ioctl__zone__calibration__data__t.html#ac4c80e7e018a15821b1eb0aa7a861508", null ],
    [ "is_read", "structstmvl53l1__ioctl__zone__calibration__data__t.html#a6c29ff159fc538b53923789ae790f25a", null ]
];