/**
  ******************************************************************************
  * @file    main.c
  * @author  SRG
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"
#include "uart.h"
#include "stdio.h"
#include "stdint.h"
#include "bsp_i2c_ee.h"

void delay_ms(uint32_t ms)
{
	int i,j;
	for(i=0;i<ms;i++)
		for(j=0;j<4000;j++);
}

int main(void)
{
  POWER_Init();
	UARTx_Init(UART1,115200,LL_UART_STOPSEL_1BIT,LL_UART_PDSEL_N_8);
	printf("UART Initial success! \r\n");
	printf("eeprom 软件模拟i2c测试程序！\r\n");
	while(1)
	{
		ee_Test();
		for(uint8_t i=0;i < 10;i++)
		{
		delay_ms(1000);
		LED_Toggle();
		printf("%d \r\n",i);
		}
	}
}
