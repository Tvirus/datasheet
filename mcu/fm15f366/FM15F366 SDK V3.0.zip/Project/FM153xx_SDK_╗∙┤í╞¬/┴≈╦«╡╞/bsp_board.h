/**
  ******************************************************************************
  * @file    board.h
  * @author  SRG
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */

#ifndef __BOARD_H_
#define __BOARD_H_


#ifdef __cplusplus
 extern "C" {
#endif


#include "fm15f3xx.h"
#include "fm15f3xx_conf.h"






void LED_Init(void);
void LED_Toggle(void);
void LED2_Toggle(void);
void LED3_Toggle(void);
void LED2_OFF(void);
void LED2_ON(void);
void LED3_OFF(void);
void LED3_ON(void);



uint8_t UserKey_GetData(void);

void UserKey_Init(void);














#ifdef __cplusplus
}
#endif
#endif
