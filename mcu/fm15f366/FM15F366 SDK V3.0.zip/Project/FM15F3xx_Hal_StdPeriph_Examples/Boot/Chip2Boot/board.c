/**
  ******************************************************************************
  * @file    board.c
  * @author  weifan
  * @version V1.0.0
  * @date    2020-09-01
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"
#include "uart.h"

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{
  while (1)
  {
  }
}
#endif

void HAL_MspInit(void)
{
  SystemClock_Config();
  UART_Init(UARTx_BAUDRATE);
}


