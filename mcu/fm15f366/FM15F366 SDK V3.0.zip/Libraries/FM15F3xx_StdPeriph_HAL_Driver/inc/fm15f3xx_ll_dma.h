/**
  ******************************************************************************
  * @file    fm15f3xx_ll_dma.h
  * @author  SRG
  * @version V1.0.0
  * @date    2020-03-17
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */

#ifndef FM15F3XX_LL_DMA_H
#define FM15F3XX_LL_DMA_H
#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "fm15f3xx.h"
#include "fm15f3xx_typedef.h"

/** @addtogroup FM15F3XX_LL_Driver
  * @{
  */

#if defined (DMA)

/** @defgroup DMA_LL DMA
  * @{
  */

/* Exported typedef --------------------------------------------------------*/
/** @defgroup DMA_LL_ExADCed_Functions DMA Functions
  * @{
  */

/**
  * @brief  DMA transfer width enumeration
  */
typedef enum _dma_transfer_width
{
  DMA_TRANSFERWIDTH_8BIT   = 0x0U,
  DMA_TRANSFERWIDTH_16BIT  = 0x1U,
  DMA_TRANSFERWIDTH_32BIT  = 0x2U,
  DMA_TRANSFERWIDTH_32BIT_ = 0x3U
} DmaTransferWidth_t;

/**
  * @brief  DMA transfer burst enumeration
  */
typedef enum _dma_transfer_burst
{
  DMA_TRANSFERBURST_SINGLE = 0x0U,
  DMA_TRANSFERBURST_INC4   = 0x1U,
  DMA_TRANSFERBURST_INC8   = 0x2U,
  DMA_TRANSFERBURST_INC16  = 0x3U,
} DmaTransferBurst_t;

/**
  * @brief  DMA modulo enumeration
  */
typedef enum _dma_modulo
{
  DMA_MODULO_DISABLE = 0x0U, /*!< Disable modulo */
  DMA_MODULO_2BYTES,         /*!< Circular buffer size is 2 bytes.   */
  DMA_MODULO_4BYTES,         /*!< Circular buffer size is 4 bytes.   */
  DMA_MODULO_8BYTES,         /*!< Circular buffer size is 8 bytes.   */
  DMA_MODULO_16BYTES,        /*!< Circular buffer size is 16 bytes.  */
  DMA_MODULO_32BYTES,        /*!< Circular buffer size is 32 bytes.  */
  DMA_MODULO_64BYTES,        /*!< Circular buffer size is 64 bytes.  */
  DMA_MODULO_128BYTES,       /*!< Circular buffer size is 128 bytes. */
  DMA_MODULO_256BYTES,       /*!< Circular buffer size is 256 bytes. */
  DMA_MODULO_512BYTES,       /*!< Circular buffer size is 512 bytes. */
  DMA_MODULO_1KBYTES,        /*!< Circular buffer size is 1K bytes.  */
  DMA_MODULO_2KBYTES,        /*!< Circular buffer size is 2K bytes.  */
  DMA_MODULO_4KBYTES,        /*!< Circular buffer size is 4K bytes.  */
  DMA_MODULO_8KBYTES,        /*!< Circular buffer size is 8K bytes.  */
  DMA_MODULO_16KBYTES,       /*!< Circular buffer size is 16K bytes. */
  DMA_MODULO_32KBYTES,       /*!< Circular buffer size is 32K bytes. */
} DmaModulo_t;

/**
  * @brief  DMA transfer type enumeration
  */
typedef enum _dma_transfer_type
{
  DMA_MEMORYtoMEMORY = 0x0U,
  DMA_PERIPHERALtoMEMORY,
  DMA_MEMORYtoPERIPHERAL,
} DmaTransferType_t;

/**
  * @brief  DMA TcdAttr structures
  */
typedef struct _dma_trans_attr
{
  DmaTransferWidth_t SrcTransferWidth;
  DmaTransferWidth_t DestTransferWidth;
  DmaTransferBurst_t SrcTransferBurst;
  DmaTransferBurst_t DestTransferBurst;
  DmaModulo_t Smod;
  DmaModulo_t Dmod;
  int8_t SrcOffset;
  int8_t DestOffset;
} Dma_TcdAttr_t;

/**
  * @brief  DMA Tcd Minor Loop structures
  */
typedef struct _dma_trans_MinorLoop
{
  uint32_t MinorLoopBytes;
  FunctionalState  SmolEn;
  FunctionalState  DmolEn;
  uint32_t Moff;
  FunctionalState  MinorLinkEn;
  uint8_t  MinorLinkch;
} DmaTcdMinorLoop_t;

/**
  * @brief  DMA Tcd Major Loop structures
  */
typedef struct _dma_trans_MajorLoop
{
  uint32_t MajorLoopCounts;
  FunctionalState  MajorLinkEn;
  uint8_t  MajorLinkch;
  FunctionalState  TcdScatterEn;
  uint32_t SLastSGA;
  uint32_t DLastSGA;
} DmaTcdMajorLoop_t;

/**
  * @brief  DMA Transfer Config structures
  */
typedef struct _dma_transfer_config
{
  uint32_t SrcAddr;
  uint32_t DestAddr;
  Dma_TcdAttr_t TcdAttr;
  DmaTcdMinorLoop_t TcdMinorLoop;
  DmaTcdMajorLoop_t TcdMajorLoop;
} LL_DMA_TransferConfig;

/**
  * @}
  */
/* Exported constants --------------------------------------------------------*/
/** @defgroup DMA_CHANNEL
  * @{
  */
#define LL_DMA_CHANNEL_0        (0x00U)
#define LL_DMA_CHANNEL_1        (0x01U)
#define LL_DMA_CHANNEL_2        (0x02U)
#define LL_DMA_CHANNEL_3        (0x03U)
#define LL_DMA_CHANNEL_4        (0x04U)
#define LL_DMA_CHANNEL_5        (0x05U)
#define LL_DMA_CHANNEL_6        (0x06U)
#define LL_DMA_CHANNEL_7        (0x07U)
/**
  * @}
  */


void LL_DMA_Init(uint32_t Channel, LL_DMA_TransferConfig *DMA_TransferStruct, dma_tcd_t *NextTcd);
void LL_DMA_ConfigTcd(dma_tcd_t *tcd, uint32_t channel, LL_DMA_TransferConfig * config, dma_tcd_t *nextTcd);
void DMA_SetTransferConfig(uint32_t channel, LL_DMA_TransferConfig *config, dma_tcd_t *nextTcd);
/**
  * @}
  */

#endif /* defined (DMA) */


#ifdef __cplusplus
}
#endif
#endif

/************************ (C) COPYRIGHT FudanMicroelectronics *****END OF FILE****/
