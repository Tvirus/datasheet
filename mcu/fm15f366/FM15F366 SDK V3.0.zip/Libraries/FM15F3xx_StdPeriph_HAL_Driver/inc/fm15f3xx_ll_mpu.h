/**
  ******************************************************************************
  * @file    fm15f3xx_ll_mpu.h
  * @author  SRG
  * @version V1.0.0
  * @date    2020-03-17
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */

#ifndef FM15F3XX_LL_MPU_H
#define FM15F3XX_LL_MPU_H
#ifdef __cplusplus
extern "C" {
#endif

#include "fm15f3xx.h"

/** @addtogroup FM15F366_LL_Driver
  * @{
  */

/* Private types -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private constants ---------------------------------------------------------*/
/* Private macros ------------------------------------------------------------*/
/* ExSPIed functions --------------------------------------------------------*/
/*! @brief MPU region config. */
typedef struct
{
  uint32_t regionNum;
  uint32_t startAddress;
  uint32_t endAddress;
  uint32_t accessRights1;
  uint32_t accessRights2;
  uint32_t accessRights3;
  uint32_t setCtrl;
  uint32_t setSwCtl;
} LL_MPU_RegionTypeDef;

/*! @brief MPU region right config. */
typedef struct
{
  uint32_t regionNum;
  uint32_t accessRights1;
  uint32_t accessRights2;
  uint32_t accessRights3;
  uint32_t setCtrl;
  uint32_t setSwCtl;
} LL_MPU_RightTypeDef;

/*! @brief MPU detail error access information. */
typedef struct
{
  uint32_t status;
  uint32_t address;
  uint32_t details;
} LL_MPU_AccessErrTypeDef;


/** @defgroup MPU_LL_Configuration Configuration
  * @{
  */

#define MPU_REGION_COUNT          (8U)
#define MPU_ACCESS_RIGHT_N        0x00

#define MPU_REGION_NUM_0          0x00
#define MPU_REGION_NUM_1          0x01
#define MPU_REGION_NUM_2          0x02
#define MPU_REGION_NUM_3          0x03
#define MPU_REGION_NUM_4          0x04
#define MPU_REGION_NUM_5          0x05
#define MPU_REGION_NUM_6          0x06
#define MPU_REGION_NUM_7          0x07

#define MPU_REGION_DMA_DSP_N      0x00
#define MPU_REGION_SJUMPE_N       0x00


/**
  * @brief  LL_MPU_Get_CSR
  * @param  None
  * @retval RegValue
  */
__STATIC_INLINE uint32_t LL_MPU_Get_CSR(MPU_TypeDef *MPUx)
{
  return (READ_REG(MPUx->CSR));
}

/**
  * @brief  LL_MPU_Set_CSR
  * @param  None
  * @retval None
  */
__STATIC_INLINE void LL_MPU_Set_CSR(MPU_TypeDef *MPUx, uint32_t val)
{
  WRITE_REG(MPUx->CSR, val);
}

/**
  * @brief  LL_MPU_Get_EAR
  * @param  None
  * @retval RegValue
  */
__STATIC_INLINE uint32_t LL_MPU_Get_EAR(MPU_TypeDef *MPUx, uint8_t num)
{
  return (uint32_t)(READ_REG(MPUx->SP[num].EAR));
}

/**
  * @brief  LL_MPU_Get_EDR
  * @param  None
  * @retval RegValue
  */
__STATIC_INLINE uint32_t LL_MPU_Get_EDR(MPU_TypeDef *MPUx, uint8_t num)
{
  return (uint32_t)(READ_REG(MPUx->SP[num].EDR));
}

/**
  * @brief  LL_MPU_Set_SADDR
  * @param  None
  * @retval None
  */
__STATIC_INLINE void LL_MPU_Set_SADDR(MPU_TypeDef *MPUx, uint8_t num,uint32_t val)
{
  WRITE_REG(MPUx->REGION[num].SADDR, val);
}

/**
  * @brief  LL_MPU_Set_EADDR
  * @param  None
  * @retval None
  */
__STATIC_INLINE void LL_MPU_Set_EADDR(MPU_TypeDef *MPUx, uint8_t num,uint32_t val)
{
  WRITE_REG(MPUx->REGION[num].EADDR, val);
}

/**
  * @brief  LL_MPU_Set_AUTHA
  * @param  None
  * @retval None
  */
__STATIC_INLINE void LL_MPU_Set_AUTHA(MPU_TypeDef *MPUx, uint8_t num,uint32_t val)
{
  WRITE_REG(MPUx->REGION[num].EADDR, val);
}

/**
  * @brief  LL_MPU_Get_AUTHA
  * @param  None
  * @retval RegValue
  */
__STATIC_INLINE uint32_t LL_MPU_Get_AUTHA(MPU_TypeDef *MPUx, uint8_t num)
{
  return (uint32_t)(READ_REG(MPUx->REGION[num].EADDR));
}

/**
  * @brief  LL_MPU_Set_AUTHB
  * @param  None
  * @retval None
  */
__STATIC_INLINE void LL_MPU_Set_AUTHB(MPU_TypeDef *MPUx, uint8_t num,uint32_t val)
{
  WRITE_REG(MPUx->REGION[num].EADDR, val);
}

/**
  * @brief  LL_MPU_Get_AUTHB
  * @param  None
  * @retval RegValue
  */
__STATIC_INLINE uint32_t LL_MPU_Get_AUTHB(MPU_TypeDef *MPUx, uint8_t num)
{
  return (uint32_t)(READ_REG(MPUx->REGION[num].EADDR));
}

/**
  * @brief  LL_MPU_Set_AUTHC
  * @param  None
  * @retval None
  */
__STATIC_INLINE void LL_MPU_Set_AUTHC(MPU_TypeDef *MPUx, uint8_t num,uint32_t val)
{
  WRITE_REG(MPUx->REGION[num].EADDR, val);
}

/**
  * @brief  LL_MPU_Get_AUTHC
  * @param  None
  * @retval RegValue
  */
__STATIC_INLINE uint32_t LL_MPU_Get_AUTHC(MPU_TypeDef *MPUx, uint8_t num)
{
  return (uint32_t)(READ_REG(MPUx->REGION[num].EADDR));
}

/**
  * @brief  LL_MPU_Set_CTRL
  * @param  None
  * @retval None
  */
__STATIC_INLINE void LL_MPU_Set_CTRL(MPU_TypeDef *MPUx, uint8_t num,uint32_t val)
{
  WRITE_REG(MPUx->REGION[num].EADDR, val);
}

/**
  * @brief  LL_MPU_Get_CTRL
  * @param  None
  * @retval RegValue
  */
__STATIC_INLINE uint32_t LL_MPU_Get_CTRL(MPU_TypeDef *MPUx, uint8_t num)
{
  return (uint32_t)(READ_REG(MPUx->REGION[num].EADDR));
}

/**
  * @brief  LL_MPU_Set_SWCTL
  * @param  None
  * @retval None
  */
__STATIC_INLINE void LL_MPU_Set_SWCTL(MPU_TypeDef *MPUx, uint8_t num,uint32_t val)
{
  WRITE_REG(MPUx->REGION[num].EADDR, val);
}

/**
  * @brief  LL_MPU_Get_SWCTL
  * @param  None
  * @retval RegValue
  */
__STATIC_INLINE uint32_t LL_MPU_Get_SWCTL(MPU_TypeDef *MPUx, uint8_t num)
{
  return (uint32_t)(READ_BIT(MPUx->REGION[num].EADDR, SPI_SPSR_RXWCOL) == SPI_SPSR_RXWCOL);
}

/**
  * @brief  MPU_Enable
  * @param  base MPUx
  * @param  enable TURE-MPU enable,FALSE-MPU disable
  * @retval None
  */
__STATIC_INLINE void MPU_Enable(MPU_TypeDef *base, uint8_t enable)
{
  if (enable)
  {
    /* Enable the MPU globally. */
    base->CSR |= MPU_CSR_EN;
  }
  else
  {
    /* Disable the MPU globally. */
    base->CSR &= ~MPU_CSR_EN;
  }
}

void LL_MPU_SetRegionConfig(MPU_TypeDef *base, LL_MPU_RegionTypeDef *regionConfig);
void LL_MPU_SetRegionAddr(MPU_TypeDef *base, uint32_t regionNum, uint32_t startAddr, uint32_t endAddr);
void LL_MPU_SetRegionAccessRights(MPU_TypeDef *base, LL_MPU_RightTypeDef *accessRights);
void LL_MPU_GetErrorAccessInfo(MPU_TypeDef *base, uint32_t slaveNum, LL_MPU_AccessErrTypeDef *errInform);


#ifdef __cplusplus
}
#endif
#endif
/************************ (C) COPYRIGHT FudanMicroelectronics *****END OF FILE****/

