/**
  ******************************************************************************
  * @file    board.c
  * @author  SRG
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"
#include "uart.h"

#define LED2_PIN	LL_GPIO_PIN_1
#define LED3_PIN	LL_GPIO_PIN_2
#define LED_GPIO	GPIOA

#define LOWER_POWER_CTR  LL_BKP_PIN5

#define USERKEY_PIN	  GPIO_PIN_4
#define USERKEY_GPIO	GPIOD

#define TIMx		ST0
#define TIMx_IRQ 	STIMER0_IRQn

extern uint32_t pwm_freq;

void LED_Init(void)
{
	LL_GPIO_InitTypeDef GPIO_InitStruct={0};
	
	GPIO_InitStruct.Pin=LED2_PIN|LED3_PIN;
	GPIO_InitStruct.Alt=LL_GPIO_ALT_GPIO;//TIMER OUT
	GPIO_InitStruct.Dir=LL_GPIO_DIRECTION_OUT;
	GPIO_InitStruct.DriveStrength=LL_GPIO_DRIVES_STRONG;
	GPIO_InitStruct.Irq=LL_GPIO_INTorDMA_DISABLE;
	GPIO_InitStruct.Lock=LL_GPIO_LK_UNLOCK;
	GPIO_InitStruct.OType=LL_GPIO_OUTPUT_NOOPENDRAIN;
	GPIO_InitStruct.PuPd=LL_GPIO_PULL_UP;
	GPIO_InitStruct.Speed=LL_GPIO_SLEWRATE_HIGH;
	GPIO_InitStruct.WECconfig=LL_GPIO_WKUP_CLOSED;
	LL_GPIO_Init(LED_GPIO,&GPIO_InitStruct);
}
void POWER_Init(void)
{
	LL_BKP_EnableVmain2Vbat(BKP_VMAIN);
	LL_BKP_GPIO_Enable();
	LL_BKP_GPIO_SetPinOutputDir(LOWER_POWER_CTR);
	LL_BKP_GPIO_SetOutputPin(LOWER_POWER_CTR);
}
void LED2_On(void)
{
	LL_GPIO_ResetOutputPin(LED_GPIO,LED2_PIN);
}
void LED2_Off(void)
{
	LL_GPIO_SetOutputPin(LED_GPIO,LED2_PIN);
}
void LED2_Toggle(void)
{
	LL_GPIO_TogglePin(LED_GPIO,LED2_PIN);
}

void LED3_On(void)
{
	LL_GPIO_ResetOutputPin(LED_GPIO,LED3_PIN);
}
void LED3_Off(void)
{
	LL_GPIO_SetOutputPin(LED_GPIO,LED3_PIN);
}
void LED3_Toggle(void)
{
	LL_GPIO_TogglePin(LED_GPIO,LED3_PIN);
}

void USERKEY_GPIO_Init(void)
{
	LL_GPIO_InitTypeDef GPIO_InitStruct={0};
	
	GPIO_InitStruct.Pin=USERKEY_PIN;
	GPIO_InitStruct.Alt=LL_GPIO_ALT_GPIO;//pwm
	GPIO_InitStruct.Dir=LL_GPIO_DIRECTION_IN;
	GPIO_InitStruct.DriveStrength=LL_GPIO_DRIVES_STRONG;
	GPIO_InitStruct.Irq=LL_GPIO_INTorDMA_DISABLE;
	GPIO_InitStruct.Lock=LL_GPIO_LK_UNLOCK;
	GPIO_InitStruct.OType=LL_GPIO_OUTPUT_NOOPENDRAIN;
	GPIO_InitStruct.PuPd=LL_GPIO_PULL_UP;
	GPIO_InitStruct.Speed=LL_GPIO_SLEWRATE_HIGH;
	GPIO_InitStruct.WECconfig=LL_GPIO_WKUP_CLOSED;
	LL_GPIO_Init(USERKEY_GPIO,&GPIO_InitStruct);	
	
}

void PWM_GPIOInit(void)//PD3
{
	LL_GPIO_InitTypeDef GPIO_InitStruct={0};
	
	GPIO_InitStruct.Pin=LL_GPIO_PIN_3;
	GPIO_InitStruct.Alt=LL_GPIO_ALT_6;//pwm
	GPIO_InitStruct.Dir=LL_GPIO_DIRECTION_OUT;
	GPIO_InitStruct.DriveStrength=LL_GPIO_DRIVES_STRONG;
	GPIO_InitStruct.Irq=LL_GPIO_INTorDMA_DISABLE;
	GPIO_InitStruct.Lock=LL_GPIO_LK_UNLOCK;
	GPIO_InitStruct.OType=LL_GPIO_OUTPUT_NOOPENDRAIN;
	GPIO_InitStruct.PuPd=LL_GPIO_PULL_NO;
	GPIO_InitStruct.Speed=LL_GPIO_SLEWRATE_HIGH;
	GPIO_InitStruct.WECconfig=LL_GPIO_WKUP_CLOSED;
	LL_GPIO_Init(GPIOD,&GPIO_InitStruct);
}
void stimer0_init(void)//PWM
{
	LL_CMU_SetStimerClkSrc(TIMx,LL_CMU_STCLK_IRC16M);//16MHz
	
	LL_STIM_Disable(TIMx);
	LL_STIM_Reset(TIMx);
	LL_STIM_SetPrescaler(TIMx,LL_TIM_PSC_DIV16);//16MHZ/16=1MHz=1us
	LL_STIM_SetRunMode(TIMx,LL_TIM_MODE_MODCNT);
	LL_STIM_DisableOneshot(TIMx);
	//LL_STIM_EnableOneshot(TIMx);
	LL_STIM_SetMod0Value(TIMx,500000);//200000*1us=0.2s
	LL_STIM_SetTrigOutMode(TIMx,LL_TIM_TR_OUT_HOLD);//LL_TIM_TR_OUT_PULSE;LL_TIM_TR_OUT_HOLD
	LL_STIM_SetTrigInv(TIMx,LL_TIM_TR_OUT_INVERT);//LL_TIM_TR_OUT_NONINVERTED;LL_TIM_TR_OUT_INVERTED
	
	LL_STIM_EnableINT(TIMx);
	NVIC_SetPriority(TIMx_IRQ, 1);
	NVIC_EnableIRQ(TIMx_IRQ);
	
	LL_STIM_Enable(TIMx);
}

void PWM_Freqinit(void)//PWM
{
	pwm_freq +=200;
	if (pwm_freq > 20000 )
		pwm_freq = 100;	
}

void stimer3_init(uint32_t pwmduty)
{
	uint32_t pwm_duty =pwmduty%10000;//���֮
	PWM_GPIOInit();
	USERKEY_GPIO_Init();	
	PWM_Freqinit();	
	
	LL_CMU_SetStimerClkSrc(ST3,LL_CMU_STCLK_IRC16M);//16MHz
	
	LL_STIM_Disable(ST3);
	LL_STIM_Reset(ST3);
	LL_STIM_DisablePrescaler(ST3);
	
	LL_STIM_SetRunMode(ST3,LL_TIM_MODE_PWM);
	LL_STIM_DisableOneshot(ST3);
	LL_STIM_SetMod0Value(ST3,(16*1000000/pwm_freq)/2*pwm_duty/10000);//
	LL_STIM_SetMod1Value(ST3,(16*1000000/pwm_freq)/2*(10000-pwm_duty)/10000);//
	
	LL_STIM_Enable(ST3);
}

uint32_t stimer_getvalue(STn_Type STn)
{
	return LL_STIM_GetCurrentValue(STn);
}
uint32_t reg_val;
extern uint8_t timeout_flag;
void STIMER0_Handler(void)
{
	if(LL_STIM_IsActiveFlag(TIMx))
	{
		Uart_Printf("STIMER0_Handler! \n");	
		timeout_flag=1;		
		LL_STIM_ClearFlag(TIMx);
		//LL_STIM_Disable(ST0);
		//LL_STIM_Disable(ST1);
//		reg_val = LL_STIM_GetCurrentValue(ST1);		
//		Uart_Dump("STIMER->CVAL[ST1] ->=",(uint8_t*)&reg_val,4);	
	}
}

void STIMER3_Handler(void)
{
	if(LL_STIM_IsActiveFlag(ST3))
	{
    reg_val = READ_REG(STIMER->FLAG);
		Uart_Dump("STIMER->FLAG ->=",(uint8_t*)&reg_val,4);	
		//LL_STIM_ClearFlag(ST1);
		reg_val = LL_STIM_GetCurrentValue(ST3);
		Uart_Dump("STIMER->CVAL[ST3] ->=",(uint8_t*)&reg_val,4);	
		Uart_Printf("STIMER1_Handler**************! \n");
		//LL_STIM_Disable(ST1);
		LL_STIM_ClearFlag(ST3);
		
	}
}
