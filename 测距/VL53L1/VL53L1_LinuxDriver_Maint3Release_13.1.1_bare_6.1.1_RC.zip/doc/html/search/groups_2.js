var searchData=
[
  ['st_20ipp_20serialization_20helper',['ST IPP serialization helper',['../group__ipp__serialize.html',1,'']]],
  ['sysfs_20attribute',['sysfs attribute',['../group__sysfs__attrib.html',1,'']]]
];
