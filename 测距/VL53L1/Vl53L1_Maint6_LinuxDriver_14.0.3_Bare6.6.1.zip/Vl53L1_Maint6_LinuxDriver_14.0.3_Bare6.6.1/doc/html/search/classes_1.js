var searchData=
[
  ['roi_5fcfg_5ft',['roi_cfg_t',['../structstmvl53l1__roi__t_1_1roi__cfg__t.html',1,'stmvl53l1_roi_t']]]
];
