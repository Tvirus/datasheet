/**
  ******************************************************************************
  * @file    fm15f3xx_ll_dma.c
  * @author  SRG
  * @version V1.0.0
  * @date    2020-03-17
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "fm15f3xx_ll_dma.h"


/** @addtogroup FM15F3XX_LL_Driver
  * @{
  */



/** @addtogroup DMA_LL
  * @{
  */
/* Exported functions --------------------------------------------------------*/
/** @addtogroup DMA_LL_Exported_Functions
  * @{
  */

/**
  * @brief  Initialize the DMA registers according to the specified parameters in LL_DMA_TransferConfig.
  * @param  Stream This parameter can be one of the following values:
  *         @arg @ref LL_DMA_CHANNEL_0
  *         @arg @ref LL_DMA_CHANNEL_1
  *         @arg @ref LL_DMA_CHANNEL_2
  *         @arg @ref LL_DMA_CHANNEL_3
  *         @arg @ref LL_DMA_CHANNEL_4
  *         @arg @ref LL_DMA_CHANNEL_5
  *         @arg @ref LL_DMA_CHANNEL_6
  *         @arg @ref LL_DMA_CHANNEL_7
  * @param  DMA_TransferStruct pointer to a @ref LL_DMA_TransferConfig structure.
  * @param  NextTcd pointer to a @ref dma_tcd_t structure.
  */
void LL_DMA_Init(uint32_t Channel, LL_DMA_TransferConfig *DMA_TransferStruct, dma_tcd_t *NextTcd)
{
  dma_tcd_t *Tcd = (dma_tcd_t *)&DMA->TCD[Channel];

  LL_DMA_ConfigTcd(Tcd, Channel, DMA_TransferStruct, NextTcd);
}


/**
  * @brief  Initialize the DMA registers according to the specified parameters in LL_DMA_TransferConfig.
  * @param  tcd pointer to a @ref dma_tcd_t structure.
  * @param  Stream This parameter can be one of the following values:
  *         @arg @ref LL_DMA_CHANNEL_0
  *         @arg @ref LL_DMA_CHANNEL_1
  *         @arg @ref LL_DMA_CHANNEL_2
  *         @arg @ref LL_DMA_CHANNEL_3
  *         @arg @ref LL_DMA_CHANNEL_4
  *         @arg @ref LL_DMA_CHANNEL_5
  *         @arg @ref LL_DMA_CHANNEL_6
  *         @arg @ref LL_DMA_CHANNEL_7
  * @param  config pointer to a @ref LL_DMA_TransferConfig structure.
  * @param  nextTcd pointer to a @ref dma_tcd_t structure.
 */
void LL_DMA_ConfigTcd(dma_tcd_t *tcd, uint32_t channel, LL_DMA_TransferConfig * config, dma_tcd_t *nextTcd)
{
  tcd->SADDR = config->SrcAddr;
  tcd->DADDR = config->DestAddr;
  tcd->ATTR = DMA_ATTR_DBURST(config->TcdAttr.DestTransferBurst)   | DMA_ATTR_DSIZE(config->TcdAttr.DestTransferWidth) \
              | DMA_ATTR_SBURST(config->TcdAttr.SrcTransferBurst)  | DMA_ATTR_SSIZE(config->TcdAttr.SrcTransferWidth) \
              | DMA_ATTR_SMOD(config->TcdAttr.Smod)     | DMA_ATTR_DMOD(config->TcdAttr.Dmod);
  tcd->SOFF = config->TcdAttr.SrcOffset;
  tcd->DOFF = config->TcdAttr.DestOffset;

  if (DMA->CR & DMA_CR_EMLM) //小循环使能
  {
    if (config->TcdMinorLoop.SmolEn || config->TcdMinorLoop.DmolEn) //小循环moff存在
    {
      tcd->NBYTES_MLOFFYES = (config->TcdMinorLoop.MinorLoopBytes & 0x3ff);
      if (config->TcdMinorLoop.SmolEn)
        tcd->NBYTES_MLOFFYES |= BIT31;
      if (config->TcdMinorLoop.DmolEn)
        tcd->NBYTES_MLOFFYES |= BIT30;
      tcd->NBYTES_MLOFFYES |= ((config->TcdMinorLoop.Moff & 0xFFFFF) << 10);
    }
    else
    {
      tcd->NBYTES_MLOFFNO = (config->TcdMinorLoop.MinorLoopBytes & 0x3ff); //smole,dmloe,moff全置0
    }
  }
  else
    tcd->NBYTES_MLNO = config->TcdMinorLoop.MinorLoopBytes;


  if (config->TcdMinorLoop.MinorLinkEn)
  {
    tcd->BITER_CITER_ELINKYES = (config->TcdMajorLoop.MajorLoopCounts & 0xfff); //biter赋值,有效位数同citer
    tcd->BITER_CITER_ELINKYES |= ((config->TcdMajorLoop.MajorLoopCounts & 0xfff) << 16); //citer
    tcd->BITER_CITER_ELINKYES |= ((config->TcdMinorLoop.MinorLinkch & 0x7) << 28); //minor_linkch
    tcd->BITER_CITER_ELINKYES |= BIT31; //minor_link enable
  }
  else
  {
    tcd->BITER_CITER_ELINKNO = (config->TcdMajorLoop.MajorLoopCounts & 0x7fff); //biter赋值
    tcd->BITER_CITER_ELINKNO |= ((config->TcdMajorLoop.MajorLoopCounts & 0x7fff) << 16); //citer赋值
  }

  //配置tcd word6
  if (config->TcdMajorLoop.MajorLinkEn)
    tcd->CSR = (BIT11 | (config->TcdMajorLoop.MajorLinkch << 8));
  else
    tcd->CSR = 0;
  if (config->TcdMajorLoop.TcdScatterEn) //scatter
  {
    tcd->CSR |= BIT4;
    tcd->DLAST = (uint16_t)((uint32_t)nextTcd);
    tcd->SLAST = (uint16_t)((uint32_t)nextTcd >> 16);
  }
  else
  {
    tcd->DLAST = config->TcdMajorLoop.DLastSGA; //不scatter, 大循环无offset时置为0
    tcd->SLAST = config->TcdMajorLoop.SLastSGA;
  }
}

void DMA_SetTransferConfig(uint32_t channel, LL_DMA_TransferConfig *config, dma_tcd_t *nextTcd)
{
  dma_tcd_t *tcd = (dma_tcd_t *)&DMA->TCD[channel];
  LL_DMA_ConfigTcd(tcd, channel, config, nextTcd);
}

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT FudanMicroelectronics *****END OF FILE****/
