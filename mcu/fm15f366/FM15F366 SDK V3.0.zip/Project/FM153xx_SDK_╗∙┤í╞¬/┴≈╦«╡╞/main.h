/**
  ********************************** Copyright ********************************* 
  *
  * Copyright (C) 2020, Shanghai Fudan Microelectronics Group Company Limited.
  *                            All Rights Reserved
  *                              
  *    
  * FileName   : main.h
  * Version    : v1.0
  * Author     : SunRongGui
  * Date       : 2020-03-02
  * Description:
  * Change Logs:
    Date                    Author              Notes
    2020-03-02              SunRongGui          first version
  ******************************************************************************
 */
#ifndef __MAIN_H_
#define __MAIN_H_


#ifdef __cplusplus
 extern "C" {
#endif

#include "fm15f3xx.h"






























#ifdef __cplusplus
}
#endif
#endif
