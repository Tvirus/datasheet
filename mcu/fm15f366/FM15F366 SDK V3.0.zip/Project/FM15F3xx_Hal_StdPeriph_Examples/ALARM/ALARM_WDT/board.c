/**
  ******************************************************************************
  * @file    board.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-03-17
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"
#include "uart.h"

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{
    while (1)
    {
    }
}
#endif


void Alarm_WDT_Init(void)
{
    ALM_MonitorInitTypeDef MonitorInit= {0};

#if 0
    //��λ����
    MonitorInit.Monitor  = ALM_MONITOR_GROUPC2_WDT;
    MonitorInit.RecordEn = ALM_MONITOR_RCD_ENABLE;
    MonitorInit.Input    = ALM_MONITOR_INPUT_NORMAL;//;
    MonitorInit.DmaEn    = ALM_MONITOR_DMA_DISABLE;
    MonitorInit.IntEn    = ALM_MONITOR_INT_DISABLE;   //ALM_MONITOR_INT_ENABLE
    MonitorInit.RstEn    = ALM_MONITOR_RST_ENABLE;    //ALM_MONITOR_RST_ENABLE	;ALM_MONITOR_RST_DISABLE
    MonitorInit.Power    = ALM_MONITOR_POWERREST_VDD;
    MonitorInit.Nrst     = ALM_MONITOR_NRST_LOW;
    MonitorInit.Filter   = ALM_MONITOR_FILTER_ENABLE;
    HAL_ALM_ClearAllResetRecord();
#else
    //�жϲ���
    MonitorInit.Monitor  = ALM_MONITOR_GROUPC2_WDT;
    MonitorInit.RecordEn = ALM_MONITOR_RCD_ENABLE;
    MonitorInit.Input    = ALM_MONITOR_INPUT_NORMAL;//;
    MonitorInit.DmaEn    = ALM_MONITOR_DMA_DISABLE;
    MonitorInit.IntEn    = ALM_MONITOR_INT_ENABLE;   //ALM_MONITOR_INT_ENABLE;ALM_MONITOR_INT_DISABLE
    MonitorInit.RstEn    = ALM_MONITOR_RST_DISABLE;    //ALM_MONITOR_RST_ENABLE	;ALM_MONITOR_RST_DISABLE
    MonitorInit.Power    = ALM_MONITOR_POWERREST_VDD;
    MonitorInit.Nrst     = ALM_MONITOR_NRST_LOW;
    MonitorInit.Filter   = ALM_MONITOR_FILTER_ENABLE;
#endif
    HAL_ALM_ClearAllAlarmAndRecord();
    HAL_ALM_MonitorInit(MONITOR_GROUPC, &MonitorInit);
}

void watchdog_init(void)
{
    LL_CMU_SetWDTClkSrc(LL_CMU_WDTCLK_LPO1K);

    LL_WDT_Init(WDT0,LL_WDT_PERIOD_12);
}

void LED_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct= {0};

    GPIO_InitStruct.Pin           = GPIO_PIN_6;
    GPIO_InitStruct.Alt           = LL_GPIO_ALT_GPIO;
    GPIO_InitStruct.Dir           = LL_GPIO_DIRECTION_OUT;
    GPIO_InitStruct.DriveStrength = LL_GPIO_DRIVES_STRONG;
    GPIO_InitStruct.Irq           = LL_GPIO_INTorDMA_DISABLE;
    GPIO_InitStruct.Lock          = LL_GPIO_LK_UNLOCK;
    GPIO_InitStruct.OType         = LL_GPIO_OUTPUT_NOOPENDRAIN;
    GPIO_InitStruct.PuPd          = LL_GPIO_PULL_UP;
    GPIO_InitStruct.Speed         = LL_GPIO_SLEWRATE_HIGH;
    GPIO_InitStruct.WECconfig     = LL_GPIO_WKUP_CLOSED;
    LL_GPIO_Init(GPIOA,&GPIO_InitStruct);
}
void HAL_MspInit(void)
{
    SystemClock_Config();
    UART_Init(115200);
    LED_Init();
    watchdog_init();
    LL_WDT_Start(WDT0);
    Alarm_WDT_Init();
}


void Led_Toggle(void)
{
    LL_GPIO_TogglePin(GPIOA,GPIO_PIN_6);
}


void NMI_Handler(void)
{
    if(HAL_ALM_IsActiveAlarmRecord(MONITOR_GROUPC, LL_ALM_ALARMRESETC_WDT))
    {
        printf("WDT Alarm Int!\r\n");
        LL_WDT_FeedDog(WDT0);
    }
    HAL_ALM_ClearAllAlarmAndRecord();

}
