/**
  ******************************************************************************
  * @file    board.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-03-17
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{
    while (1)
    {
    }
}
#endif

void LED_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct= {0};

    GPIO_InitStruct.Pin           = GPIO_PIN_6;
    GPIO_InitStruct.Alt           = GPIO_AF1_GPIO;
    GPIO_InitStruct.Dir           = GPIO_DIRECTION_OUT;
    GPIO_InitStruct.DriveStrength = GPIO_DRIVES_STRONG;
    GPIO_InitStruct.Irq           = GPIO_IRQorDMA_DISABLE;
    GPIO_InitStruct.Lock          = GPIO_UNLOCK;
    GPIO_InitStruct.OType         = GPIO_OUTPUT_NOOPENDRAIN;
    GPIO_InitStruct.PuPd          = GPIO_PULLUP;
    GPIO_InitStruct.Speed         = GPIO_SLEW_SPEED_HIGH;
    GPIO_InitStruct.WECconfig     = GPIO_WKUP_CLOSED;
    HAL_GPIO_Init(GPIOA,&GPIO_InitStruct);
}

void FREQUENCY_TEST_Init(void)
{
    ALM_BaseTimerInitTypeDef ALM_BaseTimerInitStruct={0};

    ALM_BaseTimerInitStruct.WorkMode      = ALM_BT_WORKMODE_ONESHOT;
    ALM_BaseTimerInitStruct.RefClkCnt     = 1200*1000;
    ALM_BaseTimerInitStruct.FreqAlarmEn   = ALM_BT_FREQALARM_DISABLE;
    HAL_ALM_BaseTimerInit(ALM_BASETIMER_0, &ALM_BaseTimerInitStruct);
}


void HAL_MspInit(void)
{
    SystemClock_Config();
    UART_Init(115200);
    LED_Init();
    FREQUENCY_TEST_Init();
}


void LED_Toggle(void)
{
    LL_GPIO_TogglePin(GPIOA,GPIO_PIN_6);
}

