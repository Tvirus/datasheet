/*
 ******************************************************************************
 * @file    autotest.c
 * @author  weifan
 * @version V1.0.0
 * @date    2020-09-07
 * @brief   Flash autotest case
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
 * All rights reserved.</center></h2>
 *
 ******************************************************************************
 */
#include <string.h>
#include "fm15f3xx_hal_flash.h"
#include "command.h"
#include "autotest.h"

int8_t TEST_WriteReadCheck(uint32_t addr)
{
    int8_t ret;
    uint32_t w_words[MAX_WRITE_WORDS];
    uint32_t r_words[MAX_WRITE_WORDS];
    FLASH_Status status = FLASH_UNKNOWN;

    memset(w_words, MAGIC_NUM, sizeof(w_words));
    status = FLASH_Program(addr, w_words, MAX_WRITE_WORDS);
    if (status != FLASH_COMPLETE)
        return TEST_FAIL;

    FLASH_Read((uint8_t *)addr, (uint8_t *)r_words, sizeof(r_words));
    ret = memcmp(w_words, r_words, sizeof(w_words));
    if (ret)
        return TEST_FAIL;

    return TEST_SUCCESS;
}

int8_t TEST_RewriteWithoutErase(uint32_t addr)
{
    uint32_t words[MAX_WRITE_WORDS];
    FLASH_Status status = FLASH_UNKNOWN;

    memset(words, ~MAGIC_NUM, sizeof(words) / 2);
    memset(words + MAX_WRITE_WORDS / 2, MAGIC_NUM, sizeof(words) / 2);
    status = FLASH_Program(addr, words, MAX_WRITE_WORDS);
    if (status == FLASH_COMPLETE)
        return TEST_FAIL;

    return TEST_SUCCESS;
}

int8_t TEST_Modify(uint32_t addr)
{
    int8_t ret;
    uint8_t w_bytes[MAX_WRITE_WORDS * WORD_SIZE(1)];
    uint8_t r_bytes[MAX_WRITE_WORDS * WORD_SIZE(1)];
    FLASH_Status status = FLASH_UNKNOWN;

    memset(w_bytes, MAGIC_NUM, sizeof(w_bytes));
    status = HAL_FLASH_Modify(addr, w_bytes, sizeof(w_bytes), NULL);
    if (status != FLASH_COMPLETE)
        return TEST_FAIL;

    FLASH_Read((uint8_t *)addr, r_bytes, sizeof(r_bytes));
    ret = memcmp(w_bytes, r_bytes, sizeof(w_bytes));
    if (ret)
        return TEST_FAIL;

    return TEST_SUCCESS;
}


int8_t TEST_SectorEraseCheck(uint32_t addr)
{
    int8_t ret;
    uint32_t e_words[MAX_WRITE_WORDS];
    uint32_t r_words[MAX_WRITE_WORDS];

    memset(e_words, 0xFF, sizeof(e_words));
    FLASH_Read((uint8_t *)addr, (uint8_t *)r_words, sizeof(r_words));
    ret = memcmp(e_words, r_words, sizeof(r_words));
    if (ret)
        return TEST_FAIL;

    return TEST_SUCCESS;
}

int8_t TEST_SectorErase(uint32_t addr)
{
    int8_t ret;
    FLASH_Status status = FLASH_UNKNOWN;

    status = FLASH_Erase(addr, 1, CMD_ERASE_SECTOR);
    if (status != FLASH_COMPLETE)
        return TEST_FAIL;

    ret = TEST_SectorEraseCheck(addr);
    if (ret != TEST_SUCCESS)
        return TEST_FAIL;

    return TEST_SUCCESS;
}

int8_t TEST_BlockErase(uint32_t addr)
{
    int8_t ret;

    addr = FLASH_ALIGN_ADDRESS(addr, FLASH_BLOCK_SIZE);

    ret = TEST_WriteReadCheck(addr);
    if (ret != TEST_SUCCESS)
        return TEST_FAIL;

    ret = TEST_WriteReadCheck(addr + 8 * FLASH_SECTOR_SIZE);
    if (ret != TEST_SUCCESS)
        return TEST_FAIL;

    ret = FLASH_Erase(addr, 1, CMD_ERASE_BLOCK);
    if (ret != FLASH_COMPLETE)
        return TEST_FAIL;

    ret = TEST_SectorEraseCheck(addr);
    if (ret != TEST_SUCCESS)
        return TEST_FAIL;

    ret = TEST_SectorEraseCheck(addr + 8 * FLASH_SECTOR_SIZE);
    if (ret != TEST_SUCCESS)
        return TEST_FAIL;

    return TEST_SUCCESS;
}

