var group__vl53l1__mod__dbg =
[
    [ "IPP_LOG_TIMING", "group__vl53l1__mod__dbg.html#gaf30e046453b9da64124a7b95f38c4ca6", null ],
    [ "STMVL53L1_CFG_ROI_DEBUG", "group__vl53l1__mod__dbg.html#ga7cc74d918465bf879183ac93e6f9e898", null ]
];