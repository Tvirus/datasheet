/**
  ******************************************************************************
  * @file    main.c
  * @author  SRG
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"
#include "uart.h"

/*
Stimer0 0.5sģ���������ƺͲ�ѯ����
STIME3  PWM�����PD3����Ƶ�ʳ�ʼ1.5K��������������Ƶ�ʣ�200Hz������20KHz��ת�� 100Hz
*/
uint32_t pwm_freq = 200;//Hz

uint8_t timeout_flag=0;
int main(void)
{
	uint32_t count=0;
	uint32_t reg_val;
	uint32_t pwmduty=5000;
  init_systick();
	LED_Init();
	POWER_Init();
	UARTx_Init(UART1,115200,LL_UART_STOPSEL_2BIT,LL_UART_PDSEL_N_8);	//115200;9600
	Uart_Printf("STIMER Two ����! \n");	
	
	for(count=0;count<10;count++)
	{
		LED2_Toggle();
		systick_delay_ms(200);
	}
	LED3_Off();
	stimer0_init();
	stimer3_init(pwmduty);
	
	reg_val = READ_REG(STIMER->TGSCH[0]);
	Uart_Dump("STIMER->TGSCH[0] ->=",(uint8_t*)&reg_val,4);	
	reg_val = READ_REG(STIMER->TRINCFG[ST3]);
	Uart_Dump("STIMER->TRINCFG[ST3] ->=",(uint8_t*)&reg_val,4);		
	while(1)
	{
		if(timeout_flag)
		{	
			LED3_Toggle();
			timeout_flag=0;
		}
		
		if((!LL_GPIO_ReadInputDataBit(GPIOD,GPIO_PIN_4))&&timeout_flag)
		{
			//LED2_Toggle();
			LED2_On();
			stimer3_init(pwmduty);
		}
		else
			LED2_Off();
	}
}

