var searchData=
[
  ['userrois',['UserRois',['../structstmvl53l1__roi__t_1_1roi__cfg__t.html#a0c97a352f4a6e88fcf307738b1668c5b',1,'stmvl53l1_roi_t::roi_cfg_t']]]
];
