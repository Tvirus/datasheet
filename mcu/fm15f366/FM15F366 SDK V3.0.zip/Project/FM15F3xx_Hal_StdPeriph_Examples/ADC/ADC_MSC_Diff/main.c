/**
  ******************************************************************************
  * @file    main.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-04-21
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"
#include "uart.h"
#include "fm15f3xx_msc.h"
#include "stdlib.h"
/**
   差分ADC 磁条解码实验
   1.初始化ADC的2个差分通道，Polling顺序0/1/2/3，连续工作模式
   2.等待刷卡，若开始刷卡。将刷卡数据的极值存储起来；
   3.对刷卡数据进行解析。
*/
#define MSC_TrackNum   2
#define MSC_Threshold  5 
int main(void)
{
    int i,j,num[MSC_TrackNum];

    uint8_t* msc[MSC_TrackNum],*p;

    HAL_Init();
  
    DMSC_Init(MSC_TrackNum,MSC_Threshold);
    
    for(i=0;i<MSC_TrackNum;i++)
      msc[i] = (uint8_t*)malloc(7292);


    while(1)
    {
        for(i=0;i<MSC_TrackNum;i++)
          memset(msc[i], 0, 7292);

      
        DMSC_Start(msc,MSC_TrackNum);
      
        for(i=0;i<MSC_TrackNum;i++)
          num[i] = DMSC_Parse(msc[i], MSC_Threshold);  

        for(i=0;i<MSC_TrackNum;i++)
        {
          p = msc[i];
          for(j=0;j<num[i];j++)
              printf("%02X",*p++);
          printf("\n"); 
        }
      
        printf("\n");

    }
}
