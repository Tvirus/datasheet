/**
  ******************************************************************************
  * @file    main.h
  * @author  SRG
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */

#ifndef __MAIN_H_
#define __MAIN_H_


#ifdef __cplusplus
 extern "C" {
#endif

#include "fm15f3xx.h"






#ifdef __cplusplus
}
#endif
#endif
