/**
  ******************************************************************************
  * @file    board.c
  * @author  CLF
  * @version V1.0.0
  * @date    2020-08-27
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"
#include "fm15f3xx_hal_bkp.h"

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{
    while (1)
    {
    }
}
#endif

BKP_HandleTypeDef BKPHandler={0}; //���

void BKP_TamperInit(void)
{
    BKPHandler.Instance = BKP;

    HAL_BKP_Init(&BKPHandler);

    BKP_TamperDetectionTypeDef sTamper = {0};

    sTamper.TamperDetectMode = BKP_TAMPER_STATIC;
    sTamper.FilterClockSource = BKP_FILTERCLKSRC_32768Hz;
    sTamper.FilterWidth = BKP_FILTERWIDTH_0;
    sTamper.FilterEn = BKP_PINFILTER_DISABLE;
    sTamper.PinSampleFreq = BKP_PINSAMPLEFREQ_3;
    sTamper.PinSampleWidth = BKP_PINSAMPLEWIDTH_1;
    sTamper.PinPullSelect = BKP_PINPULLSEL_PULLDOWN;       //��ʽ1
//	sTamper.PinPullSelect = BKP_PINPULLSEL_PULLUP;       //��ʽ2
    sTamper.PinPullEn = BKP_PINPULL_ENABLE;
    sTamper.PinExpectData = BKP_PINEXPECTDATA_LOW;
    sTamper.PinPolarity = BKP_PIN0POLARITY_NEGATIVE;     //��ʽ1
//	sTamper.PinPolarity = BKP_PIN0POLARITY_POSITIVE;   //��ʽ2
    sTamper.PinDirection = BKP_PIN0DIR_INPUT;
    sTamper.Pin = BKP_TAMPER_PIN0;
    sTamper.PinHysterSel = BKP_PINHYSTER_LEVEL0;
    sTamper.PinPassfilterEn = BKP_PINPASSFILTER_DISABLE;
    sTamper.PinDriveStrength = BKP_PINDRISTRENGTH_HIGH;
    sTamper.PinSlewRate = BKP_PINSLEW_FAST;
    sTamper.TamperPinEn = BKP_TAMPER_0;
    sTamper.TamperIntEn = BKP_INT_TAMPER_0;

    HAL_BKP_TamperInit(&BKPHandler,&sTamper);
}
void LED_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct={0};

    GPIO_InitStruct.Pin=GPIO_PIN_7 | GPIO_PIN_1;
    GPIO_InitStruct.Alt=LL_GPIO_ALT_GPIO;
    GPIO_InitStruct.Dir=LL_GPIO_DIRECTION_OUT;
    GPIO_InitStruct.DriveStrength=LL_GPIO_DRIVES_STRONG;
    GPIO_InitStruct.Irq=LL_GPIO_INTorDMA_DISABLE;
    GPIO_InitStruct.Lock=LL_GPIO_LK_UNLOCK;
    GPIO_InitStruct.OType=LL_GPIO_OUTPUT_NOOPENDRAIN;
    GPIO_InitStruct.PuPd=LL_GPIO_PULL_UP;
    GPIO_InitStruct.Speed=LL_GPIO_SLEWRATE_HIGH;
    GPIO_InitStruct.WECconfig=LL_GPIO_WKUP_CLOSED;
    LL_GPIO_Init(GPIOA,&GPIO_InitStruct);
}

void HAL_MspInit(void)
{
    SystemClock_Config();
    LED_Init();
}

void HAL_BKP_StaticTamperInit(void)
{
    BKP_TamperInit();
    LL_BKP_OpenTamperPass(BKP_PASSFLAG_TAMPER_0);


    NVIC_SetPriority(BKP_Tamper_IRQn,1);
    NVIC_EnableIRQ(BKP_Tamper_IRQn);
}

void Test_Low(void)
{
    LL_GPIO_SetOutputPin(GPIOA,GPIO_PIN_1);//��ʽ1
    //LL_GPIO_ResetOutputPin(GPIOA,GPIO_PIN_1);//��ʽ2
}

void LED2_Off(void)
{
    LL_GPIO_SetOutputPin(GPIOA,GPIO_PIN_7);
}


void BKP_Tamper_Handler(void)
{
    HAL_BKP_TamperIRQHandler(&BKPHandler);
}

void HAL_BKP_TamperIRQHandler(BKP_HandleTypeDef *hbkp)
{
    if(__HAL_BKP_TAMPER_ISAVTIVE_FLAG(hbkp,BKP_FLAG_TAMPER_0))
    {
        HAL_BKP_TamperEventCallback(hbkp);
        __HAL_BKP_TAMPER_CLEAR_FLAG(hbkp,BKP_FLAG_TAMPER_0);
    }
}

void HAL_BKP_TamperEventCallback(BKP_HandleTypeDef *hbkp)
{
    LED2_Off();
}


