/**
  ******************************************************************************
  * @file    main.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-04-21
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"
#include "uart.h"
/**
   ADC 轮训转换实验 
   1.初始化ADC 
   2.软件触发ADC，轮训等待转换完毕
*/
int main(void)
{
    uint16_t a = 0;
    HAL_Init();
    printf("ADC Polling Demo!");
    while(1)
    {
        HAL_Delay(1000);

        LED_Toggle();
        a = Get_Adc_Average(ADC_CHANNEL_0,10);
        printf("VDD_BKP_Value %d \r\n",a);

    }
}
