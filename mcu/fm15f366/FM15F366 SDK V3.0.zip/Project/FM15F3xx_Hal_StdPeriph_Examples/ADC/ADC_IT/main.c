/**
  ******************************************************************************
  * @file    main.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-04-21
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"
#include "uart.h"
/**
   ADC 中断触发实验 
   1.初始化ADC
   2.初始化STIMER0
   3.由STIMER0进入中断后，软件触发ADC开始转换。
*/
int main(void)
{
    HAL_Init();

    HAL_Delay(1000);
    Get_StartADC_IT(0);
    while(1)
    {
        HAL_Delay(1000);
        LED_Toggle();
    }
}
