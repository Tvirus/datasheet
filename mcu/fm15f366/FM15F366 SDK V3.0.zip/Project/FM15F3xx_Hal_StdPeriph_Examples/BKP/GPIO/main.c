/**
  ******************************************************************************
  * @file    main.c
  * @author  CLF
  * @version V1.0.0
  * @date    2020-8-28
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"

/*

BKP GPIOG0 ����ͨ�õ�GPIO����ڣ�GPIOA6��Ϊ����ڣ�GPIOG1�ڿ���GPIO6��״̬�ķ�ת
��Ҫ������ʽΪLED2����˸��

*/

int main(void)
{
    HAL_Init();
    HAL_MspInit();

    while(1)
    {
        HAL_Delay(1000);
        GPIOSet();
        HAL_Delay(1000);
        GPIOClear();
    }
}


