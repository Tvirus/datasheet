var searchData=
[
  ['sysfs_20attribute',['sysfs attribute',['../group__sysfs__attrib.html',1,'']]]
];
