var searchData=
[
  ['stmvl53l1_5fipp_5fproccesing_5fe',['stmvl53l1_ipp_proccesing_e',['../group__ipp__serialize.html#ga416fa593ec8f689b6c62365998f95797',1,'stmvl53l1_ipp.h']]],
  ['stmvl53l1_5fipp_5fstatus_5fe',['stmvl53l1_ipp_status_e',['../group__ipp__serialize.html#ga5d468459d0cd080311ca32d191f1612d',1,'stmvl53l1_ipp.h']]]
];
