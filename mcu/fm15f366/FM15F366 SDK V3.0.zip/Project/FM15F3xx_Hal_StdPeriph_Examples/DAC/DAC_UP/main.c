/**
  ******************************************************************************
  * @file    main.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-04-21
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"
#include "uart.h"
/**
   DAC UP模式实验
   1.初始化DAC；
   2.设置DAC，输出对应电压；
  */
int main(void)
{
    HAL_Init();
    while(1)
    {
        DAC_Convert();
        LED_Toggle();
        HAL_Delay(100);
    }

}
