/**
  ******************************************************************************
  * @file    board.c
  * @author  SRG
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "bsp_board.h"

#define LED2_PIN	LL_GPIO_PIN_6
#define LED3_PIN	LL_GPIO_PIN_7
#define LED_GPIO	GPIOA


void LED_Init(void)
{
	LL_GPIO_InitTypeDef GPIO_InitStruct={0};
	
	GPIO_InitStruct.Pin=LED2_PIN|LED3_PIN;
	GPIO_InitStruct.Alt=LL_GPIO_ALT_GPIO;
	GPIO_InitStruct.Dir=LL_GPIO_DIRECTION_OUT;
	GPIO_InitStruct.DriveStrength=LL_GPIO_DRIVES_STRONG;
	GPIO_InitStruct.Irq=LL_GPIO_INTorDMA_DISABLE;
	GPIO_InitStruct.Lock=LL_GPIO_LK_UNLOCK;
	GPIO_InitStruct.OType=LL_GPIO_OUTPUT_NOOPENDRAIN;
	GPIO_InitStruct.PuPd=LL_GPIO_PULL_UP;
	GPIO_InitStruct.Speed=LL_GPIO_SLEWRATE_HIGH;
	GPIO_InitStruct.WECconfig=LL_GPIO_WKUP_CLOSED;
	LL_GPIO_Init(LED_GPIO,&GPIO_InitStruct);
}

void LED_Toggle(void)
{
	LL_GPIO_TogglePin(LED_GPIO,LED2_PIN|LED3_PIN);
}
void LED2_Toggle(void)
{
	LL_GPIO_TogglePin(LED_GPIO,LED2_PIN);
}
void LED3_Toggle(void)
{
	LL_GPIO_TogglePin(LED_GPIO,LED3_PIN);
}
void LED2_OFF(void)
{
	LL_GPIO_SetOutputPin(LED_GPIO,LED2_PIN);
}

void LED2_ON(void)
{
	LL_GPIO_ResetOutputPin(LED_GPIO,LED2_PIN);
}
void LED3_OFF(void)
{
	LL_GPIO_SetOutputPin(LED_GPIO,LED3_PIN);
}

void LED3_ON(void)
{
	LL_GPIO_ResetOutputPin(LED_GPIO,LED3_PIN);
}


/*********************************************************************************************************
** ��������:	UserKey_Init
** ��������:	������ʼ��
** �������:  ��
** �������:  ��
** ����ֵ:		��
*********************************************************************************************************/
void UserKey_Init(void)
{
	  LL_GPIO_InitTypeDef GPIO_InitStruct={0};

		GPIO_InitStruct.Pin					   = LL_GPIO_PIN_4;	
		GPIO_InitStruct.Alt					   = LL_GPIO_ALT_1;
		GPIO_InitStruct.PuPd 				   = LL_GPIO_PULL_UP;
		GPIO_InitStruct.Speed 			   = LL_GPIO_SLEWRATE_LOW;
		GPIO_InitStruct.OType		       = LL_GPIO_OUTPUT_NOOPENDRAIN;	
		GPIO_InitStruct.Dir 				   = LL_GPIO_DIRECTION_IN;		

    LL_GPIO_Init(GPIOD,&GPIO_InitStruct);		//LT-PD4-gpio    
}

/*********************************************************************************************************
** ��������:	UserKey_GetData
** ��������:	��ȡ����
** �������:  ��
** �������:  ��
** ����ֵ:		��
*********************************************************************************************************/
uint8_t UserKey_GetData(void)
{
    return LL_GPIO_ReadInputDataBit(GPIOD,LL_GPIO_PIN_4);		//PD4-gpio    
}
