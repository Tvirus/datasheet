/**
  ******************************************************************************
  * @file    board.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-03-17
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"
#include "uart.h"

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{
    while (1)
    {
    }
}
#endif

extern void DecToBCD(uint32_t Dec, uint8_t *Bcd, uint32_t length) ;


CRC_HandleTypeDef CRC_Handler={0};

void LED_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct={0};

    GPIO_InitStruct.Pin=GPIO_PIN_6;
    GPIO_InitStruct.Alt=LL_GPIO_ALT_GPIO;
    GPIO_InitStruct.Dir=LL_GPIO_DIRECTION_OUT;
    GPIO_InitStruct.DriveStrength=LL_GPIO_DRIVES_STRONG;
    GPIO_InitStruct.Irq=LL_GPIO_INTorDMA_DISABLE;
    GPIO_InitStruct.Lock=LL_GPIO_LK_UNLOCK;
    GPIO_InitStruct.OType=LL_GPIO_OUTPUT_NOOPENDRAIN;
    GPIO_InitStruct.PuPd=LL_GPIO_PULL_UP;
    GPIO_InitStruct.Speed=LL_GPIO_SLEWRATE_HIGH;
    GPIO_InitStruct.WECconfig=LL_GPIO_WKUP_CLOSED;
    LL_GPIO_Init(GPIOA,&GPIO_InitStruct);
}

void CRC_Init(void)
{
    CRC_Handler.Instance = CRC;
    HAL_CRC_Init(&CRC_Handler);
}
void HAL_MspInit(void)
{
    SystemClock_Config();
    LED_Init();
    UART_Init(115200);
    CRC_Init();
}

void LED_Toggle(void)
{
    LL_GPIO_TogglePin(GPIOA,GPIO_PIN_6);
}


uint16_t CRC16_CCITT(uint8_t *buffer, uint32_t length)
{

    CRC_Handler.Init.Init = 0x0000;
    CRC_Handler.Init.XorOut = 0x0000;
    CRC_Handler.Init.RefIn = TRUE;
    CRC_Handler.Init.RefOut = TRUE;
    return HAL_CRC16_Calculate(&CRC_Handler, buffer, length);
}

uint16_t CRC16_CCITT_FALSE(uint8_t *buffer, uint32_t length)
{

    CRC_Handler.Init.Init = 0xFFFF;
    CRC_Handler.Init.XorOut = 0x0000;
    CRC_Handler.Init.RefIn = FALSE;
    CRC_Handler.Init.RefOut = FALSE;
    return HAL_CRC16_Calculate(&CRC_Handler, buffer, length);
}

uint16_t CRC16_XMODEM(uint8_t *buffer, uint32_t length)
{

    CRC_Handler.Init.Init = 0x0000;
    CRC_Handler.Init.XorOut = 0x0000;
    CRC_Handler.Init.RefIn = FALSE;
    CRC_Handler.Init.RefOut = FALSE;
    return HAL_CRC16_Calculate(&CRC_Handler, buffer, length);
}

uint16_t CRC16_X25(uint8_t *buffer, uint32_t length)
{

    CRC_Handler.Init.Init = 0xFFFF;
    CRC_Handler.Init.XorOut = 0xFFFF;
    CRC_Handler.Init.RefIn = TRUE;
    CRC_Handler.Init.RefOut = TRUE;
    return HAL_CRC16_Calculate(&CRC_Handler, buffer, length);
}


