/**
  ******************************************************************************
  * @file    uart.c
  * @author  weifan
  * @version V1.0.0
  * @date    2020-09-01
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "uart.h"

#if EN_UARTx_RX
uint8_t UART_RX_BUF[UART_REC_LEN]; //用户接收缓存

//bit15：接收到0XD
//bit14~0：接收到的有效字节
__IO uint16_t UART_RX_STA = 0;     //接收状态

//bit15：可发送标志
//bit14~0：可发送的有效字节
__IO uint16_t UART_TX_STA = 0;     //发送状态

uint8_t RxBuffer[RXBUFFERSIZE];    //HAL库使用串口接收缓存
#endif
UART_HandleTypeDef UARTx_Handler;  //UARTx句柄

//重定义fputc函数
int fputc(int ch, FILE *f)
{
  while ((UARTx->STATUS & 0X70) == 0x40); //TXFIFO若满，则等待
  UARTx->TXFIFO = (uint8_t)ch;
  return ch;
}

/**
  * @brief  Uart Init
  * @param  baudrate
  * @retval none
  */
void UART_Init(uint32_t baudrate)
{
  UARTx_Handler.Instance = UARTx;
  UARTx_Handler.Init.BaudRate = baudrate;
  UARTx_Handler.Init.StopBits = UART_STOPBITS_1;
  UARTx_Handler.Init.WordLength = UART_WORDLENGTH_8B_NONE;
  UARTx_Handler.Init.TransferMode = UART_TRANSFER_TX_RX;
  HAL_UART_Init(&UARTx_Handler);

#if EN_UARTx_RX
  HAL_UART_Receive_IT(&UARTx_Handler, (uint8_t *)RxBuffer, RXBUFFERSIZE);
#endif
}

//UART底层初始化，时钟、引脚、中断
//此函数会被HAL_UART_Init()调用
void HAL_UART_MspInit(UART_HandleTypeDef *handle)
{
  GPIO_InitTypeDef GPIO_InitStruct;
  HAL_CMU_ModuleClockConfig(CMU_MODULE_UART, CMU_UARTCLKSRC_IRC16M, CMU_CLKDIVGP1_1);

  if (handle->Instance == UARTx)
  {
    GPIO_InitStruct.Pin = UARTx_TX | UARTx_RX;
    GPIO_InitStruct.Alt = UARTx_AF;
    GPIO_InitStruct.PuPd = GPIO_NOPULL;
    HAL_GPIO_Init(UARTx_PORT, &GPIO_InitStruct);

#if EN_UARTx_RX
    HAL_NVIC_SetPriority(UARTx_IRQ, 3, 0U);
    HAL_NVIC_EnableIRQ(UARTx_IRQ);
#endif
  }

}

void UART_SendByte(uint8_t c)
{
  HAL_UART_Transmit(&UARTx_Handler, (uint8_t *)&c, 1, 1000);
}

#if EN_UARTx_RX
//中断服务函数
void UARTx_INT_HANDLER(void)
{
  HAL_UART_IRQHandler(&UARTx_Handler);//调用HAL库中断处理函数
}

uint16_t UART_RxReady(void)
{
  return UART_RX_STA & RX_END_MASK;
}

uint16_t UART_RxLength(void)
{
  return UART_RX_STA & RX_LENGTH_MASK;
}

static void IncRxLen(void)
{
  UART_RX_STA++;
}

static void DecRxLen(void)
{
  UART_RX_STA--;
}

static void RxEnd(void)
{
  UART_RX_BUF[UART_RxLength()] = '\0';
  UART_RX_STA |= RX_END_MASK;
}

void UART_ClearRx(void)
{
  UART_RX_STA = 0;
}

void Button_EnterProcess(void)
{
  // 接收的数据以'\r'回车结尾
  UART_SendByte(BUTTON_NEXTLINE);
  if (UART_RxLength())
    RxEnd();
}

void Button_DeleteProcess(void)
{
  if (UART_RxLength())
    DecRxLen();
}

void Button_DefaultProcess(char c)
{
  UART_RX_BUF[UART_RxLength()] = c;
  IncRxLen();
  if(UART_RxLength() >= (UART_REC_LEN - 1))
  {
    RxEnd(); // 接收缓冲满
    UART_SendByte(BUTTON_ENTER);
    UART_SendByte(BUTTON_NEXTLINE);
  }
}

void UARTx_ReceiveProcess(char c)
{
  switch (c)
  {
  case BUTTON_ENTER:
    Button_EnterProcess();
    break;
  case BUTTON_DELETE:
    Button_DeleteProcess();
    break;
  case BUTTON_NEXTLINE: // nop
    break;
  default:
    Button_DefaultProcess(c);
    break;
  }
}

void Show_StartupInfo(void)
{
  printf(STARTUP_INFO);
}

void Show_Commands(void)
{
  printf(COMMAND_INFO);
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *handle)
{
  if(handle->Instance == UARTx)
  {
    HAL_UART_Receive_IT(handle, (uint8_t *)RxBuffer, RXBUFFERSIZE);
    HAL_UART_Transmit(handle, (uint8_t *)RxBuffer, RXBUFFERSIZE, 1000); // 回显
    UARTx_ReceiveProcess(RxBuffer[0]);
  }
}
#endif
