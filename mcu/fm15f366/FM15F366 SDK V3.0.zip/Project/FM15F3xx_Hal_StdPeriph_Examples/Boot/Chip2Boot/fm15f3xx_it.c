/**
  ******************************************************************************
  * @file    fm15f3xx_it.c
  * @author
  * @version V1.0.0
  * @date    14-November-2017
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and
  *          peripherals interrupt service routine.
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "fm15f3xx_conf.h"
#include "fm15f3xx_hal.h"
#include "fm15f3xx_it.h"

/** @addtogroup FM15f3XX_Template
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M3 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief  This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{
}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler(void)
{
  HAL_IncTick();
}

/******************************************************************************/
/*                 FM15F3XX Peripherals Interrupt Handlers                       */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_fm15f3xx.s).                                               */
/******************************************************************************/

/************************************************************************/
/*函数名:Isr_Monitor                                                   */
/*功能说明:安全监测中断服务程序                                       */
/************************************************************************/
void MONITOR_Handler(void)
{
}

/************************************************************************/
/*函数名:Isr_PM                                                   */
/*功能说明:PM中断服务程序                                       */
/************************************************************************/
void PM_Int_Handler(void)
{
}

/************************************************************************/
/*函数名:Isr_ATIMER_Count                                               */
/*功能说明:ATIMER_Count中断服务程序                                     */
/************************************************************************/
void ATIMER_Count_Handler(void)
{
}

/************************************************************************/
/*函数名:GPIOA_Handler                                                  */
/*功能说明:GPIOA_Handler断服务程序,测试芯片各种电平中断及沿中断         */
/************************************************************************/
void GPIOA_Handler(void)
{
}
void GPIOB_Handler(void)
{

}
void GPIOC_Handler(void)
{

}
void GPIOD_Handler(void)
{

}
void GPIOE_Handler(void)
{

}
void GPIOF_Handler(void)
{

}

/************************************************************************/
/*函数名:I2C0_Handler                                                   */
/*功能说明:I2C0_Handler断服务程序                                       */
/************************************************************************/
void I2C0_Handler(void)
{
}
/**
  * @}
  */
/************************************************************************/
/*函数名:RTC_Time_Handler                                               */
/*功能说明:RTC_Time_Handler断服务程序                                   */
/************************************************************************/
void RTC_Time_Handler(void)
{
}

/**
  * @}
  */
/************************************************************************/
/*函数名:RTC_Second_Handler                                             */
/*功能说明:RTC_Second_Handler                                           */
/************************************************************************/
void RTC_Second_Handler(void)
{
}

/************************************************************************/
/*函数名:FSMC_Handler                                                   */
/*功能说明:FSMC_Handler                                                 */
/************************************************************************/
void FSMC_Handler(void)
{
}


