/**
  ******************************************************************************
  * @file    main.c
  * @author  SRG
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "bsp_board.h"
#include "uart.h"
#include <stdio.h>

void sdelay_ms(uint32_t ms)
{
	int i,j;
	for(i=0;i<ms;i++)
		for(j=0;j<4000;j++);
}

int main(void)
{
	uint32_t count=0;
	LED_Init();
	POWER_Init();
	UARTx_Init(UART1,115200,LL_UART_STOPSEL_1BIT,LL_UART_PDSEL_N_8);
	printf("UART Initial success!\n\r");
	while(1)
	{
		for(count=0;count<10;count++)
		{
			LED2_Toggle();
			sdelay_ms(500);
		}
		LED3_Off();
		for(count=0;count<10;count++)
		{
			LED3_Toggle();
			sdelay_ms(500);
		}
		sdelay_ms(1000);
		LED_Toggle();
	}
}
