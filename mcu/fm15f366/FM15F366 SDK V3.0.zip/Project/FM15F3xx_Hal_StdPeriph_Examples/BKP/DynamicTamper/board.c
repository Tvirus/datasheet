/**
  ******************************************************************************
  * @file    board.c
  * @author  CLF
  * @version V1.0.0
  * @date    2020-08-26
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"
#include "fm15f3xx_hal_bkp.h"

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{
    while (1)
    {
    }
}
#endif

BKP_HandleTypeDef BKPHandler={0}; //���

void BKP_TamperInit(void)
{
    BKPHandler.Instance = BKP;

    HAL_BKP_Init(&BKPHandler);

    BKP_TamperDetectionTypeDef sTamperOutput = {0};

    sTamperOutput.TamperDetectMode = BKP_TAMPER_DYNAMIC;
    sTamperOutput.FilterClockSource = BKP_FILTERCLKSRC_32768Hz;
    sTamperOutput.FilterWidth = BKP_FILTERWIDTH_0;
    sTamperOutput.FilterEn = BKP_PINFILTER_DISABLE;
    sTamperOutput.PinSampleFreq = BKP_PINSAMPLEFREQ_3;
    sTamperOutput.PinSampleWidth = BKP_PINSAMPLEWIDTH_1;
    sTamperOutput.PinPullSelect = BKP_PINPULLSEL_PULLUP;
    sTamperOutput.PinPullEn = BKP_PINPULL_DISABLE;
    sTamperOutput.PinExpectData = BKP_PINEXPECTDATA_A0XORA1;
    sTamperOutput.PinPolarity = BKP_PIN1POLARITY_POSITIVE;
    sTamperOutput.PinDirection = BKP_PIN1DIR_OUTPUT;
    sTamperOutput.Pin = BKP_TAMPER_PIN1;
    sTamperOutput.PinHysterSel = BKP_PINHYSTER_LEVEL0;
    sTamperOutput.PinPassfilterEn = BKP_PINPASSFILTER_DISABLE;
    sTamperOutput.PinDriveStrength = BKP_PINDRISTRENGTH_HIGH;
    sTamperOutput.PinSlewRate = BKP_PINSLEW_SLOW;
    sTamperOutput.LFSRIntialValue = 0x0121;
    sTamperOutput.LFSRTap = BKP_ACTIVELFSR0_TAP2;
    sTamperOutput.TamperActiveLFSRx = BKP_TAMPER_ACTIVE_LFSR0;
    HAL_BKP_TamperInit(&BKPHandler,&sTamperOutput);

    BKP_TamperDetectionTypeDef sTamperInput = {0};

    sTamperInput.TamperDetectMode = BKP_TAMPER_DYNAMIC;
    sTamperInput.FilterClockSource = BKP_FILTERCLKSRC_32768Hz;
    sTamperInput.FilterWidth = BKP_FILTERWIDTH_0;
    sTamperInput.FilterEn = BKP_PINFILTER_DISABLE;
    sTamperInput.PinSampleFreq = BKP_PINSAMPLEFREQ_3;
    sTamperInput.PinSampleWidth = BKP_PINSAMPLEWIDTH_1;
    sTamperInput.PinPullSelect = BKP_PINPULLSEL_PULLUP;
    sTamperInput.PinPullEn = BKP_PINPULL_DISABLE;
    sTamperInput.PinExpectData = BKP_PINEXPECTDATA_A0XORA1;
    sTamperInput.PinPolarity = BKP_PIN0POLARITY_POSITIVE;
    sTamperInput.PinDirection = BKP_PIN0DIR_INPUT;
    sTamperInput.Pin = BKP_TAMPER_PIN0;
    sTamperInput.PinHysterSel = BKP_PINHYSTER_LEVEL0;
    sTamperInput.PinPassfilterEn = BKP_PINPASSFILTER_DISABLE;
    sTamperInput.PinDriveStrength = BKP_PINDRISTRENGTH_HIGH;
    sTamperInput.PinSlewRate = BKP_PINSLEW_SLOW;
    sTamperInput.TamperPinEn = BKP_TAMPER_0;
    sTamperInput.TamperIntEn = BKP_INT_TAMPER_0;
    sTamperInput.LFSRIntialValue = 0x0001;
    sTamperInput.LFSRTap = BKP_ACTIVELFSR0_TAP2;
    sTamperInput.TamperActiveLFSRx = BKP_TAMPER_ACTIVE_LFSR1;

    HAL_BKP_TamperInit(&BKPHandler,&sTamperInput);



}
void LED_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct={0};

    GPIO_InitStruct.Pin=GPIO_PIN_7 | GPIO_PIN_1;
    GPIO_InitStruct.Alt=LL_GPIO_ALT_GPIO;
    GPIO_InitStruct.Dir=LL_GPIO_DIRECTION_OUT;
    GPIO_InitStruct.DriveStrength=LL_GPIO_DRIVES_STRONG;
    GPIO_InitStruct.Irq=LL_GPIO_INTorDMA_DISABLE;
    GPIO_InitStruct.Lock=LL_GPIO_LK_UNLOCK;
    GPIO_InitStruct.OType=LL_GPIO_OUTPUT_NOOPENDRAIN;
    GPIO_InitStruct.PuPd=LL_GPIO_PULL_UP;
    GPIO_InitStruct.Speed=LL_GPIO_SLEWRATE_HIGH;
    GPIO_InitStruct.WECconfig=LL_GPIO_WKUP_CLOSED;
    LL_GPIO_Init(GPIOA,&GPIO_InitStruct);
}

void HAL_MspInit(void)
{
    SystemClock_Config();
    LED_Init();
}

void HAL_BKP_StaticTamperInit(void)
{
    BKP_TamperInit();
    LL_BKP_OpenTamperPass(BKP_PASSFLAG_TAMPER_0);

    NVIC_SetPriority(BKP_Tamper_IRQn,0);
    NVIC_EnableIRQ(BKP_Tamper_IRQn);
}

void Test_Low(void)
{
    LL_GPIO_ResetOutputPin(GPIOA,GPIO_PIN_1);
}

void LED2_Off(void)
{
    LL_GPIO_SetOutputPin(GPIOA,GPIO_PIN_7);
}


void BKP_Tamper_Handler(void)
{
    HAL_BKP_TamperIRQHandler(&BKPHandler);
}

void HAL_BKP_TamperIRQHandler(BKP_HandleTypeDef *hbkp)
{
    if(__HAL_BKP_TAMPER_ISAVTIVE_FLAG(hbkp,BKP_FLAG_TAMPER_0))
    {
        HAL_BKP_TamperEventCallback(hbkp);
        __HAL_BKP_TAMPER_CLEAR_FLAG(hbkp,BKP_FLAG_TAMPER_0);
    }
}

void HAL_BKP_TamperEventCallback(BKP_HandleTypeDef *hbkp)
{
    LED2_Off();
}


