/**
  ******************************************************************************
  * @file    board.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"
#include "uart.h"

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{ 
	while (1)
	{
	}
}
#endif

ADC_HandleTypeDef ADC_Handler;//ADC���

void ADC_Init(void)
{
	ADC_ChannelConfigTypeDef ADC_ChanConf={0};	
	GPIO_InitTypeDef GPIO_InitStruct={0};
	
	GPIO_InitStruct.Pin	= GPIO_PIN_2;
	GPIO_InitStruct.Alt	= GPIO_AF0_ADC;
	GPIO_InitStruct.PuPd= GPIO_PULLUP;
	HAL_GPIO_Init(GPIOD,&GPIO_InitStruct);		//PD2 ADC_IN10	

	//ADC����
	LL_CMU_ConfigADCClk(LL_CMU_ADCCLK_IRC16M,LL_CMU_REUSEDIV1_DIV8);
	LL_CMU_IDLE_OpenModuleClk(LL_CMU_MDCLK_ADC);	
	ADC_Handler.Instance    = ADC0;
	ADC_Handler.Init.ClkSel = ADC_CLKSEL_WORKCLKDIV1;	
	
	ADC_Handler.Init.WorkMode    = ADC_WORKMODE_POLLING;	//ADC_WorkMode_Polling;ADC_WorkMode_FreeTrig
	ADC_Handler.Init.ConvertMode = ADC_CONVMODE_CONTINUE;	//ADC_ConvMode_Continue;ADC_ConvMode_OneShot
	ADC_Handler.Init.ReadyTime   = 0;
	ADC_Handler.Init.SampleTime  = 96;
	ADC_Handler.Init.AutoSleepEn = ADC_AUTOSLEEP_DISABLE;
	ADC_Handler.Init.VcomEn      = ADC_VCOM_DISABLE;	

	ADC_Handler.Init.PollingNum = 3;//polling 4ch
	
	HAL_ADC_Init(&ADC_Handler);
	
	//������ѯ����
	LL_ADC_SetPollSequence(ADC0,LL_ADC_POLLSEQUENCE0_CH0|LL_ADC_POLLSEQUENCE1_CH1|LL_ADC_POLLSEQUENCE2_CH2|LL_ADC_POLLSEQUENCE3_CH3);                     
 	
	LL_ADC_SetPollDelay(ADC0,5);

	//ADCͨ������
	ADC_ChanConf.Channel   = ADC_CHANNEL_0;                          
	ADC_ChanConf.Input     = ADC_INSRC_VDDBKP;     	
	ADC_ChanConf.TrigSrc   = ADC_TRIGSRC_SOFTWARE;
	ADC_ChanConf.TrigDelay = 0;
	ADC_ChanConf.DiffEn    = ADC_CHxDIFF_DISABLE;
	ADC_ChanConf.TrigInvEn = ADC_CHxTRIGINV_DISABLE;
	HAL_ADC_ChannelConfig(&ADC_Handler,&ADC_ChanConf);  
	
	ADC_ChanConf.Channel   = ADC_CHANNEL_1;                          
	ADC_ChanConf.Input     = ADC_INSRC_VREF12;     	
	ADC_ChanConf.TrigSrc   = ADC_TRIGSRC_SOFTWARE;
	ADC_ChanConf.TrigDelay = 0;
	ADC_ChanConf.DiffEn    = ADC_CHxDIFF_DISABLE;
	ADC_ChanConf.TrigInvEn = ADC_CHxTRIGINV_DISABLE;
	HAL_ADC_ChannelConfig(&ADC_Handler,&ADC_ChanConf);    

	ADC_ChanConf.Channel   = ADC_CHANNEL_2;                          
	ADC_ChanConf.Input     = ADC_INSRC_TEMPERATURE;     	
	ADC_ChanConf.TrigSrc   = ADC_TRIGSRC_SOFTWARE;
	ADC_ChanConf.TrigDelay = 0;
	ADC_ChanConf.DiffEn    = ADC_CHxDIFF_DISABLE;
	ADC_ChanConf.TrigInvEn = ADC_CHxTRIGINV_DISABLE;
	HAL_ADC_ChannelConfig(&ADC_Handler,&ADC_ChanConf);    
	
	ADC_ChanConf.Channel   = ADC_CHANNEL_3;                          
	ADC_ChanConf.Input     = ADC_INSRC_ADC10; 
	ADC_ChanConf.TrigSrc   = ADC_TRIGSRC_SOFTWARE;
	ADC_ChanConf.TrigDelay = 0;
	ADC_ChanConf.DiffEn    = ADC_CHxDIFF_DISABLE;
	ADC_ChanConf.TrigInvEn = ADC_CHxTRIGINV_DISABLE;
	HAL_ADC_ChannelConfig(&ADC_Handler,&ADC_ChanConf);    
}


void ADCChannel_PD2_Init(uint8_t Channel)
{
	ADC_ChannelConfigTypeDef ADC_ChanConf={0};
	ADC_DataProcessConfigTypeDef  ADC_ProcessConfig={0};
	
	HAL_ADC_Stop(&ADC_Handler); //ADC_CTRL[ADCEN]=0ʱ�ſ������µĲ���
		//ADC��������
	ADC_ProcessConfig.Channel      = Channel;
	ADC_ProcessConfig.AverageEn    = ADC_CHxAVERAGE_DISABLE;//DISABLE;ENABLE
	ADC_ProcessConfig.AverageNum   = ADC_AVGNUM_6;
	ADC_ProcessConfig.OffsetEn     = ADC_CHxOFFSET_DISABLE;
	ADC_ProcessConfig.OffsetValue  = 0x800A;     
	ADC_ProcessConfig.CompareEn    = ADC_CHxCOMPARE_DISABLE;
	
	HAL_ADC_DataProcrssConfig(&ADC_Handler,&ADC_ProcessConfig);
	
	ADC_ChanConf.Channel    = Channel;                          
	ADC_ChanConf.Input      = ADC_INSRC_ADC10;     	
	ADC_ChanConf.TrigSrc    = ADC_TRIGSRC_SOFTWARE;
	ADC_ChanConf.TrigDelay  = 0;
	ADC_ChanConf.DiffEn     = ADC_CHxDIFF_DISABLE;
	ADC_ChanConf.TrigInvEn  = ADC_CHxTRIGINV_DISABLE;
	HAL_ADC_ChannelConfig(&ADC_Handler,&ADC_ChanConf);        //ͨ������
}

void LED_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct={0};
	
	GPIO_InitStruct.Pin=GPIO_PIN_6;
	GPIO_InitStruct.Alt=LL_GPIO_ALT_GPIO;
	GPIO_InitStruct.Dir=LL_GPIO_DIRECTION_OUT;
	GPIO_InitStruct.DriveStrength=LL_GPIO_DRIVES_STRONG;
	GPIO_InitStruct.Irq=LL_GPIO_INTorDMA_DISABLE;
	GPIO_InitStruct.Lock=LL_GPIO_LK_UNLOCK;
	GPIO_InitStruct.OType=LL_GPIO_OUTPUT_NOOPENDRAIN;
	GPIO_InitStruct.PuPd=LL_GPIO_PULL_UP;
	GPIO_InitStruct.Speed=LL_GPIO_SLEWRATE_HIGH;
	GPIO_InitStruct.WECconfig=LL_GPIO_WKUP_CLOSED;
	LL_GPIO_Init(GPIOA,&GPIO_InitStruct);
}

void HAL_MspInit(void)
{
	SystemClock_Config();
	LED_Init();
	ADC_Init();
}


void LED_Toggle(void)
{
	LL_GPIO_TogglePin(GPIOA,GPIO_PIN_6);
}

//���ADCֵ
//ch: ͨ��ֵ 0~3��ȡֵ��ΧΪ��ADC_Channel_0~ADC_Channel_3
//����ֵ:ת�����
void VREF12_En(void)   
{
	WRITE_REG(VREF->TRIM,0x08ab+14);//trim vref12
	__HAL_ADC_ENABLE_VREF12();	    //vref12 enable
}


#define ADC_VREFH_VALUE  3248  // VREFH = VDDA

//����4ͨ��adc polling������ӡ���
void ADC_Test(void)
{
	uint32_t reg_val,DATA[10][4];	
	uint32_t i,j;	
	
	VREF12_En();
	/* Start ADC Conversion*/
	HAL_ADC_Start(&ADC_Handler, ADC_CHANNEL_0); //����ADCת��		
	Uart_Printf("ADC0->STATUSRCD_VALUE ->= ",j);
	for(i=0;i<10;i++)
	{
		if(HAL_OK !=HAL_ADC_PollForConversion(&ADC_Handler ,ADC_CHANNEL_0, 1000))
		{	
				Uart_Printf("ADC Conversion Error! \n");
			  reg_val = READ_REG(ADC0->STATUSRCD);
				Uart_Dump("ADC->STATUSRCD_VALUE ->=",(uint8_t*)&reg_val,2);
				return ;
		}	

	  reg_val = READ_REG(ADC0->STATUSRCD);
		
	  Uart_Printf(" %04X",reg_val);
		
		HAL_ADC_Polling_GetValue(&ADC_Handler ,DATA[i]);
		
		DATA[i][0] = 4*ADC_VREFH_VALUE*DATA[i][0]/4096;
		for(j=1;j<4;j++)
		{
			DATA[i][j] = ADC_VREFH_VALUE*DATA[i][j]/4096;
		}
	}	
	Uart_Printf("\n");	
	for(j=0;j<4;j++)
	{
		Uart_Printf("ADC_Ch[%d]_Value ->= \n",j);
		for(i=0;i<10;i++)
		{
			Uart_Printf(" %4d",DATA[i][j]);
		}
		Uart_Printf("\n");		
	}
	
	Uart_Printf("\n");
	
	/* Disalbe VREF12 */
  __HAL_ADC_DISABLE_VREF12();		
	HAL_ADC_Stop(&ADC_Handler);
	return ;
	
} 

