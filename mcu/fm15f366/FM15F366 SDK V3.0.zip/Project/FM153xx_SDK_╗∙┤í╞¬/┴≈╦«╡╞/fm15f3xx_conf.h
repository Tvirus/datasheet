/**
  ******************************************************************************
  * @file    fm15f3xx_conf.h
  * @author  SRG
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#ifndef __FM15F3XX_CONF_H_
#define __FM15F3XX_CONF_H_

#ifdef __cplusplus
 extern "C" {
#endif

// <<< Use Configuration Wizard in Context Menu >>>

//<c>BKP
//#include "fm15f3xx_ll_bkp.h"
//</c>

//<c>CMP
//#include "fm15f3xx_ll_cmp.h"
//</c>

//<c>DAC
//#include "fm15f3xx_ll_dac.h"
//</c>

//<c>DMA
//#include "fm15f3xx_ll_dma.h"
//</c>

//<c>FLASH
//#include "fm15f3xx_ll_flash.h"
//</c>

//<c>GPIO
#include "fm15f3xx_ll_gpio.h"
//</c>

//<c>RTC
//#include "fm15f3xx_ll_rtc.h"
//</c>

//<c>SPI
//#include "fm15f3xx_ll_spi.h"
//</c>

//<c>STIMER
//#include "fm15f3xx_ll_stimer.h"
//</c>

//<c>WDT
//#include "fm15f3xx_ll_wdt.h"
//</c>

//<c>ADC
//#include "fm15f3xx_ll_adc.h"
//</c>

//<c>ALARM
//#include "fm15f3xx_ll_alarm.h"
//</c>

//<c>CMU
#include "fm15f3xx_ll_cmu.h"
//</c>

//<c>CT
//#include "fm15f3xx_ll_ct.h"
//</c>

//<c>DCMI
//#include "fm15f3xx_ll_dcmi.h"
//</c>

//<c>FSMC
//#include "fm15f3xx_ll_fsmc.h"
//</c>

//<c>I2C
//#include "fm15f3xx_ll_i2c.h"
//</c>

//<c>LPTIMER
//#include "fm15f3xx_ll_lptimer.h"
//</c>

//<c>PMU
//#include "fm15f3xx_ll_pmu.h"
//</c>

//<c>QSPI
//#include "fm15f3xx_ll_qspi.h"
//</c>

//<c>UART
//#include "fm15f3xx_ll_uart.h"
//</c>

//<c>CRC
//#include "fm15f3xx_ll_crc.h"
//</c>





























//<<< end of configration section >>>

#ifdef __cplusplus
}
#endif
#endif

