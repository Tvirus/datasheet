/**
  ******************************************************************************
  * @file    fm15f3xx_hal_mpu.h
  * @author  SRG
  * @version V1.0.0
  * @date    2020-03-17
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */

#ifndef FM15F3XX_HAL_MPU_H
#define FM15F3XX_HAL_MPU_H
#ifdef __cplusplus
extern "C" {
#endif

/** @addtogroup FM15F3xx_HAL_Driver
  * @{
  */

/** @addtogroup MPU
  * @{
  */

/* Exported types ------------------------------------------------------------*/
/** @defgroup MPU_Exported_Types MPU Exported Types
  * @{
  */

#include "fm15f3xx.h"

/* Private types -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private constants ---------------------------------------------------------*/
/* Private macros ------------------------------------------------------------*/
/* ExSPIed functions --------------------------------------------------------*/
/*! @brief MPU region config. */
typedef struct
{
  uint32_t RegionNum;          /*!< Specifies the region number.*/
  uint32_t StartAddress;       /*!< Specifies the start address.*/
  uint32_t EndAddress;         /*!< Specifies the start address.*/
  uint32_t AccessRights1;      /*!< Specifies the access right1.*/
  uint32_t AccessRights2;      /*!< Specifies the access right2.*/
  uint32_t AccessRights3;      /*!< Specifies the access right3.*/
  uint32_t SetCtrl;            /*!< Specifies the set ctrl reg.*/
  uint32_t SetSwCtl;           /*!< Specifies the set swctl reg.*/
} HAL_MPU_RegionTypeDef;

/*! @brief MPU region right config. */
typedef struct
{
  uint32_t RegionNum;          /*!< Specifies the region number.*/
  uint32_t AccessRights1;      /*!< Specifies the access right1.*/
  uint32_t AccessRights2;      /*!< Specifies the access right2.*/
  uint32_t AccessRights3;      /*!< Specifies the access right3.*/
  uint32_t SetCtrl;            /*!< Specifies the set ctrl reg.*/
  uint32_t SetSwCtl;           /*!< Specifies the set swctl reg.*/
} HAL_MPU_RightTypeDef;

/*! @brief MPU detail error access information. */
typedef struct
{
  uint32_t Status;             /*!< Specifies the status.*/
  uint32_t Address;            /*!< Specifies the address.*/
  uint32_t Details;            /*!< Specifies the details.*/
} HAL_MPU_AccessErrTypeDef;

/* Private macros ------------------------------------------------------------*/
/** @defgroup MPU_Private_Macros MPU Private Macros
  * @{
  */
#define MPU_REGION_COUNT          (8U)  /*!< MPU region count */
#define MPU_ACCESS_RIGHT_N        0x00  /*!< MPU access right none */

#define MPU_REGION_NUM_0          0x00  /*!< MPU region0 */
#define MPU_REGION_NUM_1          0x01  /*!< MPU region1 */
#define MPU_REGION_NUM_2          0x02  /*!< MPU region2 */
#define MPU_REGION_NUM_3          0x03  /*!< MPU region3 */
#define MPU_REGION_NUM_4          0x04  /*!< MPU region4 */
#define MPU_REGION_NUM_5          0x05  /*!< MPU region5 */
#define MPU_REGION_NUM_6          0x06  /*!< MPU region6 */
#define MPU_REGION_NUM_7          0x07  /*!< MPU region7 */

#define MPU_REGION_DMA_DSP_N      0x00  /*!< MPU region dma dsp right none */
#define MPU_REGION_SJUMPE_N       0x00  /*!< MPU region sjumpe right none */

/** @defgroup MPU Private macros to check input parameters
  * @{
  */
#define IS_MPU_ALL_INSTANCE(INSTANCE) ((INSTANCE) == MPU)
#define IS_MPU_RIGHT(RIGHT)   (((RIGHT) == MPU_AUTHA_DSPWA) || \
                               ((RIGHT) == MPU_AUTHA_DSPRA) || \
                               ((RIGHT) == MPU_AUTHA_DMAWA) || \
                               ((RIGHT) == MPU_AUTHA_DMARA) || \
                               ((RIGHT) == MPU_AUTHB_R0UPX) || \
                               ((RIGHT) == MPU_AUTHB_R0UPW) || \
                               ((RIGHT) == MPU_AUTHB_R0UPR) || \
                               ((RIGHT) == MPU_AUTHB_R0PX)  || \
                               ((RIGHT) == MPU_AUTHB_R0PW)  || \
                               ((RIGHT) == MPU_AUTHB_R0PR)  || \
                               ((RIGHT) == MPU_AUTHB_R1UPX) || \
                               ((RIGHT) == MPU_AUTHB_R1UPW) || \
                               ((RIGHT) == MPU_AUTHB_R1UPR) || \
                               ((RIGHT) == MPU_AUTHB_R1PX)  || \
                               ((RIGHT) == MPU_AUTHB_R1PW)  || \
                               ((RIGHT) == MPU_AUTHB_R1PR)  || \
                               ((RIGHT) == MPU_AUTHB_R2UPX) || \
                               ((RIGHT) == MPU_AUTHB_R2UPW) || \
                               ((RIGHT) == MPU_AUTHB_R2UPR) || \
                               ((RIGHT) == MPU_AUTHB_R2PX)  || \
                               ((RIGHT) == MPU_AUTHB_R2PW)  || \
                               ((RIGHT) == MPU_AUTHB_R2PR)  || \
                               ((RIGHT) == MPU_AUTHB_R3UPX) || \
                               ((RIGHT) == MPU_AUTHB_R3UPW) || \
                               ((RIGHT) == MPU_AUTHB_R3UPR) || \
                               ((RIGHT) == MPU_AUTHB_R3PX)  || \
                               ((RIGHT) == MPU_AUTHB_R3PW)  || \
                               ((RIGHT) == MPU_AUTHB_R3PR)  || \
                               ((RIGHT) == MPU_AUTHC_R4UPX) || \
                               ((RIGHT) == MPU_AUTHC_R4UPW) || \
                               ((RIGHT) == MPU_AUTHC_R4UPR) || \
                               ((RIGHT) == MPU_AUTHC_R4PX)  || \
                               ((RIGHT) == MPU_AUTHC_R4PW)  || \
                               ((RIGHT) == MPU_AUTHC_R4PR)  || \
                               ((RIGHT) == MPU_AUTHC_R5UPX) || \
                               ((RIGHT) == MPU_AUTHC_R5UPW) || \
                               ((RIGHT) == MPU_AUTHC_R5UPR) || \
                               ((RIGHT) == MPU_AUTHC_R5PX)  || \
                               ((RIGHT) == MPU_AUTHC_R5PW)  || \
                               ((RIGHT) == MPU_AUTHC_R5PR)  || \
                               ((RIGHT) == MPU_AUTHC_R6UPX) || \
                               ((RIGHT) == MPU_AUTHC_R6UPW) || \
                               ((RIGHT) == MPU_AUTHC_R6UPR) || \
                               ((RIGHT) == MPU_AUTHC_R6PX)  || \
                               ((RIGHT) == MPU_AUTHC_R6PW)  || \
                               ((RIGHT) == MPU_AUTHC_R6PR)  || \
                               ((RIGHT) == MPU_AUTHC_R7UPX) || \
                               ((RIGHT) == MPU_AUTHC_R7UPW) || \
                               ((RIGHT) == MPU_AUTHC_R7UPR) || \
                               ((RIGHT) == MPU_AUTHC_R7PX)  || \
                               ((RIGHT) == MPU_AUTHC_R7PW)  || \
                               ((RIGHT) == MPU_AUTHC_R7PR))

/**
  * @}
  */

/* Private functions ---------------------------------------------------------*/
/** @defgroup MPU_Private_Functions MPU Private Functions
  * @{
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/** @addtogroup MPU_Exported_Functions_Group1
* @{
*/
void HAL_MPU_SetRegionConfig(MPU_TypeDef *base, HAL_MPU_RegionTypeDef *regionConfig);
void HAL_MPU_SetRegionAddr(MPU_TypeDef *base, uint32_t regionNum, uint32_t startAddr, uint32_t endAddr);
void HAL_MPU_SetRegionAccessRights(MPU_TypeDef *base, HAL_MPU_RightTypeDef *accessRights);
void HAL_MPU_GetErrorAccessInfo(MPU_TypeDef *base, uint32_t slaveNum, HAL_MPU_AccessErrTypeDef *errInform);


#ifdef __cplusplus
}
#endif
#endif /* FM15F3XX_HAL_MPU_H */
/************************ (C) COPYRIGHT FudanMicroelectronics *****END OF FILE****/
