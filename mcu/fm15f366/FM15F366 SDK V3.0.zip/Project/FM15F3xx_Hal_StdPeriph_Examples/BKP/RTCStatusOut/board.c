/**
  ******************************************************************************
  * @file    board.c
  * @author  CLF
  * @version V1.0.0
  * @date    2020-08-27
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"
#include "time.h"
#include "fm15f3xx_ll_bkp.h"

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{
    while (1)
    {
    }
}
#endif

BKP_HandleTypeDef BKPHandler={0};
RTC_HandleTypeDef RTCHandler={0};

void BKP_GPIOInit(void)
{
    BKPHandler.Instance = BKP;

    HAL_BKP_Init(&BKPHandler);

    BKP_GPIOTypeDef sGpio;
    sGpio.GpioMode = BKP_GPIO_PIN_RTC_STATUS;
    sGpio.Pin = BKP_GPIO_PIN0;
    sGpio.PinInvEn = BKP_PIN_INV_ENABLE;
    sGpio.PinODEn = BKP_PIN_OD_ENABLE;
    sGpio.WakupType = BKP_RTC_ALARM_RECORD;

    HAL_BKP_GPIOInit(&BKPHandler,&sGpio);
}

void LED_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct={0};

    GPIO_InitStruct.Pin=GPIO_PIN_7;
    GPIO_InitStruct.Alt=LL_GPIO_ALT_GPIO;
    GPIO_InitStruct.Dir=LL_GPIO_DIRECTION_IN;
    GPIO_InitStruct.DriveStrength=LL_GPIO_DRIVES_STRONG;
    GPIO_InitStruct.Irq=LL_GPIO_INTorDMA_DISABLE;
    GPIO_InitStruct.Lock=LL_GPIO_LK_UNLOCK;
    GPIO_InitStruct.OType=LL_GPIO_OUTPUT_NOOPENDRAIN;
    GPIO_InitStruct.PuPd=LL_GPIO_PULL_UP;
    GPIO_InitStruct.Speed=LL_GPIO_SLEWRATE_HIGH;
    GPIO_InitStruct.WECconfig=LL_GPIO_WKUP_CLOSED;
    LL_GPIO_Init(GPIOA,&GPIO_InitStruct);
}

void LED2_Off(void)
{
    LL_GPIO_SetOutputPin(GPIOA,GPIO_PIN_7);
}

void RTC_Config(void)
{
    RTCHandler.State = HAL_RTC_STATE_RESET;
    RTCHandler.TimePrescaler = 32768U;
    RTCHandler.Instance = RTC_TIME;
    HAL_RTC_Init(&RTCHandler);
    HAL_RTC_MspInit(&RTCHandler);

    RTC_TimeTypeDef sTime;

    sTime.Year = 2020;
    sTime.Month = 1 ;
    sTime.Date = 1 ;
    sTime.Hours = 0;
    sTime.Minutes = 0;
    sTime.Seconds = 0;

    HAL_RTC_SetTime(&RTCHandler,&sTime);

    RTC_AlarmTypeDef sTimeAlarm = {0};
    sTimeAlarm.AlarmType = RTC_ALARM_SECONDS;

    sTimeAlarm.AlarmTime.Year = 2020;
    sTimeAlarm.AlarmTime.Month = 1;
    sTimeAlarm.AlarmTime.Date = 1;
    sTimeAlarm.AlarmTime.Hours = 0;
    sTimeAlarm.AlarmTime.Minutes = 0;
    sTimeAlarm.AlarmTime.Seconds = 5;

    HAL_RTC_SetAlarmTime(&RTCHandler,&sTimeAlarm);
}

void HAL_MspInit(void)
{
    SystemClock_Config();
    LED_Init();
    BKP_GPIOInit();
    RTC_Config();
}

