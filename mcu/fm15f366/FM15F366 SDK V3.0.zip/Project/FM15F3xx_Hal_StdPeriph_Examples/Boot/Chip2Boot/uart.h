/**
  ******************************************************************************
  * @file    uart.h
  * @author  weifan
  * @version V1.0.0
  * @date    2020-09-01
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */

#ifndef __UART_H_
#define __UART_H_
#include "fm15f3xx_conf.h"
#include <stdio.h>
#include <string.h>
#include "flash.h"

#ifdef __cplusplus
extern "C" {
#endif

#define EN_UARTx_RX    1  // 使能（1）/禁止（0）串口接收

#if EN_UARTx_RX
#define RX_END_MASK    0x8000
#define RX_LENGTH_MASK 0x7fff
#endif

/* 调试串口配置 */
#define UARTx                 UART1 // 调试串口
#define UARTx_PORT            GPIOF
#define UARTx_TX              GPIO_PIN_3
#define UARTx_RX              GPIO_PIN_4
#define UARTx_AF              GPIO_AF3_UART1
#define UARTx_IRQ             UART1_IRQn
#define UARTx_INT_HANDLER     UART1_Handler
#define UARTx_BAUDRATE        115200

#define UART_REC_LEN   64 // 定义最大接收字节数
#define RXBUFFERSIZE   1  // 缓存大小

#define BUTTON_ENTER    '\r'
#define BUTTON_NEXTLINE '\n'
#define BUTTON_DELETE   0x7F

#define _str(s) #s
#define str(s)  _str(s)

#define YELLOW_COLOR  "\033[33m"
#define RED_COLOR     "\033[31m"
#define GREEN_COLOR   "\033[32m"
#define DEFAULT_THEME "\033[0m"

#define COMMAND_INFO \
  GREEN_COLOR \
  "\n\r命令:\n\r" \
  "\t" str(CMD_READ)        "       读flash\n\r" \
  "\t" str(CMD_ERASE_BLOCK)"/"str(CMD_ERASE_SECTOR) \
                                "   擦flash\n\r" \
  "\t" str(CMD_WRITE)       "       写flash\n\r" \
  "\t" str(CMD_AUTOTEST)    "       测试flash\n\r" \
  "\t" str(CMD_HELP)        "       帮助\n\r" \
  DEFAULT_THEME

#define STARTUP_INFO \
  RED_COLOR \
  "\n\rProduct: FM15F3xx flash demo\n\r" \
  "Component: HAL library\n\r" \
  "Software supplied by: fudan microelectronics\n\r" \
  COMMAND_INFO \
  DEFAULT_THEME

extern uint8_t UART_RX_BUF[UART_REC_LEN]; // 接收缓冲,最大USART_REC_LEN个字节.末字节为'\0'符
extern __IO uint16_t UART_RX_STA;         // 接收状态标记
extern __IO uint16_t UART_TX_STA;         // 发送状态标记
extern UART_HandleTypeDef UARTx_Handler;  // UART1句柄
extern uint8_t RxBuffer[RXBUFFERSIZE];    // HAL库UART接收Buffer

//如果想串口中断接收
void UART_Init(uint32_t baudrate);
uint16_t UART_RxReady(void);
uint16_t UART_RxLength(void);
void UART_ClearRx(void);
void Show_StartupInfo(void);
void Show_Commands(void);

#ifdef __cplusplus
}
#endif
#endif
