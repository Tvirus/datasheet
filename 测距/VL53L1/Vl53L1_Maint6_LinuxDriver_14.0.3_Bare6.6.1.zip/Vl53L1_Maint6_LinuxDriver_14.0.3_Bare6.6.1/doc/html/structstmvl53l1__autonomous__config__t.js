var structstmvl53l1__autonomous__config__t =
[
    [ "config", "structstmvl53l1__autonomous__config__t.html#a1f46c927d52ac8de294632fbd22efd25", null ],
    [ "is_read", "structstmvl53l1__autonomous__config__t.html#a35c4ee5c8d6459784a7f4ede103d9477", null ],
    [ "pollingTimeInMs", "structstmvl53l1__autonomous__config__t.html#a1349bd63ce8621ce44a7ddafedb70915", null ]
];