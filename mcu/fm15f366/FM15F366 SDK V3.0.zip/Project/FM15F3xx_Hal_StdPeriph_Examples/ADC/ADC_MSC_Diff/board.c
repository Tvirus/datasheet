/**
  ******************************************************************************
  * @file    board.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-03-17
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"
#include "uart.h"

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{
    while (1)
    {
    }
}
#endif


ADC_HandleTypeDef ADC_Handler={0};//ADC���
void ADC_Init(void)
{
    ADC_ChannelConfigTypeDef ADC_ChxConf= {0};

    //ADC����
    ADC_Handler.Instance         = ADC0;
    ADC_Handler.Init.ClkSel      = ADC_CLKSEL_BUSCLKDIV2;//16M
    ADC_Handler.Init.WorkMode    = ADC_WORKMODE_POLLING;
    ADC_Handler.Init.ConvertMode = ADC_CONVMODE_CONTINUE;	//ADC_CONVMODE_CONTINUE;ADC_CONVMODE_ONESHOT
    ADC_Handler.Init.ReadyTime   = 0x400;
    ADC_Handler.Init.SampleTime  = 6;
    ADC_Handler.Init.AutoSleepEn = ADC_AUTOSLEEP_DISABLE;
    ADC_Handler.Init.VcomEn      = ADC_VCOM_ENABLE;
    ADC_Handler.Init.PollingNum  = 1;
    HAL_ADC_Init(&ADC_Handler);

    //������ѯ����
    LL_ADC_SetPollSequence(ADC0,LL_ADC_POLLSEQUENCE0_CH0|LL_ADC_POLLSEQUENCE1_CH1);
    //������ѯDelay
    LL_ADC_SetPollDelay(ADC0, 0);

    //ͨ������
    ADC_ChxConf.TrigSrc   = ADC_TRIGSRC_SOFTWARE;
    ADC_ChxConf.TrigDelay = 0;
    ADC_ChxConf.DiffEn    = ADC_CHxDIFF_ENABLE;
    ADC_ChxConf.TrigInvEn = ADC_CHxTRIGINV_DISABLE;

    //Channel 0
    ADC_ChxConf.Channel   = ADC_CHANNEL_0;
    ADC_ChxConf.Input     = ADC_INSRC_DP2;
    HAL_ADC_ChannelConfig(&ADC_Handler,&ADC_ChxConf);

    //Channel 1
    ADC_ChxConf.Channel   = ADC_CHANNEL_1;
    ADC_ChxConf.Input     = ADC_INSRC_DP1;
    HAL_ADC_ChannelConfig(&ADC_Handler,&ADC_ChxConf);
    //Channel 2
//    ADC_ChxConf.Channel   = ADC_CHANNEL_2;
//    ADC_ChxConf.Input     = ADC_INSRC_DP0;
//    HAL_ADC_ChannelConfig(&ADC_Handler,&ADC_ChxConf);
}


void LED_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct= {0};

    GPIO_InitStruct.Pin           = GPIO_PIN_6;
    GPIO_InitStruct.Alt           = GPIO_AF1_GPIO;
    GPIO_InitStruct.Dir           = GPIO_DIRECTION_OUT;
    GPIO_InitStruct.DriveStrength = GPIO_DRIVES_STRONG;
    GPIO_InitStruct.Irq           = GPIO_IRQorDMA_DISABLE;
    GPIO_InitStruct.Lock          = GPIO_UNLOCK;
    GPIO_InitStruct.OType         = GPIO_OUTPUT_NOOPENDRAIN;
    GPIO_InitStruct.PuPd          = GPIO_PULLUP;
    GPIO_InitStruct.Speed         = GPIO_SLEW_SPEED_HIGH;
    GPIO_InitStruct.WECconfig     = GPIO_WKUP_CLOSED;
    HAL_GPIO_Init(GPIOA,&GPIO_InitStruct);
}

void HAL_MspInit(void)
{
    SystemClock_Config();
    UART_Init(115200);
    LED_Init();
    ADC_Init();
}


void LED_Toggle(void)
{
    LL_GPIO_TogglePin(GPIOA,GPIO_PIN_6);
}


void ADC0_Handler(void)
{
    HAL_ADC_IRQHandler(&ADC_Handler, ADC_CHANNEL_1);
}


void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc,uint32_t channel)
{

}

