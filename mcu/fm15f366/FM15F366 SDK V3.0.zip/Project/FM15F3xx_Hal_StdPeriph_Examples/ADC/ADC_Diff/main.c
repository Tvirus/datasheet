/**
  ******************************************************************************
  * @file    main.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-04-21
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"
#include "uart.h"
#include "stdlib.h"
/**
   ���ADC ʵ��
   1.��ʼ��ADC������Ϊ���ģʽ
   2.����ADC��ʼת��
*/

int main(void)
{
    uint32_t v;

    HAL_Init();
    printf("ADC���");
    for(int i=0; i<100; i++)
    {
        HAL_ADC_Start(&ADC_Handler, ADC_CHANNEL_0); //����ADCת��
        v = HAL_ADC_GetValue(&ADC_Handler,ADC_CHANNEL_0);
        printf("ADC Diff Value:%d\n",v);
    }
    HAL_ADC_Stop(&ADC_Handler);


    while(1)
    {
        LED_Toggle();
        HAL_Delay(1000);
    }

}
