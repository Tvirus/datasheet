var searchData=
[
  ['camera_5fcci',['CAMERA_CCI',['../stmvl53l1__dox_8h.html#ab6490961c8d607cf5b64d26b6846a9ba',1,'CAMERA_CCI():&#160;stmvl53l1_dox.h'],['../stmvl53lx__dox_8h.html#ab6490961c8d607cf5b64d26b6846a9ba',1,'CAMERA_CCI():&#160;stmvl53lx_dox.h']]],
  ['cfg_5fstmvl53l1_5fhave_5fregulator',['CFG_STMVL53L1_HAVE_REGULATOR',['../stmvl53l1__dox_8h.html#ae0343d2cdbe4fda7e873e91d6465f1c1',1,'stmvl53l1_dox.h']]],
  ['cfg_5fstmvl53lx_5fhave_5fregulator',['CFG_STMVL53LX_HAVE_REGULATOR',['../stmvl53lx__dox_8h.html#a2ab933eac3e38bc77fd33437e0e58ca7',1,'stmvl53lx_dox.h']]]
];
