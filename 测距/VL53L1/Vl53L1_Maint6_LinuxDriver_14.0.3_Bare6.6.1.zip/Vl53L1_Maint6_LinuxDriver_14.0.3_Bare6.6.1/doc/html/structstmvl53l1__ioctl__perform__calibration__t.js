var structstmvl53l1__ioctl__perform__calibration__t =
[
    [ "calibration_type", "structstmvl53l1__ioctl__perform__calibration__t.html#ae2097da2c0406bb02825d4898b8d0b5b", null ],
    [ "param1", "structstmvl53l1__ioctl__perform__calibration__t.html#a6621f08544dff2366a62f6e9177c6591", null ],
    [ "param2", "structstmvl53l1__ioctl__perform__calibration__t.html#aa965ccb1db002d24e067bb3fb0cb8a30", null ],
    [ "param3", "structstmvl53l1__ioctl__perform__calibration__t.html#a0c365e6abc4d8168a67fcabd0ffba433", null ]
];