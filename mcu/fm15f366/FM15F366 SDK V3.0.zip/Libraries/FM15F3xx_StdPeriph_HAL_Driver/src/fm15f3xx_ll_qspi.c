/**
  ******************************************************************************
  * @file    fm15f3xx_ll_qspi.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-03-17
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "fm15f3xx_ll_qspi.h"

#if defined (QSPI)
/* Private types -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private constants ---------------------------------------------------------*/

/* Private macros ------------------------------------------------------------*/

/**
  * @brief  Set each @ref LL_QSPI_StructInit field to default value.
  * @param  QSPI_InitTypeDef pointer to a @ref QSPI_InitTypeDef structure
  * whose fields will be set to default values.
  * @retval None
  */
void LL_QSPI_StructInit(LL_QSPI_InitTypeDef* QSPIInitStruct)
{
  QSPIInitStruct->WorkMode	       = LL_QSPI_WORK_INDIRECT;
  QSPIInitStruct->AccessFlash      = LL_QSPI_ACCESS_FLASHA;
  QSPIInitStruct->SpeedMode        = LL_QSPI_SPEED_SDR;
  QSPIInitStruct->EndianMode  	   = LL_QSPI_ENDIAN_LITTLE;
  QSPIInitStruct->SignificantBit   = LL_QSPI_RxFIFO_LSB;
  QSPIInitStruct->IoMode           = LL_QSPI_IO_HIGH;
  QSPIInitStruct->SampleShift      = LL_QSPI_SAMPLESHIFT_NONE;
  QSPIInitStruct->SamplePoint      = LL_QSPI_SAMPLEPOINT_DISABLE;
  QSPIInitStruct->ClkMode          = LL_QSPI_CLK_MODE0;
  QSPIInitStruct->ClkDiv           = LL_QSPI_CLK_DIV2;
  QSPIInitStruct->RxfifoWm         = 4;
  QSPIInitStruct->TxfifoWm         = 4;
  QSPIInitStruct->QuitStallCnt     = LL_QSPI_STALL_QUITCNT_DISABLE;
}

/**
  * @brief Initialize the QSPI mode according to the specified parameters
  *        in the QSPI_InitTypeDef and initialize the associated handle.
  * @param QSPI Instance
  * @param QSPI_InitStruct
  * @retval None
  */
void LL_QSPI_Init(QSPI_TypeDef *QSPIx, LL_QSPI_InitTypeDef* QSPI_InitStruct)
{
  /* Configure QSPI CGF */
  MODIFY_REG(QSPIx->CFG, 0x27, QSPI_InitStruct->AccessFlash |QSPI_InitStruct->SpeedMode);

  /* Configure QSPI Data Order */
  MODIFY_REG(QSPIx->DORDER, 0xC, QSPI_InitStruct->EndianMode | QSPI_InitStruct->SignificantBit);

  /* Configure QSPI mode */
  MODIFY_REG(QSPIx->MODE, 0xB, QSPI_InitStruct->WorkMode | QSPI_InitStruct->IoMode);

  /* Configure QSPI SAMPLE */
  MODIFY_REG(QSPIx->SAMPCFG, 0x3F,QSPI_InitStruct->SamplePoint | QSPI_InitStruct->SampleShift);

  /* Configure QSPI Clock Prescaler and Clock Mode */
  MODIFY_REG(QSPIx->CLKCFG, 0xF,QSPI_InitStruct->ClkMode |QSPI_InitStruct->ClkDiv);

  /* Configure QSPI Txfifo */
  MODIFY_REG(QSPIx->TXFIFOCFG, 0x7F,QSPI_TXFIFOCFG_EN | (QSPI_InitStruct->TxfifoWm <<QSPI_TXFIFOCFG_WM_Pos));

  /* Configure QSPI Txfifo */
  MODIFY_REG(QSPIx->RXFIFOCFG, 0x1FF,QSPI_RXFIFOCFG_EN | (QSPI_InitStruct->RxfifoWm <<QSPI_RXFIFOCFG_QUADWM_Pos) | \
             (QSPI_InitStruct->RxfifoWm <<QSPI_RXFIFOCFG_NORMWM_Pos));

  /* Configure QSPI Stall */
  if(QSPI_InitStruct->QuitStallCnt == LL_QSPI_STALL_QUITCNT_DISABLE)
  {
    MODIFY_REG(QSPIx->ABORTCFG, QSPI_ABORTCFG_CSTALLEN, LL_QSPI_STALL_QUITCNT_DISABLE);
  }
  else
  {
    MODIFY_REG(QSPIx->ABORTCFG, QSPI_ABORTCFG_CSTALLEN, LL_QSPI_STALL_QUITCNT_ENABLE);
    WRITE_REG(QSPIx->SCNTTHR, QSPI_InitStruct->QuitStallCnt);
  }
}

/**
  * @}
  */
#endif /* defined (QSPI) */

/************************ (C) COPYRIGHT FudanMicroelectronics *****END OF FILE****/
