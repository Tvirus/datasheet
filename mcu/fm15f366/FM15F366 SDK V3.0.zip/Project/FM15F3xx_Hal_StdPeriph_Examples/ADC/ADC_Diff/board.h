/**
  ******************************************************************************
  * @file    board.h
  * @author  SRG
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */

#ifndef __BOARD_H_
#define __BOARD_H_


#ifdef __cplusplus
 extern "C" {
#endif

#include "fm15f3xx.h"
#include "fm15f3xx_hal.h" 
#include "fm15f3xx_conf.h"
	 

extern ADC_HandleTypeDef ADC_Handler;//ADC���
void LED_Toggle(void);
	 



#ifdef __cplusplus
}
#endif
#endif
