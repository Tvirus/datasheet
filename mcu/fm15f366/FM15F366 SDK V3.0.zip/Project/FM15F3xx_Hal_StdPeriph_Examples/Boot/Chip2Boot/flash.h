/*
 ******************************************************************************
 * @file    command.h
 * @author  weifan
 * @version V1.0.0
 * @date    2020-09-03
 * @brief
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
 * All rights reserved.</center></h2>
 *
 ******************************************************************************
 */
#ifndef __COMMAND_H_
#define __COMMAND_H_

#include "fm15f3xx_conf.h"

#ifdef __cplusplus
extern "C" {
#endif

#define CMD_READ         'r'
#define CMD_ERASE_SECTOR 'e'
#define CMD_ERASE_BLOCK  'E'
#define CMD_WRITE        'w'
#define CMD_AUTOTEST     't'
#define CMD_HELP         'h'

#define WORD_SIZE(n)     (4 * (n))

#define MAX_WRITE_WORDS  32

#define MAGIC_NUM        0xA5A5A5A5

#define BASE_DECIMAL     10
#define BASE_HEX         16

#define PARAMETER_VALID  0
#define PARAMETER_ERROR  -1

#define IS_SECTOR_ERASE(c) ((c) == CMD_ERASE_SECTOR)

#define CMD_READ_USAGE     "[r addr cnt] - addr：16进制地址, cnt：数量（word）,\r\n" \
                           "               e.g., r 93000 16\r\n"
#define CMD_WRITE_USAGE    "[w addr values] - addr：16进制地址, values：16进制数值,\r\n" \
                           "                  e.g., w 93000 a b c d\r\n"
#define CMD_AUTOTEST_USAGE "[t addr] - addr：16进制地址, e.g., t 93000\n\r"
#define CMD_ERASE_USAGE    "[%c addr cnt] - addr：16进制地址, cnt：数量（%s）,\n\r" \
                           "               e.g., %c 93000 1\n\r"

void CommandParse(uint8_t *cmd, uint16_t len);
void FLASH_Read(uint32_t *addr, uint32_t *value, uint32_t size);
FLASH_Status FLASH_Write(uint32_t addr, uint32_t *value, uint32_t size);
FLASH_Status FLASH_Erase(uint32_t addr, uint32_t count, uint8_t mode);
int WriteFlash32(uint32_t addr, uint32_t* wbuf, int wlen);
void ReadFlash(uint32_t addr, uint8_t* data, uint32_t len);
int WriteDataFlash(uint32_t addr, uint8_t* data, uint32_t len);

#ifdef __cplusplus
}
#endif
#endif
