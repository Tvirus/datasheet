/**
  ******************************************************************************
  * @file    main.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-04-21
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"
/**
   ALARM 频率检测报警实验
   1.初始化频率检测，包括报警中断；
   2.初始频率报警探测器;
   3.初始化LED，提示系统正常运行；
   4.判断待测频率是否超出报警计数的上限和下限：
     若超出其中一个限值，则产生中断，返回待测频率值；
     若正常运行，返回待测频率值；
  */
int main(void)
{
    uint32_t i=10, freq=1;
    HAL_Init();
    printf("ALARM 频率检测 实验\n");
    HAL_Delay(3000);

    while(i>0)
    {
        freq = HAL_ALM_FrequencyTest_Start(ALM_BASETIMER_0, ALM_BT_CLK_OSC, ALM_BT_CLK_IRC4M);
        printf("IRC16M_FreqValue(Hz):%d\n\n",freq);
        HAL_Delay(3000);
        LED_Toggle();
        i--;

    }
    while(1)
    {
        HAL_Delay(1000);
        LED_Toggle();
    }
}
