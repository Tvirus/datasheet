/**
  ******************************************************************************
  * @file    board.h
  * @author  SRG
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */

#ifndef __BOARD_H_
#define __BOARD_H_


#ifdef __cplusplus
 extern "C" {
#endif

#include "fm15f3xx.h"
#include "fm15f3xx_hal.h" 

	 
void HAL_MspInit(void);

void Test_Low(void);
	 
void LED2_Off(void);

void GPIOToggle(void);
	 
void HAL_BKP_StaticTamperInit(void);





















#ifdef __cplusplus
}
#endif
#endif
