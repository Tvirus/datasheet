/*
 ******************************************************************************
 * @file    autotest.h
 * @author  weifan
 * @version V1.0.0
 * @date    2020-09-07
 * @brief
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
 * All rights reserved.</center></h2>
 *
 ******************************************************************************
 */
#ifndef __AUTOTEST_H_
#define __AUTOTEST_H_

#include "fm15f3xx_conf.h"

#ifdef __cplusplus
extern "C" {
#endif

#define TEST_SUCCESS       0
#define TEST_FAIL          -1

#define MAX_COLUMN         128
#define TEST_RESULT_COLUMN 50
#define MOVE_BACKWARD(col) "\033[" str(col) "D"
#define MOVE_FORWARD(col)  "\033[" str(col) "C"
#define LOCATE_CURSOR(col) MOVE_BACKWARD(MAX_COLUMN) MOVE_FORWARD(col)

#define TEST(func, ...) \
  do { \
    if (func(__VA_ARGS__) == TEST_SUCCESS) { \
      printf("\t" YELLOW_COLOR #func \
             GREEN_COLOR LOCATE_CURSOR(TEST_RESULT_COLUMN) "success\n\r" \
             DEFAULT_THEME); \
    } else { \
      printf("\t" YELLOW_COLOR __FILE__ "@" str(__LINE__) " " #func \
             RED_COLOR LOCATE_CURSOR(TEST_RESULT_COLUMN) "error\n\r" \
             DEFAULT_THEME); \
      return TEST_FAIL; \
    } \
  } while (0)

int8_t TEST_WriteReadCheck(uint32_t addr);
int8_t TEST_RewriteWithoutErase(uint32_t addr);
int8_t TEST_Modify(uint32_t addr);
int8_t TEST_SectorErase(uint32_t addr);
int8_t TEST_BlockErase(uint32_t addr);

#ifdef __cplusplus
}
#endif
#endif
