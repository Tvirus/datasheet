/**
  ******************************************************************************
  * @file    fm15f3xx_ll_fsmc.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-03-17
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  *//* Includes ------------------------------------------------------------------*/
#include "fm15f3xx_ll_fsmc.h"

/** @addtogroup FM15f3XX_LL_Driver
  * @{
  */

#if defined (FSMC)
/** @addtogroup FSMC_LL
  * @{
  */

/**
  * @brief  Set each @ref LL_FSMC_NORSRAMStructInit field to default value.
  * @param  FSMC_NORSRAMInitStruct pointer to a @ref FSMC_NORSRAM_InitTypeDef structure
  * whose fields will be set to default values.
  * @retval None
  */
void LL_FSMC_NORSRAMStructInit(LL_FSMC_NORSRAMInitTypeDef *FSMC_NORSRAMInitStruct)
{
  FSMC_NORSRAMInitStruct->WorkMode            = LL_FSMC_NORSRAM_MODE;
  FSMC_NORSRAMInitStruct->AccessMode          = LL_FSMC_ACCESS_MMAP;
  FSMC_NORSRAMInitStruct->MemoryDataWidth     = LL_FSMC_WIDTH_16;
  FSMC_NORSRAMInitStruct->NWaitEn             = LL_FSMC_NWAIT_DISABLE ;
  FSMC_NORSRAMInitStruct->NWaitPolarity       = LL_FSMC_NWAITPOL_LOW;
  FSMC_NORSRAMInitStruct->ClkEn               = LL_FSMC_CLK_DISABLE;
  FSMC_NORSRAMInitStruct->ClkDiv              = 0;
}

/**
  * @brief  Set each @ref LL_FSMC_LCDStructInit field to default value.
  * @param  FSMC_LCDInitStruct pointer to a @ref FSMC_LCD_InitTypeDef structure
  * whose fields will be set to default values.
  * @retval None
  */
void LL_FSMC_LCDStructInit(LL_FSMC_LCDInitTypeDef *FSMC_LCDInitStruct)
{
  FSMC_LCDInitStruct->WorkMode             = LL_FSMC_LCD_MODE;
  FSMC_LCDInitStruct->AccessMode           = LL_FSMC_ACCESS_MMAP;
  FSMC_LCDInitStruct->LcdDataWidth         = LL_FSMC_WIDTH_16;
  FSMC_LCDInitStruct->LcdType              = LL_FSMC_LCDTYPE_8080 ;
  FSMC_LCDInitStruct->EnOrRdPolarity       = LL_FSMC_ENorRD_LOW;
  FSMC_LCDInitStruct->RwOrWrPolarity       = LL_FSMC_RWorWR_LOW;
}

/**
  * @brief  Set each @ref LL_FSMC_TimingtInitStruct field to default value.
  * @param  FSMC_TimingtInitStruct pointer to a @ref FSMC_TimingtInitStruct structure
  * whose fields will be set to default values.
  * @retval None
  */
void LL_FSMC_TimingtInitStruct(LL_FSMC_TimingConfigTypeDef *FSMC_TimingtInitStruct)
{
  FSMC_TimingtInitStruct->AddressSetupTime       = 0x03;
  FSMC_TimingtInitStruct->AddressHoldTime        = 0x03;
  FSMC_TimingtInitStruct->DataSetupTime          = 0x03;
  FSMC_TimingtInitStruct->DataHoldTime           = 0x03;
  FSMC_TimingtInitStruct->BusReadyTime           = 0x03;
}

/**
  * @brief  Initialize the FSMC_NORSRAM device according to the specified
  *         control parameters in the FSMC_NORSRAM_InitTypeDef
  * @param  Device Pointer to FSMC instance
  * @param  Init Pointer to NORSRAM Initialization structure
  * @retval null
  */
void LL_FSMC_NORSRAMInit(FSMC_TypeDef *FSMCx, LL_FSMC_NORSRAMInitTypeDef *FSMC_NORSRAMInitStruct)
{
  MODIFY_REG(FSMCx->CTRL, 0x1FE,
             FSMC_NORSRAMInitStruct->WorkMode        |
             FSMC_NORSRAMInitStruct->MemoryDataWidth |
             FSMC_NORSRAMInitStruct->NWaitEn         |
             FSMC_NORSRAMInitStruct->NWaitPolarity   |
             FSMC_NORSRAMInitStruct->ClkEn);
  //FMC_CLK
  LL_FSMC_SetClkDiv(FSMCx, FSMC_NORSRAMInitStruct->ClkDiv);

  MODIFY_REG(FSMCx->EXTM, 0x07, FSMC_NORSRAMInitStruct->AccessMode);
}

/**
  * @brief  Initialize the FSMC_LCD device according to the specified
  *         control parameters in the FSMC_LCD_InitTypeDef
  * @param  Device Pointer to FSMC instance
  * @param  Init Pointer to LCD Initialization structure
  * @retval null
  */
void LL_FSMC_LCDInit(FSMC_TypeDef *FSMCx,  LL_FSMC_LCDInitTypeDef *FSMC_LCDInitStruct)
{
  MODIFY_REG(FSMCx->CTRL, 0x7013E,
             FSMC_LCDInitStruct->WorkMode		      |
             FSMC_LCDInitStruct->LcdDataWidth     |
             FSMC_LCDInitStruct->LcdType          |
             FSMC_LCDInitStruct->EnOrRdPolarity   |
             FSMC_LCDInitStruct->RwOrWrPolarity   |
             LL_FSMC_CLK_DISABLE);

  MODIFY_REG(FSMCx->EXTM, 0x07, FSMC_LCDInitStruct->AccessMode);
}

/**
  * @brief  Initialize the Timing according to the specified
  *         parameters in the FSMC_Timing_TypeDef
  * @param  Device Pointer to FSMC instance
  * @param  Timing Pointer to NORSRAM Timing structure
  * @retval HAL status
  */
void LL_FSMC_TimingInit(FSMC_TypeDef *FSMCx, LL_FSMC_TimingConfigTypeDef *FSMC_TimingtInitStruct)
{
  // timing
  MODIFY_REG(FSMCx->ARDT, 0xFFFFF,
             (FSMC_TimingtInitStruct->AddressSetupTime << FSMC_ARDT_RDADDSET_Pos) |
             (FSMC_TimingtInitStruct->AddressHoldTime << FSMC_ARDT_RDADDHLD_Pos)  |
             (FSMC_TimingtInitStruct->DataSetupTime << FSMC_ARDT_RDDATAST_Pos)    |
             (FSMC_TimingtInitStruct->DataHoldTime << FSMC_ARDT_RDDATAHLD_Pos)    |
             (FSMC_TimingtInitStruct->BusReadyTime << FSMC_ARDT_RDBUSRDY_Pos));
  MODIFY_REG(FSMCx->AWRT, 0xFFFFF,
             (FSMC_TimingtInitStruct->AddressSetupTime << FSMC_ARDT_RDADDSET_Pos) |
             (FSMC_TimingtInitStruct->AddressHoldTime << FSMC_ARDT_RDADDHLD_Pos)  |
             (FSMC_TimingtInitStruct->DataSetupTime << FSMC_ARDT_RDDATAST_Pos)    |
             (FSMC_TimingtInitStruct->DataHoldTime << FSMC_ARDT_RDDATAHLD_Pos)    |
             (FSMC_TimingtInitStruct->BusReadyTime << FSMC_ARDT_RDBUSRDY_Pos));
}


/**
  * @}FSMC_LL
  */

#endif /* FSMC */

/**
  * @}FM15F3XX_LL_Driver
  */

/************************ (C) COPYRIGHT FudanMicroelectronics *****END OF FILE****/
