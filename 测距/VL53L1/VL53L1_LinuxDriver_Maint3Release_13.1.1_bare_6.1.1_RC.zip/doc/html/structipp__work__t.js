var structipp__work__t =
[
    [ "data", "structipp__work__t.html#a33aaeed63bc27d25e9e674e461fce711", null ],
    [ "dev_id", "structipp__work__t.html#a2cfcb494f8a03c97e9ac1283a89e0667", null ],
    [ "process_no", "structipp__work__t.html#ae7ecbfc96b5c78ff1f73bbb8c872a21f", null ],
    [ "status", "structipp__work__t.html#a71524bc67b82b0cd2b9a86d9969c27eb", null ],
    [ "xfer_id", "structipp__work__t.html#a1bf7b27b521c51c5ff85088e8ba6d4c4", null ]
];