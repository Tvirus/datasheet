var structstmvl53l1__roi__full__t =
[
    [ "is_read", "structstmvl53l1__roi__full__t.html#ad9be07f64781d6c536149ff8aee14a03", null ],
    [ "roi_cfg", "structstmvl53l1__roi__full__t.html#a821d8c3c0d1aaea9fd2f86135c6bf4cb", null ]
];