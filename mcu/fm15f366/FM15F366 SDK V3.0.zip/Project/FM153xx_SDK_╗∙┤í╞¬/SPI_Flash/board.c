/**
  ******************************************************************************
  * @file    board.c
  * @author  SRG
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"
#include "bsp_spi_flash.h"
#define LED2_PIN	       LL_GPIO_PIN_1
#define LED3_PIN	       LL_GPIO_PIN_2 
#define LOWER_POWER_CTR  LL_BKP_PIN5
#define LED_GPIO	       GPIOA

void LED_Init(void)
{
	LL_GPIO_InitTypeDef GPIO_InitStruct={0};
	GPIO_InitStruct.Pin=LED2_PIN|LED3_PIN;
	GPIO_InitStruct.Alt=LL_GPIO_ALT_GPIO;
	GPIO_InitStruct.Dir=LL_GPIO_DIRECTION_OUT;
	GPIO_InitStruct.DriveStrength=LL_GPIO_DRIVES_STRONG;
	GPIO_InitStruct.Irq=LL_GPIO_INTorDMA_DISABLE;
	GPIO_InitStruct.Lock=LL_GPIO_LK_UNLOCK;
	GPIO_InitStruct.OType=LL_GPIO_OUTPUT_NOOPENDRAIN;
	GPIO_InitStruct.PuPd=LL_GPIO_PULL_UP;
	GPIO_InitStruct.Speed=LL_GPIO_SLEWRATE_HIGH;
	GPIO_InitStruct.WECconfig=LL_GPIO_WKUP_CLOSED;
	LL_GPIO_Init(LED_GPIO,&GPIO_InitStruct);
}

void POWER_Init(void)
{
	LL_BKP_EnableVmain2Vbat(BKP_VMAIN);
	LL_BKP_GPIO_Enable();
	LL_BKP_GPIO_SetPinOutputDir(LOWER_POWER_CTR);
	LL_BKP_GPIO_SetOutputPin(LOWER_POWER_CTR);
}

void LED2_On(void)
{
	LL_GPIO_ResetOutputPin(LED_GPIO,LED2_PIN);
}
void LED2_Off(void)
{
	LL_GPIO_SetOutputPin(LED_GPIO,LED2_PIN);
}
void LED2_Toggle(void)
{
	LL_GPIO_TogglePin(LED_GPIO,LED2_PIN);
}

void LED3_On(void)
{
	LL_GPIO_ResetOutputPin(LED_GPIO,LED3_PIN);
}
void LED3_Off(void)
{
	LL_GPIO_SetOutputPin(LED_GPIO,LED3_PIN);
}
void LED3_Toggle(void)
{
	LL_GPIO_TogglePin(LED_GPIO,LED3_PIN);
}

extern void delay_ms(uint32_t ms)
{
	int i,j;
	for(i=0;i<ms;i++)
		for(j=0;j<4000;j++);
}

void LED_WaterFlow(void)
{
	LED2_On();
	delay_ms(500);
	LED2_Off();
  LED3_On();
	delay_ms(500);
  LED3_Off();
}
