/**
  ******************************************************************************
  * @file    board.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"
#include "lcd.h"
#define LED2_PIN	GPIO_PIN_1
#define LED3_PIN	GPIO_PIN_2 
#define LED_GPIO	GPIOA
#define LOWER_POWER_CTR  LL_BKP_PIN5
#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{ 
	while (1)
	{
	}
}
#endif

void LED_Init(void)
{
	LL_GPIO_InitTypeDef GPIO_InitStruct={0};
	
	GPIO_InitStruct.Pin=LED2_PIN|LED3_PIN;
	GPIO_InitStruct.Alt=LL_GPIO_ALT_GPIO;
	GPIO_InitStruct.Dir=LL_GPIO_DIRECTION_OUT;
	GPIO_InitStruct.DriveStrength=LL_GPIO_DRIVES_STRONG;
	GPIO_InitStruct.Irq=LL_GPIO_INTorDMA_DISABLE;
	GPIO_InitStruct.Lock=LL_GPIO_LK_UNLOCK;
	GPIO_InitStruct.OType=LL_GPIO_OUTPUT_NOOPENDRAIN;
	GPIO_InitStruct.PuPd=LL_GPIO_PULL_UP;
	GPIO_InitStruct.Speed=LL_GPIO_SLEWRATE_HIGH;
	GPIO_InitStruct.WECconfig=LL_GPIO_WKUP_CLOSED;
	LL_GPIO_Init(LED_GPIO,&GPIO_InitStruct);
}

void LED_Toggle(void)
{
	LL_GPIO_TogglePin(LED_GPIO,LED2_PIN|LED3_PIN);
}

void POWER_Init(void)
{
	LL_BKP_EnableVmain2Vbat(BKP_VMAIN);
	LL_BKP_GPIO_Enable();
	LL_BKP_GPIO_SetPinOutputDir(LOWER_POWER_CTR);
	LL_BKP_GPIO_SetOutputPin(LOWER_POWER_CTR);
}
void LCD_EN(void)
{
	LL_GPIO_InitTypeDef GPIO_InitStruct={0};
	
	GPIO_InitStruct.Pin=GPIO_PIN_5|GPIO_PIN_6;
	GPIO_InitStruct.Alt=LL_GPIO_ALT_GPIO;
	GPIO_InitStruct.Dir=LL_GPIO_DIRECTION_OUT;
	GPIO_InitStruct.DriveStrength=LL_GPIO_DRIVES_STRONG;
	GPIO_InitStruct.Irq=LL_GPIO_INTorDMA_DISABLE;
	GPIO_InitStruct.Lock=LL_GPIO_LK_UNLOCK;
	GPIO_InitStruct.OType=LL_GPIO_OUTPUT_NOOPENDRAIN;
	GPIO_InitStruct.PuPd=LL_GPIO_PULL_UP;
	GPIO_InitStruct.Speed=LL_GPIO_SLEWRATE_HIGH;
	GPIO_InitStruct.WECconfig=LL_GPIO_WKUP_CLOSED;
	LL_GPIO_Init(GPIOD,&GPIO_InitStruct);
	
	HAL_GPIO_WritePin(GPIOD,GPIO_PIN_5,GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOD,GPIO_PIN_6,GPIO_PIN_SET);
}

FSMC_HandleTypeDef FSMC_Handle;
void FSMC_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct={0};
	FSMC_TimingConfigTypeDef FSMC_TimingtStruct={0};;
	FSMC_Handle.Instance = FSMC;
	GPIO_InitStruct.PuPd = GPIO_NOPULL;
	GPIO_InitStruct.Alt  = GPIO_AF7_FSMC;
	//FSMC_D4--->LCD_D12
	//FSMC_D5--->LCD_D13
	//FSMC_D6--->LCD_D14
	//FSMC_D7--->LCD_D15
	//FSMC_A17(PB13)--->LCD_RS/DCX
	GPIO_InitStruct.Pin  = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 |GPIO_PIN_13; 
	HAL_GPIO_Init(GPIOB,&GPIO_InitStruct);
	//FSMC_D0--->LCD_D8
	//FSMC_D1--->LCD_D9
	//FSMC_D2--->LCD_D10
	//FSMC_D3--->LCD_D11
	GPIO_InitStruct.Pin  = GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7; 
	HAL_GPIO_Init(GPIOA,&GPIO_InitStruct);
	//FSMC_NE(PC10)--->LCD_CSX
	GPIO_InitStruct.Pin  = GPIO_PIN_10; 
	HAL_GPIO_Init(GPIOC,&GPIO_InitStruct);

	FSMC_Handle.NORSRAMInit.AccessMode  = FSMC_ACCESS_MMAP;
	FSMC_Handle.NORSRAMInit.MemoryWidth = FSMC_WIDTH_16;
	FSMC_Handle.NORSRAMInit.NWaitEn     = FSMC_NWAIT_DISABLE;
	FSMC_Handle.NORSRAMInit.NWaitPol    = FSMC_NWAITPOL_LOW;
	FSMC_Handle.NORSRAMInit.ClkEn       = FSMC_CLK_DISABLE;
	HAL_FSMC_NORSRAMInit(&FSMC_Handle);
	
	FSMC_TimingtStruct.AddressSetupTime = 0x01;
	FSMC_TimingtStruct.AddressHoldTime  = 0x00;
	FSMC_TimingtStruct.DataSetupTime    = 0x01;
	FSMC_TimingtStruct.DataHoldTime     = 0x03;
	FSMC_TimingtStruct.BusReadyTime     = 0x00;
	HAL_FSMC_TimingConfig(&FSMC_Handle, &FSMC_TimingtStruct);

	//RST ����
	GPIO_InitStruct.Pin           = GPIO_PIN_2;
	GPIO_InitStruct.Alt           = GPIO_AF1_GPIO;
	GPIO_InitStruct.Dir           = GPIO_DIRECTION_OUT;
	GPIO_InitStruct.DriveStrength = GPIO_DRIVES_STRONG;
	GPIO_InitStruct.Irq           = GPIO_IRQorDMA_DISABLE;
	GPIO_InitStruct.Lock          = GPIO_UNLOCK;
	GPIO_InitStruct.OType         = GPIO_OUTPUT_NOOPENDRAIN;
	GPIO_InitStruct.PuPd          = GPIO_PULLUP;
	GPIO_InitStruct.Speed         = GPIO_SLEW_SPEED_HIGH;
	GPIO_InitStruct.WECconfig     = GPIO_WKUP_CLOSED;
	HAL_GPIO_Init(GPIOF,&GPIO_InitStruct);
	HAL_GPIO_WritePin(GPIOF,GPIO_PIN_2,GPIO_PIN_SET);

	//PB04--->LCD_WR
	GPIO_InitStruct.Pin           = GPIO_PIN_4;
	GPIO_InitStruct.Alt           = GPIO_AF1_GPIO;
	HAL_GPIO_Init(GPIOB,&GPIO_InitStruct);
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,GPIO_PIN_RESET); //Enable Write
	//PD00--->LCD_RD
	GPIO_InitStruct.Pin           = GPIO_PIN_0;
	GPIO_InitStruct.Alt           = GPIO_AF1_GPIO;
	HAL_GPIO_Init(GPIOD,&GPIO_InitStruct);
	HAL_GPIO_WritePin(GPIOD,GPIO_PIN_0,GPIO_PIN_SET); //Disable Read	
	
	//���� ����
	GPIO_InitStruct.Pin           = GPIO_PIN_7;
	GPIO_InitStruct.Alt           = GPIO_AF1_GPIO;
	HAL_GPIO_Init(GPIOD,&GPIO_InitStruct);
	HAL_GPIO_WritePin(GPIOD,GPIO_PIN_7,GPIO_PIN_RESET);
	
	HAL_FSMC_START(&FSMC_Handle);
}

void HAL_MspInit(void)
{
	SystemClock_Config();
	UART_Init(115200);
  LCD_EN();
	POWER_Init();
	FSMC_Init();
	HAL_Delay(1000);
  LCD_Init();
	HAL_GPIO_WritePin(GPIOD,GPIO_PIN_7,GPIO_PIN_SET); //���� ����
}

