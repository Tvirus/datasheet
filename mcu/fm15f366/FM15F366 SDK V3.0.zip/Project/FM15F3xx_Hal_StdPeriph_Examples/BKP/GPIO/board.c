/**
  ******************************************************************************
  * @file    board.c
  * @author  CLF
  * @version V1.0.0
  * @date    2020-8-28
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"
#include "fm15f3xx_hal_bkp.h"

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{
    while (1)
    {
    }
}
#endif

BKP_HandleTypeDef BKPHandler={0}; //���
BKP_GPIOTypeDef sGpio;

void BKP_GPIOInit(void)
{
    BKPHandler.Instance = BKP;

    HAL_BKP_Init(&BKPHandler);

    sGpio.GpioMode = BKP_GPIO_PIN_GENERIC;
    sGpio.Pin = BKP_GPIO_PIN0 | BKP_GPIO_PIN1;
    sGpio.Direction = BKP_GPIO_PIN_OUTPUT;

    HAL_BKP_GPIOInit(&BKPHandler,&sGpio);

}
void LED_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct={0};

    GPIO_InitStruct.Pin=GPIO_PIN_7 | GPIO_PIN_6;
    GPIO_InitStruct.Alt=LL_GPIO_ALT_GPIO;
    GPIO_InitStruct.Dir=LL_GPIO_DIRECTION_IN;
    GPIO_InitStruct.DriveStrength=LL_GPIO_DRIVES_STRONG;
    GPIO_InitStruct.Irq=LL_GPIO_INTorDMA_DISABLE;
    GPIO_InitStruct.Lock=LL_GPIO_LK_UNLOCK;
    GPIO_InitStruct.OType=LL_GPIO_OUTPUT_NOOPENDRAIN;
    GPIO_InitStruct.PuPd=LL_GPIO_PULL_UP;
    GPIO_InitStruct.Speed=LL_GPIO_SLEWRATE_HIGH;
    GPIO_InitStruct.WECconfig=LL_GPIO_WKUP_CLOSED;
    LL_GPIO_Init(GPIOA,&GPIO_InitStruct);
}

void HAL_MspInit(void)
{
    SystemClock_Config();
    LED_Init();
    BKP_GPIOInit();
}

void GPIOClear(void)
{
    HAL_BKP_GPIOClearPin(&BKPHandler,&sGpio);
}

void GPIOSet(void)
{
    HAL_BKP_GPIOSetPin(&BKPHandler,&sGpio);
}



