/**
  ******************************************************************************
  * @file    main.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-04-21
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"
//#include "bsp_ili9341_lcd.h"
#include "lcd.h"

int main(void)
{
	HAL_Init();

	printf("LCD ʵ��");

	LCD_Clear(WHITE);
  LCD_ShowString(120,100,210,24,24,(uint8_t *)"FM15F366");	
	HAL_Delay(4000);
	
	while(1)
	{
		LCD_Clear(RED);
		HAL_Delay(1000);	
		LCD_Clear(YELLOW);
		HAL_Delay(1000);	
	}
}
