/**
  ******************************************************************************
  * @file    board.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-03-17
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"
#include "uart.h"

#define USERKEY_PIN	  GPIO_PIN_4
#define USERKEY_GPIO	GPIOD

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{
    while (1)
    {
    }
}
#endif

extern void DecToBCD(uint32_t Dec, uint8_t *Bcd, uint32_t length) ;

void Alarm_VDET_Init(void)
{
    ALM_SensorsTypeDef SENSORSn = {0};
    ALM_MonitorInitTypeDef MonitorInit= {0};

    SENSORSn.VddDet = ALM_SENSORS_VDET_ENABLE;
    HAL_ALM_SensorsInit(&SENSORSn);
#if 1
    //��λ����
    MonitorInit.Monitor  = ALM_MONITOR_GROUPA0_VDDH |ALM_MONITOR_GROUPA0_VDDL;//ALM_MONITOR_GROUPA0_VDDL
    MonitorInit.RecordEn = ALM_MONITOR_RCD_ENABLE;
    MonitorInit.Input    = ALM_MONITOR_INPUT_NORMAL;//;
    MonitorInit.DmaEn    = ALM_MONITOR_DMA_DISABLE;
    MonitorInit.IntEn    = ALM_MONITOR_INT_DISABLE;   //ALM_MONITOR_INT_ENABLE
    MonitorInit.RstEn    = ALM_MONITOR_RST_ENABLE;    //ALM_MONITOR_RST_ENABLE	;ALM_MONITOR_RST_DISABLE
    MonitorInit.Power    = ALM_MONITOR_POWERREST_VDD;
    MonitorInit.Nrst     = ALM_MONITOR_NRST_LOW;
    MonitorInit.Filter   = ALM_MONITOR_FILTER_ENABLE;
    HAL_ALM_ClearAllResetRecord();
#else
    //�жϲ���
    MonitorInit.Monitor  = ALM_MONITOR_GROUPA0_VDDH |ALM_MONITOR_GROUPA0_VDDL;//ALM_MONITOR_GROUPA0_VDDL
    MonitorInit.RecordEn = ALM_MONITOR_RCD_ENABLE;
    MonitorInit.Input    = ALM_MONITOR_INPUT_NORMAL;//;
    MonitorInit.DmaEn    = ALM_MONITOR_DMA_DISABLE;
    MonitorInit.IntEn    = ALM_MONITOR_INT_ENABLE;   //ALM_MONITOR_INT_ENABLE;ALM_MONITOR_INT_DISABLE
    MonitorInit.RstEn    = ALM_MONITOR_RST_DISABLE;    //ALM_MONITOR_RST_ENABLE	;ALM_MONITOR_RST_DISABLE
    MonitorInit.Power    = ALM_MONITOR_POWERREST_VDD;
    MonitorInit.Nrst     = ALM_MONITOR_NRST_LOW;
    MonitorInit.Filter   = ALM_MONITOR_FILTER_ENABLE;
#endif
    HAL_ALM_ClearAllAlarmAndRecord();
    HAL_ALM_MonitorInit(MONITOR_GROUPA, &MonitorInit);
    LL_ALM_SetVDDL(LL_ALM_VDDL_300V);
    LL_ALM_SetBOR(LL_ALM_BOR_256V);
}

void Alarm_WDT_Init(void)
{
    ALM_MonitorInitTypeDef MonitorInit= {0};

#if 0
    //��λ����
    MonitorInit.Monitor  = ALM_MONITOR_GROUPC2_WDT;
    MonitorInit.RecordEn = ALM_MONITOR_RCD_ENABLE;
    MonitorInit.Input    = ALM_MONITOR_INPUT_NORMAL;//;
    MonitorInit.DmaEn    = ALM_MONITOR_DMA_DISABLE;
    MonitorInit.IntEn    = ALM_MONITOR_INT_DISABLE;   //ALM_MONITOR_INT_ENABLE
    MonitorInit.RstEn    = ALM_MONITOR_RST_ENABLE;    //ALM_MONITOR_RST_ENABLE	;ALM_MONITOR_RST_DISABLE
    MonitorInit.Power    = ALM_MONITOR_POWERREST_VDD;
    MonitorInit.Nrst     = ALM_MONITOR_NRST_LOW;
    MonitorInit.Filter   = ALM_MONITOR_FILTER_ENABLE;
    HAL_ALM_ClearAllResetRecord();
#else
    //�жϲ���
    MonitorInit.Monitor  = ALM_MONITOR_GROUPC2_WDT;
    MonitorInit.RecordEn = ALM_MONITOR_RCD_ENABLE;
    MonitorInit.Input    = ALM_MONITOR_INPUT_NORMAL;//;
    MonitorInit.DmaEn    = ALM_MONITOR_DMA_DISABLE;
    MonitorInit.IntEn    = ALM_MONITOR_INT_ENABLE;   //ALM_MONITOR_INT_ENABLE;ALM_MONITOR_INT_DISABLE
    MonitorInit.RstEn    = ALM_MONITOR_RST_DISABLE;    //ALM_MONITOR_RST_ENABLE	;ALM_MONITOR_RST_DISABLE
    MonitorInit.Power    = ALM_MONITOR_POWERREST_VDD;
    MonitorInit.Nrst     = ALM_MONITOR_NRST_LOW;
    MonitorInit.Filter   = ALM_MONITOR_FILTER_ENABLE;
#endif
    HAL_ALM_ClearAllAlarmAndRecord();
    HAL_ALM_MonitorInit(MONITOR_GROUPC, &MonitorInit);
}

void Alarm_GPIO_Init(void)
{
    ALM_MonitorInitTypeDef MonitorInit= {0};

#if 0
    //��λ����
    MonitorInit.Monitor  = ALM_MONITOR_GROUPD1_GPIOD;
    MonitorInit.RecordEn = ALM_MONITOR_RCD_ENABLE;
    MonitorInit.Input    = ALM_MONITOR_INPUT_NORMAL;//;
    MonitorInit.DmaEn    = ALM_MONITOR_DMA_DISABLE;
    MonitorInit.IntEn    = ALM_MONITOR_INT_DISABLE;   //ALM_MONITOR_INT_ENABLE
    MonitorInit.RstEn    = ALM_MONITOR_RST_ENABLE;    //ALM_MONITOR_RST_ENABLE	;ALM_MONITOR_RST_DISABLE
    MonitorInit.Power    = ALM_MONITOR_POWERREST_VDD;
    MonitorInit.Nrst     = ALM_MONITOR_NRST_LOW;
    MonitorInit.Filter   = ALM_MONITOR_FILTER_ENABLE;
    HAL_ALM_ClearAllResetRecord();
#else
    //�жϲ���
    MonitorInit.Monitor  = ALM_MONITOR_GROUPD1_GPIOD;
    MonitorInit.RecordEn = ALM_MONITOR_RCD_ENABLE;
    MonitorInit.Input    = ALM_MONITOR_INPUT_NORMAL;//;
    MonitorInit.DmaEn    = ALM_MONITOR_DMA_DISABLE;
    MonitorInit.IntEn    = ALM_MONITOR_INT_ENABLE;   //ALM_MONITOR_INT_ENABLE;ALM_MONITOR_INT_DISABLE
    MonitorInit.RstEn    = ALM_MONITOR_RST_DISABLE;    //ALM_MONITOR_RST_ENABLE	;ALM_MONITOR_RST_DISABLE
    MonitorInit.Power    = ALM_MONITOR_POWERREST_VDD;
    MonitorInit.Nrst     = ALM_MONITOR_NRST_LOW;
    MonitorInit.Filter   = ALM_MONITOR_FILTER_ENABLE;
#endif
    HAL_ALM_ClearAllAlarmAndRecord();
    HAL_ALM_MonitorInit(MONITOR_GROUPD, &MonitorInit);
}

void watchdog_init(void)
{
    LL_WDT_Init(WDT0,LL_WDT_PERIOD_12);

}

void LED_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct= {0};

    GPIO_InitStruct.Pin           = GPIO_PIN_6;
    GPIO_InitStruct.Alt           = LL_GPIO_ALT_GPIO;
    GPIO_InitStruct.Dir           = LL_GPIO_DIRECTION_OUT;
    GPIO_InitStruct.DriveStrength = LL_GPIO_DRIVES_STRONG;
    GPIO_InitStruct.Irq           = LL_GPIO_INTorDMA_DISABLE;
    GPIO_InitStruct.Lock          = LL_GPIO_LK_UNLOCK;
    GPIO_InitStruct.OType         = LL_GPIO_OUTPUT_NOOPENDRAIN;
    GPIO_InitStruct.PuPd          = LL_GPIO_PULL_UP;
    GPIO_InitStruct.Speed         = LL_GPIO_SLEWRATE_HIGH;
    GPIO_InitStruct.WECconfig     = LL_GPIO_WKUP_CLOSED;
    LL_GPIO_Init(GPIOA,&GPIO_InitStruct);
}

void Userkey_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct= {0};

    GPIO_InitStruct.Pin           = USERKEY_PIN;
    GPIO_InitStruct.Alt           = LL_GPIO_ALT_GPIO;
    GPIO_InitStruct.Dir           = LL_GPIO_DIRECTION_IN;
    GPIO_InitStruct.DriveStrength = LL_GPIO_DRIVES_STRONG;
    GPIO_InitStruct.Irq           = LL_GPIO_INTonFALL;
    GPIO_InitStruct.Lock          = LL_GPIO_LK_UNLOCK;
    GPIO_InitStruct.OType         = LL_GPIO_OUTPUT_NOOPENDRAIN;
    GPIO_InitStruct.PuPd          = LL_GPIO_PULL_UP;
    GPIO_InitStruct.Speed         = LL_GPIO_SLEWRATE_HIGH;
    GPIO_InitStruct.WECconfig     = LL_GPIO_WKUP_FALL;
    LL_GPIO_Init(USERKEY_GPIO,&GPIO_InitStruct);
}
void HAL_MspInit(void)
{
    SystemClock_Config();
    UART_Init(115200);
    printf("Uart initial ok!\r\n");
    LED_Init();
    //GPIO ALARM
    Userkey_Init();
    Alarm_GPIO_Init();

    //WDT ALARM
    watchdog_init();
    LL_WDT_Start(WDT0);
    Alarm_WDT_Init();

    //VDET ALARM
    Alarm_VDET_Init();

}


void Led_Toggle(void)
{
    LL_GPIO_TogglePin(GPIOA,GPIO_PIN_6);
}


void NMI_Handler(void)
{
    printf("NMI_Handler!\r\n");
    if(HAL_ALM_IsActiveAlarmRecord(MONITOR_GROUPD, LL_ALM_ALARMRESETD_GPIOD))
    {
        printf("GPIOD Alarm Int!\r\n");
        LL_GPIO_ClearFlagPin_IT(USERKEY_GPIO,USERKEY_PIN);
    }

    if(HAL_ALM_IsActiveAlarmRecord(MONITOR_GROUPC, ALM_MONITOR_GROUPC2_WDT))
    {
        printf("WDT Alarm Int!\r\n");
        LL_WDT_FeedDog(WDT0);
    }
    HAL_ALM_ClearAllAlarmAndRecord();

}

void GPIOD_Handler(void)
{
    printf("GPIOD Int!\r\n");
    LL_GPIO_ClearFlagPin_IT(USERKEY_GPIO,USERKEY_PIN);
}
