/**
  ******************************************************************************
  * @file    main.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-04-21
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"
/**
   ADC ���ݴ���ʵ��
   1.��ʼ��ADC������ƽ��������
   2.���ڲ�1.2V���в���
*/

int main(void)
{
    uint32_t a = 0;
    HAL_Init();

    while(1)
    {
        HAL_Delay(1000);

        LED_Toggle();
        a = Get_Vrefh_VDD(ADC_CHANNEL_0,10);
    }
}
