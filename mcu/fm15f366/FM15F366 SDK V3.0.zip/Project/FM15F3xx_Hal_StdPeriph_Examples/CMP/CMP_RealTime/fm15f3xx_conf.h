/**
  ******************************************************************************
  * @file    fm15f3xx_conf.h
  * @author  MCD Application Team
  * @version V1.0.0
  * @date    2020-04-14
  * @brief   Fm15F3xx configuration file. 
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT(c) 2020 FudanMicroelectronics</center></h2>
  *
  ******************************************************************************
  */ 

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __FM15F3xx_CONF_H
#define __FM15F3xx_CONF_H

#ifdef __cplusplus
 extern "C" {
#endif

// <<< Use Configuration Wizard in Context Menu >>>
/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* ########################## HSE/IRC Values adaptation ##################### */
/**
  * @brief Adjust the value of External High Speed oscillator (HSE) used in your application.
  *        This value is used by the RCC HAL module to compute the system frequency
  *        (when HSE is used as system clock source, directly or through the PLL).  
  */
// <o>System Max Frequency
//  <i>Default: 180MHz
//  <180000000UL=> 180MHz
#if!defined  (SYS_MAXVALUE)
  #define SYS_MAXVALUE    ((uint32_t)180000000U) /*!<Permit Max Value of the System clock in Hz */
#endif /* SYS_MAXVALUE */

/* ########################### System Configuration ######################### */
/**
  * @brief This is the HAL system configuration section
  */     
// <o>VDD Value
//  <i>Default: 3300 (Unit:mv)
//  <1710-3600>
#define  VDD_VALUE                    (3300U) /*!< Value of VDD in mv */
// <o>TICK INT PRIORITY
//  <i>Default: 0xF
//  <0-15>
#define  TICK_INT_PRIORITY            (0x0FU) /*!< tick interrupt priority */

// <e>USE_RTOS Config
//  <o>USE_RTOS
//   <i> Default:USE_RTOS
//   <0=> USE_RTOS
#define  USE_RTOS                     0U
// </e>

// <e>CACHE_ENABLE
//  <o>CACHE_ENABLE
//   <i> Default:CACHE_ENABLE
//   <1=> CACHE_ENABLE
#define  CACHE_ENABLE            1U
// </e>
 
/* ########################## Assert Selection ############################## */
/**
  * @brief Uncomment the line below to expanse the "assert_param" macro in the 
  *        HAL drivers code
  */
//<c>USE_FULL_ASSERT
#define USE_FULL_ASSERT
//</c>
	 
/* ########################## Module Selection ############################## */
/**
  * @brief This is the list of modules to be used in the HAL driver 
  */
	
// <h>MCU Module Enable Selection

// <o>Libraries Selection
//  <i>Default: HAL_LIB
//  <1=> HAL_LIB
//  <0=> LL_LIB
#define IS_HAL_LIB   1  /*!<Libraries Selection HAL or LL */

//<c>CORTEX
#define CORTEX_MODULE_ENABLED
//</c>

//<c>CMU
#define CMU_MODULE_ENABLED
//</c>

//<c>PMU
//#define PMU_MODULE_ENABLED
//</c>

//<c>ALARM
//#define ALM_MODULE_ENABLED
//</c>

//<c>FLASH
//#define FLASH_MODULE_ENABLED
//</c>

//<c>DMA
//#define DMA_MODULE_ENABLED
//</c>

//<c>GPIO
#define GPIO_MODULE_ENABLED
//</c>

//<c>UART
#define UART_MODULE_ENABLED
//</c>

//<c>CT
//#define SMARTCARD_MODULE_ENABLED
//</c>

//<c>I2C
//#define I2C_MODULE_ENABLED
//</c>

//<c>SPI
//#define SPI_MODULE_ENABLED 
//</c>

//<c>QSPI
//#define QSPI_MODULE_ENABLED
//</c>

//<c>FSMC
//#define FSMC_MODULE_ENABLED
//</c>

//<c>DCMI
//#define DCMI_MODULE_ENABLED
//</c>

//<c>WDT
//#define WDT_MODULE_ENABLED
//</c>

//<c>STIM
//#define STIM_MODULE_ENABLED 
//</c>

//<c>LPTIM
//#define LPTIM_MODULE_ENABLED
//</c>

//<c>RTC
//#define RTC_MODULE_ENABLED
//</c>

//<c>BKP
//#define BKP_MODULE_ENABLED
//</c>

//<c>ADC
//#define ADC_MODULE_ENABLED
//</c>

//<c>DAC
#define DAC_MODULE_ENABLED
//</c>

//<c>CMP
#define CMP_MODULE_ENABLED
//</c>

//<c>CRC
//#define CRC_MODULE_ENABLED
//</c>

//<c>SYSTICK
//#define SYSTICK_MODULE_ENABLED 
//</c>

//<c>MPU
//#define MPU_MODULE_ENABLED 
//</c>

//<c>RAND
//#define RAND_MODULE_ENABLED
//</c>

//<c>SECU
//#define SECU_MODULE_ENABLED
//</c>
// </h>  // end of MCU Module Selection	 

/* Includes ------------------------------------------------------------------*/
/**
  * @brief Include module's header file 
  */
#ifdef CORTEX_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_cortex.h"
#else
  #include "fm15f3xx_ll_cortex.h"
#endif
#endif /* CORTEX_MODULE_ENABLED */

#ifdef CMU_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_cmu.h"
#else
  #include "fm15f3xx_ll_cmu.h"
#endif
#endif /* CMU_MODULE_ENABLED */

#ifdef PMU_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_pmu.h"
#else
  #include "fm15f3xx_ll_pmu.h"
#endif
#endif /* PMU_MODULE_ENABLED */

#ifdef ALM_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_alarm.h"
#else
  #include "fm15f3xx_ll_alarm.h"
#endif
#endif /* ALM_MODULE_ENABLED */

#ifdef FLASH_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_flash.h"
#else
  #include "fm15f3xx_ll_flash.h"
#endif
#endif /* FLASH_MODULE_ENABLED */

#ifdef DMA_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_dma.h"
#else
  #include "fm15f3xx_ll_dma.h"
#endif
#endif /* DMA_MODULE_ENABLED */

#ifdef GPIO_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_gpio.h"
#else
  #include "fm15f3xx_ll_gpio.h"
#endif
#endif /* GPIO_MODULE_ENABLED */

#ifdef UART_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_uart.h"
#else
  #include "fm15f3xx_ll_uart.h"
#endif	
#endif /* UART_MODULE_ENABLED */

#ifdef SMARTCARD_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_ct.h"
#else
  #include "fm15f3xx_ll_ct.h"
#endif
#endif /* SMARTCARD_MODULE_ENABLED */

#ifdef I2C_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_i2c.h"
#else
  #include "fm15f3xx_ll_i2c.h"
#endif	
#endif /* I2C_MODULE_ENABLED */

#ifdef SPI_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_spi.h"
#else
  #include "fm15f3xx_ll_spi.h"
#endif
#endif /* SPI_MODULE_ENABLED */

#ifdef QSPI_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_qspi.h"
#else
  #include "fm15f3xx_ll_qspi.h"
#endif
#endif /* QSPI_MODULE_ENABLED */

#ifdef FSMC_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_fsmc.h"
#else
  #include "fm15f3xx_ll_fsmc.h"
#endif
#endif /* FSMC_MODULE_ENABLED */

#ifdef DCMI_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_dcmi.h"
#else
  #include "fm15f3xx_ll_dcmi.h"
#endif
#endif /* DCMI_MODULE_ENABLED */

#ifdef WDT_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_wdt.h"
#else
  #include "fm15f3xx_ll_wdt.h"
#endif
#endif /* WDG_MODULE_ENABLED */

#ifdef STIM_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_stimer.h"
#else
  #include "fm15f3xx_ll_stimer.h"
#endif
#endif /* GPIO_MODULE_ENABLED */

#ifdef LPTIM_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_lptimer.h"
#else
  #include "fm15f3xx_ll_lptimer.h"
#endif
#endif /* LPTIM_MODULE_ENABLED */

#ifdef RTC_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_rtc.h"
#else
  #include "fm15f3xx_ll_rtc.h"
#endif
#endif /* RTC_MODULE_ENABLED */

#ifdef BKP_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_bkp.h"
#else
  #include "fm15f3xx_ll_bkp.h"
#endif
#endif /* BKP_MODULE_ENABLED */

#ifdef ADC_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_adc.h"
#else
  #include "fm15f3xx_ll_adc.h"
#endif
#endif /* ADC_MODULE_ENABLED */

#ifdef DAC_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_dac.h"
#else
  #include "fm15f3xx_ll_dac.h"
#endif
#endif /* DAC_MODULE_ENABLED */

#ifdef CMP_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_cmp.h"
#else
  #include "fm15f3xx_ll_cmp.h"
#endif
#endif /* CMP_MODULE_ENABLED */

#ifdef CRC_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_crc.h"
#else
  #include "fm15f3xx_ll_crc.h"
#endif
#endif /* CRC_MODULE_ENABLED */

#ifdef SYSTICK_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_systick.h" 
#else
  #include "fm15f3xx_ll_systick.h"
#endif
#endif /* SYSTICK_MODULE_ENABLED */

#ifdef MPU_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_mpu.h"
#else
  #include "fm15f3xx_ll_mpu.h"
#endif
#endif /* MPU_MODULE_ENABLED */

#ifdef RAND_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_rand.h"
#else
  #include "fm15f3xx_ll_rand.h"
#endif
#endif /* RAND_MODULE_ENABLED */

#ifdef SECU_MODULE_ENABLED
#if (IS_HAL_LIB)
  #include "fm15f3xx_hal_secu.h"
#else
  #include "fm15f3xx_ll_secu.h"
#endif
#endif /* SECU_MODULE_ENABLED */

/* Exported macro ------------------------------------------------------------*/
#ifdef  USE_FULL_ASSERT
/**
  * @brief  The assert_param macro is used for function's parameters check.
  * @param  expr: If expr is false, it calls assert_failed function
  *         which reports the name of the source file and the source
  *         line number of the call that failed. 
  *         If expr is true, it returns no value.
  * @retval None
  */
  #define assert_param(expr) ((expr) ? (void)0 : assert_failed((uint8_t *)__FILE__, __LINE__))
/* Exported functions ------------------------------------------------------- */
  void assert_failed(uint8_t* file, uint32_t line);
#else
  #define assert_param(expr) ((void)0)
#endif /* USE_FULL_ASSERT */


//<<< end of configration section >>>
#ifdef __cplusplus
}
#endif

#endif /* __FM15F3xx_CONF_H */
 

/************************ (C) COPYRIGHT FudanMicroelectronics *****END OF FILE****/
