var modules =
[
    [ "debugging", "group__vl53l1__mod__dbg.html", "group__vl53l1__mod__dbg" ],
    [ "IOCTL interface commands", "group__vl53l1__ioctl.html", "group__vl53l1__ioctl" ],
    [ "sysfs attribute", "group__sysfs__attrib.html", "group__sysfs__attrib" ],
    [ "vl53l1 interface module porting and customization", "group__drv__port.html", "group__drv__port" ],
    [ "IPP information", "group__ipp__dev.html", "group__ipp__dev" ]
];