/**
  ******************************************************************************
  * @file    fm15f3xx_hal_conf.h
  * @author  MCD Application Team
  * @version V1.0.0
  * @date    2020-04-14
  * @brief   HAL configuration file. 
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT(c) 2016 STMicroelectronics</center></h2>
  *
  ******************************************************************************
  */ 

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __FM15F3xx_HAL_CONF_H
#define __FM15F3xx_HAL_CONF_H

#ifdef __cplusplus
 extern "C" {
#endif

// <<< Use Configuration Wizard in Context Menu >>>
/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* ########################## HSE/IRC Values adaptation ##################### */
/**
  * @brief Adjust the value of External High Speed oscillator (HSE) used in your application.
  *        This value is used by the RCC HAL module to compute the system frequency
  *        (when HSE is used as system clock source, directly or through the PLL).  
  */
// <o>Set System Max Frequency
//  <i>Default: 180MHz
//  <180000000UL=> 180MHz
#if!defined  (SYS_MAXVALUE)
  #define SYS_MAXVALUE    ((uint32_t)180000000U) /*!<Permit Max Value of the System clock in Hz */
#endif /* SYS_MAXVALUE */

// <o>Set OSC Frequency
//  <i>Default: 12MHz
//  <12000000UL=> 12MHz
//  <8000000UL=> 8MHz
#if!defined  (OSC_VALUE) 
  #define OSC_VALUE    ((uint32_t)12000000U) /*!< Value of the External oscillator in Hz */
#endif /* OSC_VALUE */

/* ########################### System Configuration ######################### */
/**
  * @brief This is the HAL system configuration section
  */     
// <o>VDD
//  <i>Default: 3300 (Unit:mv)
//  <1710-3600>
#define  VDD_VALUE                    (3300U) /*!< Value of VDD in mv */
// <o>TICK INT PRIORITY
//  <i>Default: 0xF
//  <0-15>
#define  TICK_INT_PRIORITY            (0x0FU) /*!< tick interrupt priority */

// <e>USE_RTOS Config
//  <o>USE_RTOS
//   <i> Default:USE_RTOS
//   <0=> USE_RTOS
#define  USE_RTOS                     0U
// </e>

// <e>DATA_CACHE_ENABLE
//  <o>DATA_CACHE_ENABLE
//   <i> Default:DATA_CACHE_ENABLE
//   <1=> DATA_CACHE_ENABLE
#define  DATA_CACHE_ENABLE            1U
// </e>
 
/* ########################## Assert Selection ############################## */
/**
  * @brief Uncomment the line below to expanse the "assert_param" macro in the 
  *        HAL drivers code
  */
//<c>USE_FULL_ASSERT
#define USE_FULL_ASSERT
//</c>
	 
/* ########################## Module Selection ############################## */
/**
  * @brief This is the list of modules to be used in the HAL driver 
  */
// <h>CORTEX Module Enable Selection
//<c>CORTEX
#define HAL_CORTEX_MODULE_ENABLED
//</c>

//<c>CMU
#define HAL_CMU_MODULE_ENABLED
//</c>

//<c>PMU
//#define HAL_PMU_MODULE_ENABLED
//</c>

//<c>ALARM
//#define HAL_ALM_MODULE_ENABLED
//</c>

//<c>FLASH
//#define HAL_FLASH_MODULE_ENABLED
//</c>

//<c>DMA
//#define HAL_DMA_MODULE_ENABLED
//</c>

//<c>GPIO
#define HAL_GPIO_MODULE_ENABLED
//</c>

//<c>UART
#define HAL_UART_MODULE_ENABLED
//</c>

//<c>CT
//#define HAL_SMARTCARD_MODULE_ENABLED
//</c>

//<c>I2C
//#define HAL_I2C_MODULE_ENABLED
//</c>

//<c>SPI
//#define HAL_SPI_MODULE_ENABLED 
//</c>

//<c>QSPI
//#define HAL_QSPI_MODULE_ENABLED
//</c>

//<c>FSMC
//#define HAL_FSMC_MODULE_ENABLED
//</c>

//<c>DCMI
//#define HAL_DCMI_MODULE_ENABLED
//</c>

//<c>WDT
//#define HAL_WDG_MODULE_ENABLED
//</c>

//<c>TIM
//#define HAL_STIM_MODULE_ENABLED 
//</c>

//<c>LPTIM
//#define HAL_LPTIM_MODULE_ENABLED
//</c>

//<c>RTC
//#define HAL_RTC_MODULE_ENABLED
//</c>

//<c>BKP
//#define HAL_BKP_MODULE_ENABLED
//</c>

//<c>ADC
//#define HAL_ADC_MODULE_ENABLED
//</c>

//<c>DAC
//#define HAL_DAC_MODULE_ENABLED
//</c>

//<c>CMP
//#define HAL_CMP_MODULE_ENABLED
//</c>

//<c>CRC
//#define HAL_CRC_MODULE_ENABLED
//</c>

//<c>MPU
//#define HAL_MPU_MODULE_ENABLED 
//</c>

//<c>RAND
//#define HAL_RAND_MODULE_ENABLED
//</c>

//<c>SECU
//#define HAL_SECU_MODULE_ENABLED
//</c>
// </h>  // end of MCU Module Selection	 

/* Includes ------------------------------------------------------------------*/
/**
  * @brief Include module's header file 
  */
#ifdef HAL_CORTEX_MODULE_ENABLED
  #include "fm15f3xx_hal_cortex.h"
#endif /* HAL_CORTEX_MODULE_ENABLED */

#ifdef HAL_CMU_MODULE_ENABLED
  #include "fm15f3xx_hal_cmu.h"
#endif /* HAL_CMU_MODULE_ENABLED */


#ifdef HAL_PMU_MODULE_ENABLED
  #include "fm15f3xx_hal_pmu.h"
#endif /* HAL_PMU_MODULE_ENABLED */

#ifdef HAL_ALM_MODULE_ENABLED
  #include "fm15f3xx_hal_alarm.h"
#endif /* HAL_ALM_MODULE_ENABLED */


#ifdef HAL_FLASH_MODULE_ENABLED
  #include "fm15f3xx_hal_flash.h"
#endif /* HAL_FLASH_MODULE_ENABLED */

#ifdef  HAL_DMA_MODULE_ENABLED
  #include "fm15f3xx_hal_dma.h"
#endif /* HAL_DMA_MODULE_ENABLED */

#ifdef HAL_GPIO_MODULE_ENABLED
#include "fm15f3xx_hal_gpio.h"
#endif /* HAL_GPIO_MODULE_ENABLED */

#ifdef HAL_UART_MODULE_ENABLED
  #include "fm15f3xx_hal_uart.h"
#endif /* HAL_UART_MODULE_ENABLED */

#ifdef HAL_SMARTCARD_MODULE_ENABLED
#include "fm15f3xx_hal_ct.h"
#endif /* HAL_SMARTCARD_MODULE_ENABLED */

#ifdef HAL_I2C_MODULE_ENABLED
  #include "fm15f3xx_hal_i2c.h"
#endif /* HAL_I2C_MODULE_ENABLED */

#ifdef HAL_SPI_MODULE_ENABLED
#include "fm15f3xx_hal_spi.h"
#endif /* HAL_SPI_MODULE_ENABLED */

#ifdef HAL_QSPI_MODULE_ENABLED
  #include "fm15f3xx_hal_qspi.h"
#endif /* HAL_QSPI_MODULE_ENABLED */

#ifdef HAL_FSMC_MODULE_ENABLED
  #include "fm15f3xx_hal_fsmc.h"
#endif /* HAL_FSMC_MODULE_ENABLED */

#ifdef HAL_DCMI_MODULE_ENABLED
  #include "fm15f3xx_hal_dcmi.h"
#endif /* HAL_DCMI_MODULE_ENABLED */

#ifdef HAL_WDG_MODULE_ENABLED
  #include "fm15f3xx_hal_wdt.h"
#endif /* HAL_WDG_MODULE_ENABLED */

#ifdef HAL_STIM_MODULE_ENABLED
  #include "fm15f3xx_hal_stimer.h"
#endif /* HAL_GPIO_MODULE_ENABLED */

#ifdef HAL_LPTIM_MODULE_ENABLED
  #include "fm15f3xx_ll_lptimer.h"
#endif /* HAL_LPTIM_MODULE_ENABLED */

#ifdef HAL_RTC_MODULE_ENABLED
  #include "fm15f3xx_hal_rtc.h"
#endif /* HAL_RTC_MODULE_ENABLED */

#ifdef HAL_BKP_MODULE_ENABLED
  #include "fm15f3xx_hal_bkp.h"
#endif /* HAL_BKP_MODULE_ENABLED */

#ifdef HAL_ADC_MODULE_ENABLED
  #include "fm15f3xx_hal_adc.h"
#endif /* HAL_ADC_MODULE_ENABLED */

#ifdef HAL_DAC_MODULE_ENABLED
  #include "fm15f3xx_hal_dac.h"
#endif /* HAL_DAC_MODULE_ENABLED */

#ifdef HAL_CMP_MODULE_ENABLED
  #include "fm15f3xx_hal_cmp.h"
#endif /* HAL_CMP_MODULE_ENABLED */

#ifdef HAL_CRC_MODULE_ENABLED
  #include "fm15f3xx_hal_crc.h"
#endif /* HAL_CRC_MODULE_ENABLED */

#ifdef HAL_MPU_MODULE_ENABLED
  #include "fm15f3xx_hal_mpu.h"
#endif /* HAL_MPU_MODULE_ENABLED */

#ifdef HAL_RAND_MODULE_ENABLED
  #include "fm15f3xx_hal_rand.h"
#endif /* HAL_RAND_MODULE_ENABLED */

#ifdef HAL_SECU_MODULE_ENABLED
  #include "fm15f3xx_hal_secu.h"
#endif /* HAL_SECU_MODULE_ENABLED */

/* Exported macro ------------------------------------------------------------*/
#ifdef  USE_FULL_ASSERT
/**
  * @brief  The assert_param macro is used for function's parameters check.
  * @param  expr: If expr is false, it calls assert_failed function
  *         which reports the name of the source file and the source
  *         line number of the call that failed. 
  *         If expr is true, it returns no value.
  * @retval None
  */
  #define assert_param(expr) ((expr) ? (void)0 : assert_failed((uint8_t *)__FILE__, __LINE__))
/* Exported functions ------------------------------------------------------- */
  void assert_failed(uint8_t* file, uint32_t line);
#else
  #define assert_param(expr) ((void)0)
#endif /* USE_FULL_ASSERT */


//<<< end of configration section >>>
#ifdef __cplusplus
}
#endif

#endif /* __FM15F3xx_HAL_CONF_H */
 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
