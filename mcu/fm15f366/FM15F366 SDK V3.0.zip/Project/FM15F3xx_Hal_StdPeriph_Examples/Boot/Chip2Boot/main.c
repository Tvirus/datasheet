/**
  ******************************************************************************
  * @file    main.c
  * @author  weifan
  * @version V1.0.0
  * @date    2020-09-01
  * @brief
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include <stdio.h>
#include "main.h"
#include "board.h"
#include "uart.h"

/* Boot Demo 功能说明
 * 1、设置Chip to Boot
 */
#define MANU_MODE 0  // =1,工厂模式；=0,用户模式
int main(void)
{
  HAL_Init();
  // 用户模式下的芯片，NVR0区擦除（NVR0地址为0x3FFF0000），擦除后芯片下次复位即开始执行BOOT。
	LL_FLASH_Erase1Sector_Single(0x3FFF0000);
  
#if(MANU_MODE ==1)
  if(READ_BIT(*((uint32_t *)0x4007E010),0x08)==0)
  {
      uint8_t data[] = {0x08,0x00,0x00,0x00,0xF7,0xFF,0xFF,0xFF};
      //工厂模式的芯片，写NVR3（NVR0地址为0x3FFF1800），写后芯片下次复位即开始执行BOOT。
      WriteDataFlash(0x3FFF1800,data,sizeof(data)/sizeof(data[0]));
  }
#endif
  
  while(1){
    printf("Set Chip2Boot OK");
    HAL_Delay(1000);
  }
}
