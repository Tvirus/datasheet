var group__ipp__dev =
[
    [ "ST IPP serialization helper", "group__ipp__serialize.html", "group__ipp__serialize" ]
];