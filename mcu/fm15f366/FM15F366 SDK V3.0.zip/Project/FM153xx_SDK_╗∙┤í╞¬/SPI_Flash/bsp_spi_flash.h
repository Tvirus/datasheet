#include "fm15f3xx.h"
#include "fm15f3xx_conf.h"

#ifndef __SPI_FLASH_H
#define __SPI_FLASH_H

#define SPI_FLASH_MOSI_PIN	GPIO_PIN_10
#define SPI_FLASH_MISO_PIN	GPIO_PIN_9
#define SPI_FLASH_SCK_PIN		GPIO_PIN_8
#define SPI_FLASH_NSS_PIN		LL_BKP_GPIO_PIN1
#define SPI_PORT		        GPIOE
#define SPIx			          SPI3
 
void SPI_Init(void);
uint8_t SPI_RW_Byte(uint8_t cmd_addr);
void SPI_FLASH_SectorErase(uint32_t SectorAddr);
void SPI_FLASH_BulkErase(void);
void SPI_FLASH_PageWrite(uint8_t* pBuffer, uint32_t WriteAddr, uint16_t NumByteToWrite);
void SPI_FLASH_BufferWrite(uint8_t* pBuffer, uint32_t WriteAddr, uint16_t NumByteToWrite);
void SPI_FLASH_BufferRead(uint8_t* pBuffer, uint32_t ReadAddr, uint16_t NumByteToRead);
uint32_t SPI_FLASH_ReadID(void);
uint32_t SPI_FLASH_ReadDeviceID(void);
void SPI_FLASH_StartReadSequence(uint32_t ReadAddr);
void SPI_Flash_PowerDown(void);
void SPI_Flash_WAKEUP(void);
uint8_t SPI_FLASH_ReadByte(void);
uint16_t SPI_FLASH_SendHalfWord(uint16_t HalfWord);
void SPI_FLASH_WriteEnable(void);
void SPI_FLASH_WaitForWriteEnd(void);

#endif /* __SPI_FLASH_H */

